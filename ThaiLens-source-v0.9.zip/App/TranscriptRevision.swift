import Foundation

struct SpeechUpdate {
    let group: UUID
    let revision: Int
    let text: String
    let isFinal: Bool
    var uncertain: Bool = false
}

enum TranscriptRevision {
    // A correction (not merely more words) makes an in-flight older translation stale.
    // Never revive text from a finished/replaced recognition request.
    static func canDisplay(candidate: String, current: String,
                           candidateGroup: UUID?, currentGroup: UUID?) -> Bool {
        guard candidateGroup == currentGroup else { return false }
        let old = TextTools.normalized(candidate)
        let latest = TextTools.normalized(current)
        return !old.isEmpty && latest.hasPrefix(old)
    }
}
