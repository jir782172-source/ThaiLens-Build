import AVKit
import SwiftUI

final class SubtitleSurface: UIView {
    override class var layerClass: AnyClass { AVSampleBufferDisplayLayer.self }
    var displayLayer: AVSampleBufferDisplayLayer { layer as! AVSampleBufferDisplayLayer }
}

struct SubtitlePreview: UIViewRepresentable {
    let window: SubtitleWindow
    func makeUIView(context: Context) -> SubtitleSurface { window.surface }
    func updateUIView(_ uiView: SubtitleSurface, context: Context) {}
}

final class SubtitleWindow: NSObject, ObservableObject,
                            AVPictureInPictureSampleBufferPlaybackDelegate,
                            AVPictureInPictureControllerDelegate {
    let surface = SubtitleSurface()
    @Published var possible = false
    @Published var active = false
    @Published private(set) var pageNumber = 1
    @Published private(set) var pageCount = 1
    @Published private(set) var autoPaging = true
    @Published private(set) var hasPendingCaption = false
    @Published private(set) var fullText = "准备后开启字幕窗口"
    var onError: ((String) -> Void)?
    var onStopped: (() -> Void)?
    private var controller: AVPictureInPictureController?
    private var observation: NSKeyValueObservation?
    private var timer: Timer?
    private var title = "泰语 → 中文"
    private var pager = SubtitlePager()
    private var timebase: CMTimebase?
    private var showingTranslation = false
    private var waitingForInput = false
    private var audioStatus: String?
    private var recoveryStatus: String?
    private var captureStatus: String?
    private var now: TimeInterval { ProcessInfo.processInfo.systemUptime }

    override init() {
        super.init()
        surface.displayLayer.videoGravity = .resizeAspect
        CMTimebaseCreateWithSourceClock(allocator: kCFAllocatorDefault,
                                       sourceClock: CMClockGetHostTimeClock(), timebaseOut: &timebase)
        if let timebase {
            CMTimebaseSetTime(timebase, time: .zero)
            CMTimebaseSetRate(timebase, rate: 1)
            surface.displayLayer.controlTimebase = timebase
        }
        guard AVPictureInPictureController.isPictureInPictureSupported() else { return }
        let source = AVPictureInPictureController.ContentSource(sampleBufferDisplayLayer: surface.displayLayer,
                                                                playbackDelegate: self)
        controller = AVPictureInPictureController(contentSource: source)
        controller?.delegate = self
        controller?.requiresLinearPlayback = false
        observation = controller?.observe(\.isPictureInPicturePossible, options: [.initial, .new]) { [weak self] c, _ in
            DispatchQueue.main.async { self?.possible = c.isPictureInPicturePossible }
        }
    }

    func prepare() throws {
        let audio = AVAudioSession.sharedInstance()
        try audio.setCategory(.playback, mode: .moviePlayback, options: [.mixWithOthers])
        try audio.setActive(true)
        if timer == nil {
            let timer = Timer(timeInterval: 1, repeats: true) { [weak self] _ in self?.tick() }
            RunLoop.main.add(timer, forMode: .common)
            self.timer = timer
        }
        render()
    }

    func show(_ text: String, title: String = "泰语 → 中文 · 实验版") {
        self.title = title
        showingTranslation = false
        waitingForInput = false
        pager.setPlaying(true, now: now)
        pager.replace(SubtitleDocument(text), now: now)
        synchronize()
    }

    func showTranslation(_ text: String, group: UUID? = nil, provisional: Bool = false, realtime: Bool = false) {
        title = "泰语 → 中文 · Qwen 翻译"
        waitingForInput = false
        let document = SubtitleDocument(text, group: group, provisional: provisional)
        if showingTranslation { pager.submit(document, now: now, realtime: realtime) }
        else { pager.replace(document, now: now) }
        showingTranslation = true
        synchronize()
    }

    func setWaitingForInput(_ value: Bool) {
        guard waitingForInput != value else { return }
        waitingForInput = value
        render()
    }

    func setAudioStatus(_ text: String?) {
        guard audioStatus != text else { return }
        audioStatus = text
        render()
    }

    func setRecoveryStatus(_ text: String?) {
        guard recoveryStatus != text else { return }
        recoveryStatus = text; render()
    }
    func setCaptureStatus(_ text: String?) {
        guard captureStatus != text else { return }
        captureStatus = text; render()
    }

    func previousPage() { pager.move(-1, now: now); synchronize() }
    func configurePageSeconds(_ seconds: Double) { pager.configure(seconds: seconds, now: now); synchronize() }
    func nextPage() { pager.move(1, now: now); synchronize() }
    func toggleAutoPaging() { setAutoPaging(!pager.playing) }
    func showLatest() { pager.latest(now: now); synchronize() }

    private func setAutoPaging(_ value: Bool) {
        pager.setPlaying(value, now: now)
        synchronize()
    }

    private func tick() {
        if pager.tick(now: now) { synchronize() }
        else { render() } // Keep status visible even when reading is paused.
    }

    private func synchronize() {
        pageNumber = pager.page + 1
        pageCount = pager.document.pageCount
        autoPaging = pager.playing
        hasPendingCaption = pager.pending != nil
        fullText = pager.document.text
        surface.displayLayer.flush()
        if let timebase {
            CMTimebaseSetTime(timebase, time: CMTime(seconds: pager.playbackTime(now: now),
                                                    preferredTimescale: 600))
            CMTimebaseSetRate(timebase, rate: pager.playing ? SubtitlePager.timelineSecondsPerPage / pager.dwellSeconds : 0)
        }
        controller?.invalidatePlaybackState()
        render()
    }

    func start() {
        guard possible else { onError?("画中画尚未就绪，请等待预览出现；确认系统已允许画中画。"); return }
        controller?.startPictureInPicture()
    }

    func stop() {
        controller?.stopPictureInPicture()
        timer?.invalidate()
        timer = nil
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }

    private func render() {
        let width = Int(SubtitleDocument.canvasSize.width), height = Int(SubtitleDocument.canvasSize.height)
        var output: CVPixelBuffer?
        let attrs: [CFString: Any] = [kCVPixelBufferCGImageCompatibilityKey: true,
                                     kCVPixelBufferCGBitmapContextCompatibilityKey: true,
                                     kCVPixelBufferIOSurfacePropertiesKey: [:]]
        guard CVPixelBufferCreate(kCFAllocatorDefault, width, height, kCVPixelFormatType_32BGRA,
                                 attrs as CFDictionary, &output) == kCVReturnSuccess,
              let pixels = output else { return }
        CVPixelBufferLockBaseAddress(pixels, [])
        defer { CVPixelBufferUnlockBaseAddress(pixels, []) }
        guard let cg = CGContext(data: CVPixelBufferGetBaseAddress(pixels), width: width, height: height,
                                  bitsPerComponent: 8, bytesPerRow: CVPixelBufferGetBytesPerRow(pixels),
                                  space: CGColorSpaceCreateDeviceRGB(),
                                  bitmapInfo: CGBitmapInfo.byteOrder32Little.rawValue | CGImageAlphaInfo.premultipliedFirst.rawValue) else { return }
        cg.translateBy(x: 0, y: CGFloat(height))
        cg.scaleBy(x: 1, y: -1)
        UIGraphicsPushContext(cg)
        var footer = pager.playing ? "自动翻页 · 每页 \(Int(pager.dwellSeconds)) 秒" : "字幕已暂停 · 点播放继续"
        if let recoveryStatus { footer = recoveryStatus }
        else if let captureStatus { footer = captureStatus }
        else if !pager.playing, pager.pending != nil { footer = "有新字幕 · 已暂停，点播放继续" }
        else if let audioStatus { footer += " · \(audioStatus)" }
        else if pager.pending != nil { footer += " · 有新译文等候" }
        else if waitingForInput { footer += " · 等待新内容，保留上一段" }
        let headline = recoveryStatus != nil ? "网络中断 · 正在自动恢复"
            : captureStatus != nil ? "录屏连接中断 · 正在重连"
            : !pager.playing ? "字幕已暂停 · 点播放继续"
            : audioStatus == "音轨接近静音" ? "等待声音 · 当前音轨接近静音"
            : audioStatus == "未收到应用音轨" ? "等待声音 · 未收到应用音轨"
            : pager.document.provisional ? "泰语 → 中文 · 临时译文，可能修正" : title
        pager.document.draw(page: pager.page, title: headline,
                            footer: footer)
        UIGraphicsPopContext()

        var format: CMVideoFormatDescription?
        guard CMVideoFormatDescriptionCreateForImageBuffer(allocator: kCFAllocatorDefault, imageBuffer: pixels,
                                                           formatDescriptionOut: &format) == noErr, let format else { return }
        var timing = CMSampleTimingInfo(duration: CMTime(value: 1, timescale: 1),
                                        presentationTimeStamp: timebase.map { CMTimebaseGetTime($0) } ?? .zero,
                                        decodeTimeStamp: .invalid)
        var sample: CMSampleBuffer?
        guard CMSampleBufferCreateReadyWithImageBuffer(allocator: kCFAllocatorDefault, imageBuffer: pixels,
                                                       formatDescription: format, sampleTiming: &timing,
                                                       sampleBufferOut: &sample) == noErr, let sample else { return }
        if surface.displayLayer.status == .failed { surface.displayLayer.flush() }
        if surface.displayLayer.isReadyForMoreMediaData { surface.displayLayer.enqueue(sample) }
    }

    func pictureInPictureController(_ controller: AVPictureInPictureController, setPlaying playing: Bool) {
        setAutoPaging(playing)
    }
    func pictureInPictureControllerTimeRangeForPlayback(_ controller: AVPictureInPictureController) -> CMTimeRange {
        CMTimeRange(start: .zero, duration: CMTime(seconds: Double(pager.document.pageCount) * SubtitlePager.timelineSecondsPerPage,
                                                  preferredTimescale: 600))
    }
    func pictureInPictureControllerIsPlaybackPaused(_ controller: AVPictureInPictureController) -> Bool { !pager.playing }
    func pictureInPictureController(_ controller: AVPictureInPictureController,
                                    didTransitionToRenderSize newRenderSize: CMVideoDimensions) {}
    func pictureInPictureController(_ controller: AVPictureInPictureController, skipByInterval skipInterval: CMTime,
                                    completion completionHandler: @escaping () -> Void) {
        let seconds = CMTimeGetSeconds(skipInterval)
        if seconds.isFinite, seconds != 0 { pager.move(seconds > 0 ? 1 : -1, now: now); synchronize() }
        completionHandler()
    }
    func pictureInPictureControllerDidStartPictureInPicture(_ controller: AVPictureInPictureController) { active = true }
    func pictureInPictureControllerDidStopPictureInPicture(_ controller: AVPictureInPictureController) {
        active = false
        onStopped?()
    }
    func pictureInPictureController(_ controller: AVPictureInPictureController,
                                    failedToStartPictureInPictureWithError error: Error) {
        active = false
        onError?("字幕窗口未能启动：\(error.localizedDescription)")
    }
    func pictureInPictureController(_ controller: AVPictureInPictureController,
                                    restoreUserInterfaceForPictureInPictureStopWithCompletionHandler completionHandler: @escaping (Bool) -> Void) {
        completionHandler(true)
    }
}
