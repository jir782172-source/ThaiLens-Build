import Foundation

// Only numeric timing metadata is retained, never response bodies or credentials.
struct ServiceRateLimit: LocalizedError {
    let retryAfter: TimeInterval?
    var errorDescription: String? { "免费额度暂时受限，正在等待自动恢复。" }

    static func from(_ response: HTTPURLResponse, now: Date = Date()) -> Self {
        var waits: [Double] = []
        if let raw = response.value(forHTTPHeaderField: "retry-after") {
            if let seconds = Double(raw), seconds.isFinite, seconds >= 0 { waits.append(seconds) }
            else {
                let formatter = DateFormatter()
                formatter.locale = Locale(identifier: "en_US_POSIX")
                formatter.timeZone = TimeZone(secondsFromGMT: 0)
                formatter.dateFormat = "EEE, dd MMM yyyy HH:mm:ss zzz"
                if let date = formatter.date(from: raw) { waits.append(max(0, date.timeIntervalSince(now))) }
            }
        }
        for dimension in ["requests", "tokens"] {
            if let raw = response.value(forHTTPHeaderField: "x-ratelimit-remaining-\(dimension)"),
               let remaining = Double(raw), remaining <= 0,
               let reset = response.value(forHTTPHeaderField: "x-ratelimit-reset-\(dimension)"),
               let seconds = duration(reset) { waits.append(seconds) }
        }
        return Self(retryAfter: waits.max().map { max(1, $0) })
    }

    static func duration(_ raw: String) -> TimeInterval? {
        let text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if let seconds = Double(text) { return seconds.isFinite && seconds >= 0 ? seconds : nil }
        let pattern = #"([0-9]+(?:\.[0-9]+)?)(ms|s|m|h|d)"#
        guard let regex = try? NSRegularExpression(pattern: pattern) else { return nil }
        let ns = text as NSString
        let matches = regex.matches(in: text, range: NSRange(location: 0, length: ns.length))
        var end = 0, total = 0.0
        let factors = ["ms": 0.001, "s": 1.0, "m": 60.0, "h": 3600.0, "d": 86400.0]
        for match in matches {
            guard match.range.location == end,
                  let value = Double(ns.substring(with: match.range(at: 1))),
                  let factor = factors[ns.substring(with: match.range(at: 2))] else { return nil }
            total += value * factor; end = NSMaxRange(match.range)
        }
        return !matches.isEmpty && end == ns.length && total.isFinite ? total : nil
    }

    static func countdown(_ seconds: TimeInterval) -> String {
        let seconds = Int(min(315_360_000, max(1, ceil(seconds))))
        if seconds >= 3600 { return "约 \((seconds + 3599) / 3600) 小时" }
        if seconds >= 60 { return "\(seconds / 60) 分 \(seconds % 60) 秒" }
        return "\(seconds) 秒"
    }
}
