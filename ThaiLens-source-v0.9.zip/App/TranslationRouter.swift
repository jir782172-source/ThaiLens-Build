import Foundation

// Fixed model allowlist on the same Groq account; no new provider, key or billing action.
enum TranslationEngine: String, CaseIterable {
    case qwen = "qwen/qwen3.8-27b"
    case backup = "openai/gpt-oss-120b"
    var title: String { self == .qwen ? "Qwen" : "GPT-OSS 120B（备用）" }
}

struct RoutedTranslation {
    let text: String
    let engine: TranslationEngine
}

@MainActor
final class TranslationRouter {
    private let client: CloudTranslator
    private let now: () -> TimeInterval
    private struct Cooldown { var until: TimeInterval; var failures: Int }
    private var cooldowns: [TranslationEngine: Cooldown] = [:]
    var onSwitch: ((String) -> Void)?

    init(client: CloudTranslator = CloudTranslator(),
         now: @escaping () -> TimeInterval = { ProcessInfo.processInfo.systemUptime }) {
        self.client = client; self.now = now
    }

    func translate(_ text: String, apiKey: String, configuration: TranslationConfiguration,
                   partner: PartnerPreference, isCurrent: () -> Bool = { true }) async throws -> RoutedTranslation {
        for engine in TranslationEngine.allCases {
            try Task.checkCancellation()
            guard isCurrent() else { throw RecoverySkip.superseded }
            if (cooldowns[engine]?.until ?? 0) > now() { continue }
            if engine == .backup { onSwitch?("主模型暂不可用 · 正在切换免费备用模型") }
            do {
                let translated = try await client.translate(text, apiKey: apiKey,
                    configuration: configuration, partner: partner, engine: engine)
                cooldowns.removeValue(forKey: engine)
                return RoutedTranslation(text: translated, engine: engine)
            } catch let error as ServiceRateLimit {
                let failures = min((cooldowns[engine]?.failures ?? 0) + 1, 5)
                let delay = error.retryAfter ?? min(900, 60 * pow(2, Double(failures - 1)))
                cooldowns[engine] = Cooldown(until: now() + max(1, delay), failures: failures)
            } catch TranslationFailure.unavailable {
                cooldowns[engine] = Cooldown(until: now() + 300, failures: 1)
            }
        }
        let remaining = cooldowns.values.map { max(1, $0.until - now()) }.min() ?? 60
        throw ServiceRateLimit(retryAfter: remaining)
    }
}
