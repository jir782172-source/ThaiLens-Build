import Foundation

// Only ReplayKit app audio: no Apple Speech and no microphone fallback.
@MainActor
final class ThaiSpeech {
    var onText: ((SpeechUpdate) -> Void)?
    var onError: ((Error) -> Void)?
    var onNotice: ((String) -> Void)?
    private let client: GroqSpeechClient
    private let recovery: NetworkRecovery?
    private var segmenter = SpeechSegmenter()
    private var generation = UUID()
    private var enabled = false
    private var apiKey = ""
    private var pending: SpeechAudioWindow?
    private var task: Task<Void, Never>?
    private var lastAttempt: TimeInterval = -.infinity
    private var budget = SpeechBudget.load()
    private var previousGroup: UUID?
    private var previousText = ""
    private var groupPrefix = ""
    var processing: Bool { task != nil }

    init(client: GroqSpeechClient = GroqSpeechClient(), recovery: NetworkRecovery? = nil) {
        self.client = client; self.recovery = recovery
    }
    func start(apiKey: String) throws {
        stop()
        try GroqSpeechClient.validateKey(apiKey)
        self.apiKey = apiKey
        enabled = true
    }
    func append(_ chunk: PCMChunk) {
        guard enabled, chunk.isValid else { return }
        // Do not collect a backlog during a known outage. Fresh speech resumes on reconnection.
        if recovery?.available == false || recovery?.isCoolingDown(.speech) == true || recovery?.isCoolingDown(.translation) == true {
            segmenter = SpeechSegmenter(); pending = nil
            return
        }
        let result = segmenter.append(chunk)
        if result.discontinuity {
            generation = UUID()
            task?.cancel(); task = nil; pending = nil
            previousGroup = nil; previousText = ""; groupPrefix = ""
            onNotice?("音频有丢帧或格式改变，已重新接续；缺失的声音无法识别")
        }
        if let window = result.window {
            if let old = pending, old.group != window.group {
                onNotice?("网络识别跟不上声音，已跳过积压段落；请检查网络")
            }
            pending = window
            launch()
        }
    }
    func stop() {
        enabled = false
        generation = UUID()
        task?.cancel(); task = nil
        pending = nil; apiKey = ""
        segmenter = SpeechSegmenter()
        previousGroup = nil; previousText = ""; groupPrefix = ""
        // Preserve rate limits across restarts.
    }
    private func launch() {
        guard enabled, task == nil, pending != nil else { return }
        let id = generation
        task = Task { [weak self] in
            guard let self else { return }
            defer {
                if generation == id {
                    task = nil
                    if enabled { launch() }
                }
            }
            do {
                let delay = max(0, 6 - (ProcessInfo.processInfo.systemUptime - lastAttempt))
                if delay > 0 { try await Task.sleep(for: .seconds(delay)) }
                guard enabled, generation == id, let window = pending else { return }
                pending = nil
                let selectedAt = ProcessInfo.processInfo.systemUptime
                let operation = { [self] () async throws -> GroqSpeechClient.Result in
                    let delay = max(0, 6 - (ProcessInfo.processInfo.systemUptime - self.lastAttempt))
                    if delay > 0 { try await Task.sleep(for: .seconds(delay)) }
                    try Task.checkCancellation()
                    guard self.enabled, self.generation == id else { throw CancellationError() }
                    guard ProcessInfo.processInfo.systemUptime - selectedAt < 25 else { throw RecoverySkip.superseded }
                    let budgetNow = Date().timeIntervalSince1970
                    do { try self.budget.reserve(duration: window.duration, now: budgetNow) }
                    catch SpeechFailure.localLimit {
                        throw ServiceRateLimit(retryAfter: self.budget.retryDelay(duration: window.duration, now: budgetNow))
                    }
                    self.budget.save()
                    self.lastAttempt = ProcessInfo.processInfo.systemUptime
                    self.onNotice?("Whisper Large V3 正在联网识别泰语…")
                    return try await self.client.transcribe(window, apiKey: self.apiKey)
                }
                let result: GroqSpeechClient.Result
                if let recovery {
                    result = try await recovery.perform(channel: .speech, isCurrent: { [self] in
                        self.enabled && self.generation == id && ProcessInfo.processInfo.systemUptime - selectedAt < 25 &&
                        (self.pending == nil || self.pending?.group == window.group)
                    }, operation: operation)
                } else { result = try await operation() }
                guard enabled, generation == id, !Task.isCancelled else { return }
                if !result.text.isEmpty {
                    if previousGroup != window.group {
                        groupPrefix = window.overlapsPrevious ? previousText : ""
                    }
                    let text = SpeechOverlap.removingRepeatedPrefix(result.text, previous: groupPrefix)
                    previousGroup = window.group
                    previousText = result.text
                    onText?(SpeechUpdate(group: window.group, revision: window.revision,
                                         text: text, isFinal: window.isFinal, uncertain: result.uncertain))
                    if result.uncertain { onNotice?("本段声音较难辨认，请核对泰文原句；未必识别正确") }
                } else {
                    onText?(SpeechUpdate(group: window.group, revision: window.revision,
                                         text: "", isFinal: true, uncertain: true))
                    onNotice?("本段未识别出可靠泰语；没有把静音或噪声当成字幕")
                }
            } catch is RecoverySkip {
                return // Defer schedules the freshest pending segment, if any.
            } catch is CancellationError { return }
            catch {
                guard enabled, generation == id, !Task.isCancelled else { return }
                stop()
                onError?(error)
            }
        }
    }
}
