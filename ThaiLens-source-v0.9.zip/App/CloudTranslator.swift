import Foundation
import Security

enum TranslationFailure: LocalizedError {
    case missingKey, unauthorized, quota, payment, unavailable, invalidResponse, truncated, inputTooLong, nonChinese
    case server(Int)
    var errorDescription: String? {
        switch self {
        case .missingKey: return "请先保存 Groq API Key（gsk_ 开头），与语音识别共用。"
        case .unauthorized: return "Groq 密钥无效或账号无权限。请检查密钥、地区及免费模型权限。"
        case .quota: return "免费服务已限流，翻译已停止。请稍后手动重试；不会切换付费模型。"
        case .payment: return "服务返回余额或付费限制，翻译已停止。请核实免费模型状态，不必充值。"
        case .unavailable: return "Groq Qwen 翻译模型当前不可用，请检查账户的免费模型权限。"
        case .invalidResponse: return "翻译服务未返回有效译文，请稍后重试。"
        case .truncated: return "服务返回的译文不完整，已丢弃，避免显示错误字幕。"
        case .inputTooLong: return "这一段文字过长，未截断后强行翻译。请缩短当前画面内容或重新开始一段语音。"
        case .nonChinese: return "模型返回了泰文或推理内容，已丢弃，避免把原文当作中文字幕。请重试。"
        case .server(let code): return "翻译服务暂时异常（HTTP \(code)）。"
        }
    }
}

enum APIKeyStore {
    private static func query(account: String) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: "ThaiLens.SiliconFlow", kSecAttrAccount as String: account]
    }
    static func load(account: String = "translation-api-key") -> String {
        var q = query(account: account)
        q[kSecReturnData as String] = true
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return "" }
        return String(data: data, encoding: .utf8) ?? ""
    }
    static func save(_ raw: String, account: String = "translation-api-key") throws {
        let query = query(account: account)
        let key = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty, !key.contains(where: { $0.isWhitespace }) else { throw TranslationFailure.missingKey }
        let values: [String: Any] = [kSecValueData as String: Data(key.utf8),
                                    kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly]
        var status = SecItemUpdate(query as CFDictionary, values as CFDictionary)
        if status == errSecItemNotFound {
            status = SecItemAdd(query.merging(values) { _, new in new } as CFDictionary, nil)
        }
        guard status == errSecSuccess else {
            throw NSError(domain: NSOSStatusErrorDomain, code: Int(status),
                          userInfo: [NSLocalizedDescriptionKey: "密钥无法保存到钥匙串（\(status)），请检查重签配置。"])
        }
    }
    static func remove(account: String = "translation-api-key") throws {
        let query = query(account: account)
        let status = SecItemDelete(query as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else {
            throw NSError(domain: NSOSStatusErrorDomain, code: Int(status),
                          userInfo: [NSLocalizedDescriptionKey: "密钥删除失败（\(status)）。"])
        }
    }
}

private final class NoTranslationRedirects: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}

// Only the user's Groq Free account. No automatic provider or paid-plan fallback.
struct CloudTranslator {
    static let model = "qwen/qwen3.8-27b"
    static let keyAccount = GroqSpeechClient.keyAccount
    static let endpoint = URL(string: "https://api.groq.com/openai/v1/chat/completions")!
    private let session: URLSession
    init(session: URLSession? = nil) {
        if let session { self.session = session }
        else {
            let configuration = URLSessionConfiguration.ephemeral
            configuration.urlCache = nil
            configuration.httpCookieStorage = nil
            configuration.waitsForConnectivity = true
            configuration.allowsCellularAccess = true
            configuration.timeoutIntervalForRequest = 20
            configuration.timeoutIntervalForResource = 25
            self.session = URLSession(configuration: configuration, delegate: NoTranslationRedirects(), delegateQueue: nil)
        }
    }
    struct Message: Codable { let role: String; let content: String }
    struct Body: Encodable {
        let model = CloudTranslator.model
        let messages: [Message]
        let stream = false
        let temperature = 0.6
        let top_p = 0.95
        let reasoning_effort = "default"
        let reasoning_format = "hidden"
        let max_completion_tokens = 2048
    }
    struct Response: Decodable {
        struct Choice: Decodable {
            struct Message: Decodable { let content: String? }
            let message: Message
            let finish_reason: String?
        }
        let choices: [Choice]
    }
    static func request(text: String, apiKey: String,
                        configuration: TranslationConfiguration = .builtIn,
                        partner: PartnerPreference = .neutral) throws -> URLRequest {
        let key = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard key.hasPrefix("gsk_"), key.count > 12, !key.contains(where: { $0.isWhitespace }) else { throw TranslationFailure.missingKey }
        guard text.count <= 4000 else { throw TranslationFailure.inputTooLong }
        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        // Keep the complete source. Use the tested Qwen prompt; r1/r2 Hunyuan rules
        // remain readable by old apps and cannot replace model-specific instructions.
        var instructions = configuration.qwenPrompt ?? TranslationConfiguration.qwenDefaultPrompt
        if !partner.instruction.isEmpty { instructions += "\n" + partner.instruction }
        if !configuration.glossary.isEmpty {
            instructions += "\n术语参考（以原文语境为准）：\n" + configuration.glossary
                .map { "\($0.thai)：\($0.chinese)" }.joined(separator: "\n")
        }
        let prompt = instructions + "\n\n" + text
        request.httpBody = try JSONEncoder().encode(Body(messages: [Message(role: "user", content: prompt)]))
        return request
    }
    static func decode(_ data: Data, status: Int) throws -> String {
        switch status {
        case 200...299: break
        case 401, 403: throw TranslationFailure.unauthorized
        case 402: throw TranslationFailure.payment
        case 404, 410: throw TranslationFailure.unavailable
        case 429: throw TranslationFailure.quota
        default: throw TranslationFailure.server(status)
        }
        guard data.count < 1_000_000,
              let result = try? JSONDecoder().decode(Response.self, from: data),
              let choice = result.choices.first else { throw TranslationFailure.invalidResponse }
        guard choice.finish_reason == "stop" else { throw TranslationFailure.truncated }
        guard let text = choice.message.content?.trimmingCharacters(in: .whitespacesAndNewlines),
              !text.isEmpty, text.count <= 3000 else { throw TranslationFailure.invalidResponse }
        guard !text.unicodeScalars.contains(where: { (0x0E00...0x0E7F).contains($0.value) }),
              !text.lowercased().contains("<think>"), !text.lowercased().contains("</think>") else {
            throw TranslationFailure.nonChinese
        }
        return text
    }
    func translate(_ text: String, apiKey: String,
                   configuration: TranslationConfiguration = .builtIn,
                   partner: PartnerPreference = .neutral) async throws -> String {
        try Task.checkCancellation()
        let (data, response) = try await session.data(for: Self.request(text: text, apiKey: apiKey,
                                                        configuration: configuration, partner: partner))
        try Task.checkCancellation()
        guard let http = response as? HTTPURLResponse else { throw TranslationFailure.invalidResponse }
        return try Self.decode(data, status: http.statusCode)
    }
}

struct TranslationExample: Identifiable {
    let id: Int
    let thai: String
    let meaning: String
    static let samples = [
        TranslationExample(id: 0, thai: "ไม่เป็นไร ไว้เจอกันวันหลังก็ได้", meaning: "没关系，改天再见也可以。"),
        TranslationExample(id: 1, thai: "อย่าเพิ่งโอนนะ ยังไม่ได้ตกลงราคา", meaning: "先别转账，价格还没谈好。"),
        TranslationExample(id: 2, thai: "เกรงใจอะ ไม่อยากรบกวนตอนดึก", meaning: "有点不好意思，不想大晚上打扰你。"),
        TranslationExample(id: 3, thai: "วันนี้ไม่ไหวแล้ว ขอนอนก่อนนะ 555", meaning: "今天撑不住了，我先睡啦，哈哈。"),
        TranslationExample(id: 4, thai: "แฟนสาวของคุณอยู่ที่ไหน", meaning: "你的女朋友在哪里？不能翻成男朋友或他的女朋友。"),
        TranslationExample(id: 5, thai: "ฉันอยากคุยกับคุณ ไม่ใช่เขา", meaning: "我想和你聊，不是和那个人聊。保留我、你、第三人的区别。"),
        TranslationExample(id: 6, thai: "คุณมีแฟนหรือยัง", meaning: "你有对象了吗？แฟน 本身未明确男女；如补充了女朋友语境，可据此表达。")
    ]
}
