import SwiftUI

@MainActor
final class SessionModel: ObservableObject {
    @Published var mode = CaptureMode.screen
    @Published var speechConsent = false
    @Published var speechKeySaved = !APIKeyStore.load(account: GroqSpeechClient.keyAccount).isEmpty
    @Published var speechSetupStatus = "请保存 Groq 免费账户的语音识别密钥"
    @Published var running = false
    @Published var ready = false
    @Published var connected = false
    @Published var status = "选择要翻译的内容，然后准备翻译"
    @Published var sourceText = ""
    @Published var translatedText = ""
    @Published var receivedCount = 0
    @Published var translationCount = 0
    @Published var keySaved = !APIKeyStore.load(account: CloudTranslator.keyAccount).isEmpty
    @Published var cloudConsent = false
    @Published var testing = false
    @Published var testResults: [Int: String] = [:]
    @Published var setupStatus = "Qwen 3.8 27B · 使用 Groq Free Plan · 与语音识别共用密钥"
    @Published var audioInputState = AudioInputState.waiting
    @Published var audioLevel: Float = 0
    @Published var lastTranslationSeconds: Double?
    @Published var lastTranslationCached = false
    @Published var partnerPreference = PartnerPreference.neutral
    @Published var realtimeCorrections = true
    @Published var provisionalTranslation = false
    @Published var translationWarning = ""
    private var recognitionUncertain = false
    private var reviewedTranslation: String {
        translationWarning.isEmpty ? translatedText : "⚠ " + translationWarning + "\n" + translatedText
    }
    let updates = ConfigurationUpdates()
    let window = SubtitleWindow()
    let diagnostics = Diagnostics()
    private let server = CaptureServer()
    private let recovery = NetworkRecovery()
    private lazy var speech = ThaiSpeech(recovery: recovery)
    @Published private(set) var recoveryStatus = ""
    private var broadcastLostAt: Date?
    private let ocr = ThaiOCR()
    private let translator = CloudTranslator()
    private var runTask: Task<Void, Never>?
    private var testTask: Task<Void, Never>?
    private var apiKey = ""
    private var cache: [String: String] = [:]
    private var inputEpoch = UUID()
    private var textChangedAt = Date.distantPast
    private var runID = UUID()
    private var recognizingImage = false
    private var pendingText = ""
    private var lastTranslated = ""
    private var lastInput = Date.distantPast
    private var lastAttempt = Date.distantPast
    private var silenceWarned = false
    private var pendingSince: Date?
    private var pendingIsFinal = false
    private var audioHealth = AudioHealth()
    private var healthTask: Task<Void, Never>?
    private var lastAudioDiagnostic: TimeInterval = -.infinity
    private var speechGroup: UUID?
    private var speechRevision = 0
    private var lastTranslatedGroup: UUID?
    private var activeConfiguration = TranslationConfiguration.builtIn

    init() {
        recovery.onStatus = { [weak self] message in
            guard let self else { return }
            recoveryStatus = message ?? ""
            window.setRecoveryStatus(message)
        }
        recovery.onTransient = { [weak self] channel, error in
            guard let self, running else { return }
            diagnostics.record(channel == .speech ? .speech : .translation, mode: mode, error: error)
        }
        server.onReady = { [weak self] in
            self?.ready = true
            self?.status = "已准备。开启字幕窗口，再开启屏幕广播。"
        }
        server.onStatus = { [weak self] message in self?.status = message }
        server.onFailure = { [weak self] error in self?.fail(.localConnection, error) }
        server.onPacket = { [weak self] packet in self?.receive(packet) }
        speech.onText = { [weak self] update in
            guard let self else { return }
            audioHealth.recognized(now: ProcessInfo.processInfo.systemUptime)
            speechGroup = update.group
            speechRevision = update.revision
            recognitionUncertain = update.uncertain
            accept(update.text, isFinal: update.isFinal)
        }
        speech.onError = { [weak self] error in self?.fail(.speech, error) }
        speech.onNotice = { [weak self] message in self?.status = message }
        window.onError = { [weak self] message in
            self?.diagnostics.record(.subtitleWindow, mode: self?.mode ?? .screen)
            self?.status = message
        }
        window.onStopped = { [weak self] in
            guard let self, running else { return }
            stop(message: "字幕窗口已关闭，翻译与采集已停止")
        }
    }

    func prepare() async {
        guard !running, !testing else { return }
        guard cloudConsent else { status = "请先同意将识别出的泰文发给 Groq 翻译，并确认使用 Free Plan。"; return }
        apiKey = APIKeyStore.load(account: CloudTranslator.keyAccount)
        guard !apiKey.isEmpty else { status = "请先在翻译设置里保存 API Key。"; return }
        running = true
        recovery.start()
        broadcastLostAt = nil
        runID = UUID()
        let id = runID
        status = "正在检查可用的翻译配置…"
        await updates.check()
        guard running, id == runID else { return }
        activeConfiguration = updates.effective
        window.configurePageSeconds(activeConfiguration.pageSeconds)
        status = "正在准备 Qwen 泰语 → 中文翻译…"
        receivedCount = 0
        translationCount = 0
        lastTranslationSeconds = nil
        lastTranslationCached = false
        pendingSince = nil
        pendingIsFinal = false
        audioInputState = .waiting
        audioLevel = 0
        lastAudioDiagnostic = -.infinity
        speechGroup = nil
        speechRevision = 0
        lastTranslatedGroup = nil
        provisionalTranslation = false
        cache.removeAll()
        inputEpoch = UUID()
        lastAttempt = .distantPast
        if mode == .audio {
            guard speechConsent else { stop(message: "请先同意将应用声音发给 Groq，并确认使用 Free Plan。"); return }
            do { try speech.start(apiKey: APIKeyStore.load(account: GroqSpeechClient.keyAccount)) }
            catch { fail(.speech, error); return }
        }
        guard running, id == runID else { return }
        runTask = Task { [weak self] in
            guard let self else { return }
            await self.run()
        }
    }

    private func run() async {
        guard running else { return }
        let id = runID
        var stage = DiagnosticStage.subtitleWindow
        do {
            guard running, runID == id, !Task.isCancelled else { return }
            try window.prepare()
            window.show("开启屏幕广播后，切换到 YeeTalk、微信或 Instagram")
            stage = .localConnection
            try server.start(mode: mode)
            if mode == .audio { startAudioHealthMonitor() }
            stage = .translation
            while running, id == runID, !Task.isCancelled {
                try await Task.sleep(for: .milliseconds(250))
                let now = Date()
                let configuration = updates.effective
                if configuration != activeConfiguration {
                    activeConfiguration = configuration
                    cache.removeAll()
                    window.configurePageSeconds(configuration.pageSeconds)
                }
                if let lost = broadcastLostAt, now.timeIntervalSince(lost) >= 30 {
                    stop(message: "屏幕广播连接已中断。请重新点广播按钮开始；系统录屏不能由应用擅自重开。")
                    return
                }
                if connected, now.timeIntervalSince(lastInput) > 8, !silenceWarned {
                    silenceWarned = true
                    let message = mode == .audio ? "未收到应用声音；通话或播放内容可能不允许采集" : "未收到画面，请检查屏幕广播"
                    status = message
                    diagnostics.record(.broadcast, mode: mode)
                    if translatedText.isEmpty { window.show(message) }
                    else { window.setWaitingForInput(true) }
                    pendingText = ""
                    pendingSince = nil
                    pendingIsFinal = false
                    inputEpoch = UUID()
                }
                let candidate = pendingText
                let key = TextTools.normalized(candidate)
                guard !key.isEmpty, key != lastTranslated || (mode == .audio && speechGroup != lastTranslatedGroup),
                      TranslationPacing.isReady(mode: mode, now: now.timeIntervalSinceReferenceDate,
                        lastAttempt: lastAttempt.timeIntervalSinceReferenceDate,
                        pendingSince: (pendingSince ?? textChangedAt).timeIntervalSinceReferenceDate,
                        lastChange: textChangedAt.timeIntervalSinceReferenceDate,
                        isFinal: pendingIsFinal, configuration: activeConfiguration) else { continue }
                lastAttempt = now
                pendingSince = nil
                let epoch = inputEpoch
                let candidateGroup = mode == .audio ? speechGroup : nil
                let response: String
                let cachedResult = cache[key]
                let requestStarted = ProcessInfo.processInfo.systemUptime
                if let cached = cachedResult { response = cached }
                else {
                    do {
                        response = try await recovery.perform(channel: .translation, isCurrent: { [self] in
                            running && runID == id && connected && inputEpoch == epoch && !pendingText.isEmpty &&
                            (mode == .audio ? speechGroup == candidateGroup : TextTools.normalized(pendingText) == key)
                        }) { [self] in
                            try await translator.translate(candidate, apiKey: apiKey,
                                configuration: activeConfiguration, partner: partnerPreference)
                        }
                    } catch is RecoverySkip { continue }
                    guard running, runID == id, !Task.isCancelled else { return }
                    if cache.count >= 128 { cache.removeAll(keepingCapacity: true) }
                    cache[key] = response
                }
                guard running, runID == id, !Task.isCancelled else { return }
                // A blank screen or disconnected broadcast must not revive an old subtitle.
                guard connected, inputEpoch == epoch, !pendingText.isEmpty else { continue }
                if mode == .screen, TextTools.normalized(pendingText) != key { continue }
                if mode == .audio, !TranscriptRevision.canDisplay(candidate: candidate, current: pendingText,
                                            candidateGroup: candidateGroup, currentGroup: speechGroup) { continue }
                translatedText = response
                translationWarning = TranslationReview.warning(source: candidate, chinese: response)
                    ?? (mode == .audio && recognitionUncertain ? "本段语音识别不确定，请核对原句" : "")
                lastTranslationSeconds = ProcessInfo.processInfo.systemUptime - requestStarted
                lastTranslationCached = cachedResult != nil
                lastTranslated = key
                lastTranslatedGroup = candidateGroup
                provisionalTranslation = mode == .audio && !(pendingIsFinal && TextTools.normalized(pendingText) == key)
                if TextTools.normalized(pendingText) == key { pendingSince = nil }
                translationCount += 1
                window.showTranslation(reviewedTranslation, group: candidateGroup, provisional: provisionalTranslation,
                                       realtime: realtimeCorrections)
                status = "Qwen 翻译中 · \(mode == .screen ? "画面文字" : "应用声音") · 译文仍可能有误差"
            }
            if running, id == runID { stop(message: "翻译会话已结束，请重新准备") }
        } catch is CancellationError {
            if running, id == runID { stop(message: "翻译会话已结束，请重新准备") }
        } catch {
            if running, id == runID { fail(stage, error) }
        }
    }

    private func fail(_ stage: DiagnosticStage, _ error: Error) {
        diagnostics.record(stage, mode: mode, error: error)
        stop(message: DiagnosticEvent.userMessage(stage: stage, error: error))
    }

    func stop(message: String = "已停止翻译与采集") {
        running = false
        ready = false
        connected = false
        runID = UUID()
        recovery.stop()
        broadcastLostAt = nil
        runTask?.cancel()
        runTask = nil
        healthTask?.cancel()
        healthTask = nil
        window.setAudioStatus(nil)
        window.setCaptureStatus(nil)
        apiKey = ""
        cache.removeAll()
        inputEpoch = UUID()
        server.stop()
        speech.stop()
        window.stop()
        recognizingImage = false
        pendingText = ""
        pendingSince = nil
        pendingIsFinal = false
        speechGroup = nil
        lastTranslatedGroup = nil
        provisionalTranslation = false
        lastTranslated = ""
        sourceText = ""
        translatedText = ""
        translationWarning = ""
        recognitionUncertain = false
        status = message
        window.show(message)
    }

    private func receive(_ packet: WirePacket) {
        guard running else { return }
        switch packet.kind {
        case "hello", "resumed":
            let reconnecting = broadcastLostAt != nil
            broadcastLostAt = nil
            connected = true
            window.setCaptureStatus(nil)
            audioHealth.reset(now: ProcessInfo.processInfo.systemUptime)
            lastInput = Date()
            window.setWaitingForInput(false)
            silenceWarned = false
            status = "正在接收画面 / 声音，切换到目标软件即可"
            if (packet.kind == "resumed" || reconnecting), mode == .audio {
                do { try speech.start(apiKey: APIKeyStore.load(account: GroqSpeechClient.keyAccount)) }
                catch { fail(.speech, error) }
            }
        case "paused":
            inputEpoch = UUID()
            connected = false
            pendingText = ""
            pendingSince = nil
            pendingIsFinal = false
            audioInputState = .waiting
            audioLevel = 0
            window.setAudioStatus(mode == .audio ? "屏幕广播已暂停" : nil)
            translatedText = ""
            sourceText = ""
            lastTranslated = ""
            speech.stop()
            window.show("屏幕广播已暂停")
            status = "屏幕广播已暂停"
        case "linkLost":
            guard connected else { return }
            connected = false
            broadcastLostAt = Date()
            inputEpoch = UUID()
            pendingText = ""; pendingSince = nil; pendingIsFinal = false
            speech.stop()
            window.setCaptureStatus("录屏连接中断 · 正在自动重连")
            status = "正在重新连接屏幕广播，最多等待 30 秒"
            diagnostics.record(.broadcast, mode: mode)
        case "finished", "disconnected":
            diagnostics.record(.broadcast, mode: mode)
            stop(message: "屏幕广播已结束；未继续采集")
        case "image":
            guard mode == .screen, let data = packet.image, !recognizingImage else { return }
            lastInput = Date()
            window.setWaitingForInput(false)
            silenceWarned = false
            receivedCount += 1
            recognizingImage = true
            let id = runID
            Task {
                do {
                    let text = try await ocr.recognize(data)
                    guard running, id == runID else { return }
                    recognizingImage = false
                    guard connected else { return }
                    accept(text)
                } catch {
                    guard running, id == runID else { return }
                    recognizingImage = false
                    fail(.screenRecognition, error)
                }
            }
        case "audio":
            guard mode == .audio, let chunk = packet.pcm, chunk.isValid else { return }
            lastInput = Date()
            window.setWaitingForInput(false)
            silenceWarned = false
            receivedCount += 1
            audioHealth.receive(chunk, now: ProcessInfo.processInfo.systemUptime)
            speech.append(chunk)
        default: break
        }
    }

    private func accept(_ text: String, isFinal: Bool = false) {
        guard running, connected else { return }
        if text != pendingText {
            textChangedAt = Date()
            if pendingSince == nil { pendingSince = textChangedAt }
        }
        pendingIsFinal = isFinal
        sourceText = text
        pendingText = text
        if mode == .audio, isFinal, speechGroup == lastTranslatedGroup,
           TextTools.normalized(text) == lastTranslated, !translatedText.isEmpty {
            provisionalTranslation = false
            window.showTranslation(reviewedTranslation, group: speechGroup, provisional: false,
                                   realtime: realtimeCorrections)
        }
        if text.isEmpty {
            pendingSince = nil
            inputEpoch = UUID()
            translatedText = ""
            lastTranslated = ""
            translationWarning = ""
            status = mode == .audio ? "本段未识别出可靠泰语，请等待下一段" : "画面中未识别到泰文"
            window.show(status)
        }
    }

    private func startAudioHealthMonitor() {
        healthTask?.cancel()
        let id = runID
        healthTask = Task { [weak self] in
            while !Task.isCancelled {
                do { try await Task.sleep(for: .seconds(1)) } catch { return }
                guard let self, self.running, self.runID == id else { return }
                guard self.connected else { continue }
                let now = ProcessInfo.processInfo.systemUptime
                let measured = self.audioHealth.state(now: now)
                let state: AudioInputState = measured == .noRecognition && self.speech.processing ? .recognizing : measured
                self.audioInputState = state
                self.audioLevel = state == .receiving || state == .noRecognition || state == .recognizing ? self.audioHealth.peak : 0
                self.window.setAudioStatus(state.shortTitle)
                if let code = state.diagnosticCode, now - self.lastAudioDiagnostic >= 60 {
                    self.lastAudioDiagnostic = now
                    self.diagnostics.record(.audioCapture, mode: .audio,
                        error: NSError(domain: "ThaiLens", code: code))
                }
            }
        }
    }

    func saveSpeechKey(_ raw: String) {
        guard !running, !testing else { return }
        do {
            let key = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            try GroqSpeechClient.validateKey(key)
            try APIKeyStore.save(key, account: GroqSpeechClient.keyAccount)
            speechKeySaved = true
            keySaved = true
            speechSetupStatus = "Groq 密钥已保存到本机钥匙串。开始广播后才能验证真实语音连接。"
        } catch { speechSetupStatus = error.localizedDescription }
    }
    func removeSpeechKey() {
        guard !running, !testing else { return }
        do {
            try APIKeyStore.remove(account: GroqSpeechClient.keyAccount)
            speechKeySaved = false; keySaved = false; speechConsent = false; cloudConsent = false
            speechSetupStatus = "Groq 密钥已删除。"
        } catch { speechSetupStatus = error.localizedDescription }
    }

    func saveKey(_ raw: String) {
        guard !running, !testing else { return }
        do {
            let key = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            try GroqSpeechClient.validateKey(key)
            try APIKeyStore.save(key, account: CloudTranslator.keyAccount)
            keySaved = true
            speechKeySaved = true
            testResults.removeAll()
            setupStatus = "密钥已存入本机钥匙串。请运行口语样例检查连接与译文。"
        } catch {
            diagnostics.record(.keychain, mode: mode, error: error)
            setupStatus = error.localizedDescription
        }
    }

    func removeKey() {
        guard !running, !testing else { return }
        do {
            try APIKeyStore.remove(account: CloudTranslator.keyAccount)
            keySaved = false
            speechKeySaved = false
            speechConsent = false
            cloudConsent = false
            testResults.removeAll()
            setupStatus = "密钥已删除。"
        } catch { setupStatus = error.localizedDescription }
    }

    func cancelTest() {
        testTask?.cancel()
        testTask = nil
        testing = false
        setupStatus = "样例测试已取消。"
    }

    func testTranslation() {
        guard !running, !testing, cloudConsent else { return }
        let key = APIKeyStore.load(account: CloudTranslator.keyAccount)
        guard !key.isEmpty else { setupStatus = "请先保存 API Key。"; return }
        testing = true
        testResults.removeAll()
        setupStatus = "正在发送 7 条固定泰语样例，含女朋友与人称对照；不会采集屏幕或声音…"
        testTask = Task { [weak self] in
            guard let self else { return }
            do {
                for sample in TranslationExample.samples {
                    let text = try await self.translator.translate(sample.thai, apiKey: key,
                                      configuration: self.updates.effective, partner: self.partnerPreference)
                    try Task.checkCancellation()
                    self.testResults[sample.id] = text
                    try await Task.sleep(for: .seconds(3))
                }
                self.setupStatus = "连接成功。请对照参考含义检查译文；这不是准确率认证。"
            } catch is CancellationError { return }
            catch {
                guard !Task.isCancelled else { return }
                self.diagnostics.record(.translation, mode: self.mode, error: error)
                self.setupStatus = DiagnosticEvent.userMessage(stage: .translation, error: error)
            }
            self.testing = false
            self.testTask = nil
        }
    }
}
