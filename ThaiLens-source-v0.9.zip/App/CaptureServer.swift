import Foundation
import Network

final class CaptureServer {
    var onPacket: ((WirePacket) -> Void)?
    var onStatus: ((String) -> Void)?
    var onReady: (() -> Void)?
    var onFailure: ((Error) -> Void)?
    private var listener: NWListener?
    private var peers: [UUID: WirePeer] = [:]
    private var authenticated: UUID?
    private var mode = CaptureMode.screen
    private var generation = UUID()
    private var closingListeners: [UUID: NWListener] = [:]
    private var pendingStart: (() -> Void)?

    // Supply the numeric loopback address and port once. Passing a port again
    // to NWListener(using:on:) can conflict with requiredLocalEndpoint on iOS.
    static func makeListener(port: NWEndpoint.Port = Wire.port) throws -> NWListener {
        let parameters = NWParameters.tcp
        parameters.requiredLocalEndpoint = .hostPort(host: .ipv4(.loopback), port: port)
        parameters.allowLocalEndpointReuse = true
        return try NWListener(using: parameters)
    }

    func start(mode: CaptureMode) throws {
        stop()
        self.mode = mode
        let id = generation
        // cancel() is asynchronous. A replacement must wait for .cancelled,
        // otherwise even SO_REUSEADDR can still hit EADDRINUSE on the old port.
        if !closingListeners.isEmpty {
            pendingStart = { [weak self] in
                guard let self, self.generation == id else { return }
                do { try self.beginListener(generation: id) }
                catch { self.onFailure?(error) }
            }
        } else {
            try beginListener(generation: id)
        }
    }

    private func beginListener(generation id: UUID) throws {
        let listener = try Self.makeListener()
        self.listener = listener
        listener.stateUpdateHandler = { [weak self] state in
            guard let self, self.generation == id else { return }
            switch state {
            case .ready: self.onReady?()
            case .failed(let error): self.onFailure?(error)
            default: break
            }
        }
        listener.newConnectionHandler = { [weak self] connection in
            guard let self, self.generation == id else { connection.cancel(); return }
            self.accept(connection)
        }
        listener.start(queue: .main)
    }

    private func accept(_ connection: NWConnection) {
        guard peers.count < 3 else { connection.cancel(); return }
        let id = UUID()
        let peer = WirePeer(connection, queue: .main)
        peers[id] = peer
        peer.onPacket = { [weak self, weak peer] packet in
            guard let self, let peer else { return }
            if packet.kind == "hello", authenticated == nil {
                authenticated = id
                peer.send(WirePacket(kind: "configure", mode: mode))
                onStatus?("已连接屏幕广播")
            }
            guard authenticated == id else { return }
            if packet.kind == "ping" { peer.send(WirePacket(kind: "pong")); return }
            onPacket?(packet)
        }
        peer.onClose = { [weak self] _ in
            guard let self else { return }
            peers.removeValue(forKey: id)
            if authenticated == id {
                authenticated = nil
                onPacket?(WirePacket(kind: "linkLost"))
            }
        }
        peer.start()
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) { [weak self, weak peer] in
            guard let self, authenticated != id else { return }
            peer?.close("认证超时")
        }
    }

    func stop() {
        generation = UUID()
        pendingStart = nil
        if let retiring = listener {
            let closingID = UUID()
            closingListeners[closingID] = retiring
            retiring.newConnectionHandler = { $0.cancel() }
            retiring.stateUpdateHandler = { [weak self] state in
                guard let self, case .cancelled = state else { return }
                self.closingListeners.removeValue(forKey: closingID)
                if self.closingListeners.isEmpty {
                    let start = self.pendingStart
                    self.pendingStart = nil
                    start?()
                }
            }
            retiring.cancel()
        }
        listener = nil
        let oldPeers = Array(peers.values)
        peers.removeAll()
        authenticated = nil
        for peer in oldPeers {
            peer.onClose = nil
            peer.send(WirePacket(kind: "stop"))
            // Allow the stop message to drain; closure retains peer for this short interval.
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) { peer.close() }
        }
    }
}
