import Foundation

// Targeted consistency warnings, not automatic word replacement. These checks
// cannot detect every mistake or establish who a pronoun refers to.
enum TranslationReview {
    static func warning(source: String, chinese: String) -> String? {
        let female = source.contains("แฟนสาว")
        let male = source.contains("แฟนหนุ่ม")
        if female && !male && chinese.contains("男朋友") { return "关系称呼疑似翻错，请核对原句" }
        if male && !female && chinese.contains("女朋友") { return "关系称呼疑似翻错，请核对原句" }
        if source.contains("คุณ"), !source.contains("เขา"), !source.contains("เธอ"), !source.contains("ท่าน"),
           !chinese.contains("你"), !chinese.contains("您"), chinese.contains("他") || chinese.contains("她") {
            return "人称可能翻错，请核对原句"
        }
        return nil
    }
}
