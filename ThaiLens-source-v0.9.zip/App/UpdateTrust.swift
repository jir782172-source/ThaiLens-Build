// Public verification key only. The private key never enters the source archive.
import Foundation
enum UpdateTrust {
    static let publicKeyBase64 = "7/lwGn2DKKjGXUc82oSN3ILaDRCtG44cKLadPBNvj9c="
    static let issueNumber = 2
}
