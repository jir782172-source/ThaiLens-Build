import Foundation
import SwiftyTesseract

enum TextTools {
    static func thaiLines(_ text: String) -> String {
        let lines = text.components(separatedBy: .newlines).map {
            $0.trimmingCharacters(in: .whitespacesAndNewlines)
        }.filter { line in
            line.unicodeScalars.filter { (0x0E01...0x0E5B).contains($0.value) }.count >= 2
        }
        // Prefer recent chat bubbles at the bottom; cap work and subtitle height.
        return lines.suffix(5).joined(separator: "\n")
    }

    static func normalized(_ text: String) -> String {
        text.split(whereSeparator: { $0.isWhitespace }).joined(separator: " ")
    }
}

actor ThaiOCR {
    private var engine: Tesseract?

    func recognize(_ image: Data) throws -> String {
        if engine == nil {
            guard let url = Bundle.main.url(forResource: "tha", withExtension: "traineddata", subdirectory: "tessdata"),
                  let size = try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize, size > 100_000 else {
                throw NSError(domain: "ThaiLens", code: 2, userInfo: [NSLocalizedDescriptionKey: "安装包缺少泰文识别模型，请重新编译。"])
            }
            engine = Tesseract(language: .custom("tha")) {
                set("tessedit_pageseg_mode", value: .integer(11))
            }
        }
        guard let engine else { return "" }
        return TextTools.thaiLines(try engine.performOCR(on: image).get())
    }
}
