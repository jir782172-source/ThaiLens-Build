import Foundation

enum SpeechFailure: LocalizedError {
    case missingKey, unauthorized, quota, localLimit, payment, unavailable, invalidResponse, invalidAudio
    case server(Int)
    var errorDescription: String? {
        switch self {
        case .missingKey: return "请先保存 Groq API Key（gsk_ 开头）；不能使用硅基流动密钥。"
        case .unauthorized: return "Groq 密钥无效、无模型权限或地区不可用。请检查 Groq 账户与手机网络。"
        case .quota: return "Groq 免费额度或速率已用完，语音识别已停止；不会切换付费服务。"
        case .localLimit: return "已达到本机语音请求保护上限，请稍后重试。不会自动付费或切换服务。"
        case .payment: return "Groq 要求付费或余额，已停止。请保持 Free Plan，不必充值。"
        case .unavailable: return "Groq Whisper Large V3 当前不可用，已停止识别。"
        case .invalidResponse: return "Groq 未返回有效的泰文识别结果，已停止；未显示不完整内容。"
        case .invalidAudio: return "这段应用音频格式不支持，已停止识别。"
        case .server(let code): return "Groq 语音识别服务异常（HTTP \(code)），请稍后重试。"
        }
    }
    var diagnosticCode: Int {
        switch self {
        case .missingKey: return 1201
        case .unauthorized: return 401
        case .quota: return 429
        case .localLimit: return 1202
        case .payment: return 402
        case .unavailable: return 404
        case .invalidResponse: return 1203
        case .invalidAudio: return 1204
        case .server(let code): return code
        }
    }
}

private final class NoSpeechRedirects: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}

struct GroqSpeechClient {
    static let keyAccount = "groq-speech-api-key"
    static let model = "whisper-large-v3"
    static let endpoint = URL(string: "https://api.groq.com/openai/v1/audio/transcriptions")!
    struct Result { let text: String; let uncertain: Bool }
    struct Response: Decodable {
        struct Segment: Decodable {
            let text: String
            let avg_logprob: Double?
            let no_speech_prob: Double?
            let compression_ratio: Double?
        }
        let text: String
        let segments: [Segment]?
    }
    private let session: URLSession
    init(session: URLSession? = nil) {
        if let session { self.session = session }
        else {
            let config = URLSessionConfiguration.ephemeral
            config.urlCache = nil; config.httpCookieStorage = nil
            config.waitsForConnectivity = true
            config.allowsCellularAccess = true
            config.timeoutIntervalForRequest = 20; config.timeoutIntervalForResource = 25
            self.session = URLSession(configuration: config, delegate: NoSpeechRedirects(), delegateQueue: nil)
        }
    }
    static func validateKey(_ key: String) throws {
        guard key.hasPrefix("gsk_"), key.count > 12, !key.contains(where: { $0.isWhitespace }) else {
            throw SpeechFailure.missingKey
        }
    }
    static func request(_ window: SpeechAudioWindow, apiKey: String) throws -> URLRequest {
        try validateKey(apiKey)
        guard window.rate.isFinite, (8000...96000).contains(window.rate), window.rate.rounded() == window.rate,
              !window.pcm.isEmpty, window.pcm.count % 2 == 0, window.duration <= 15 else { throw SpeechFailure.invalidAudio }
        let boundary = "ThaiLens-" + UUID().uuidString
        var body = Data()
        func add(_ string: String) { body.append(Data(string.utf8)) }
        for (name, value) in [("model", model), ("language", "th"), ("temperature", "0"), ("response_format", "verbose_json")] {
            add("--\(boundary)\r\nContent-Disposition: form-data; name=\"\(name)\"\r\n\r\n\(value)\r\n")
        }
        // Do not inject guesses about gender or person into the audio transcript.
        add("--\(boundary)\r\nContent-Disposition: form-data; name=\"file\"; filename=\"speech.wav\"\r\nContent-Type: audio/wav\r\n\r\n")
        body.append(window.wav); add("\r\n--\(boundary)--\r\n")
        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        request.httpBody = body
        return request
    }
    static func decode(_ data: Data, status: Int) throws -> Result {
        switch status {
        case 200...299: break
        case 401, 403: throw SpeechFailure.unauthorized
        case 402: throw SpeechFailure.payment
        case 404, 410: throw SpeechFailure.unavailable
        case 429: throw SpeechFailure.quota
        default: throw SpeechFailure.server(status)
        }
        guard data.count <= 1_000_000, let response = try? JSONDecoder().decode(Response.self, from: data),
              response.text.count <= 4000 else { throw SpeechFailure.invalidResponse }
        let text = response.text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return Result(text: "", uncertain: false) }
        var uncertain = false
        if let segments = response.segments, !segments.isEmpty {
            // Drop the whole utterance when likely noise: deleting one clause may
            // remove a subject or negation and reverse the meaning.
            for segment in segments {
                let logprob = segment.avg_logprob ?? 0
                let silence = segment.no_speech_prob ?? 0
                let repeated = segment.compression_ratio ?? 0
                if (silence > 0.6 && logprob < -1) || repeated > 3.5 { return Result(text: "", uncertain: true) }
                if logprob < -0.8 || silence > 0.5 || repeated > 2.4 { uncertain = true }
            }
        } else { uncertain = true }
        guard text.unicodeScalars.contains(where: { (0x0E00...0x0E7F).contains($0.value) }) else {
            return Result(text: "", uncertain: true)
        }
        return Result(text: text, uncertain: uncertain)
    }
    func transcribe(_ window: SpeechAudioWindow, apiKey: String) async throws -> Result {
        try Task.checkCancellation()
        let (data, response) = try await session.data(for: Self.request(window, apiKey: apiKey))
        try Task.checkCancellation()
        guard let http = response as? HTTPURLResponse else { throw SpeechFailure.invalidResponse }
        if http.statusCode == 429 { throw ServiceRateLimit.from(http) }
        return try Self.decode(data, status: http.statusCode)
    }
}
