import Foundation
import Network
import SwiftUI

enum DiagnosticStage: String, Codable {
    case localConnection, speech, translation, screenRecognition, subtitleWindow, broadcast, keychain, uploadTest, audioCapture
    var title: String {
        switch self {
        case .localConnection: return "本机录屏连接"
        case .speech: return "泰语语音识别"
        case .translation: return "Qwen 联网翻译"
        case .screenRecognition: return "画面泰文识别"
        case .subtitleWindow: return "字幕窗口"
        case .broadcast: return "屏幕广播"
        case .keychain: return "密钥保存"
        case .uploadTest: return "日志上传测试"
        case .audioCapture: return "应用音轨接收"
        }
    }
}

// Never persist localizedDescription, userInfo, URLs, headers or input text.
// All textual error fields come from this allowlist, not from server responses.
struct DiagnosticEvent: Codable, Identifiable {
    let id: UUID
    let time: Date
    let stage: DiagnosticStage
    let mode: CaptureMode
    let domain: String
    let code: Int
    let appVersion: String
    let systemVersion: String

    init(stage: DiagnosticStage, mode: CaptureMode, error: Error? = nil) {
        id = UUID()
        time = Date()
        self.stage = stage
        self.mode = mode
        let safe = Self.safeCode(error)
        domain = safe.0
        code = safe.1
        appVersion = "\(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "unknown") (\(Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "unknown"))"
        let version = ProcessInfo.processInfo.operatingSystemVersion
        systemVersion = "\(version.majorVersion).\(version.minorVersion).\(version.patchVersion)"
    }

    static func safeCode(_ error: Error?) -> (String, Int) {
        guard let error else { return ("event", 0) }
        if error is ServiceRateLimit { return ("HTTP", 429) }
        if let nw = error as? NWError {
            switch nw {
            case .posix(let code): return ("POSIX", Int(code.rawValue))
            case .dns(let code): return ("DNS", Int(code))
            case .tls(let code): return ("TLS", Int(code))
            @unknown default: return ("Network", -1)
            }
        }
        if let failure = error as? SpeechFailure { return ("Groq-ASR", failure.diagnosticCode) }
        if let failure = error as? TranslationFailure {
            switch failure {
            case .missingKey: return ("translation", 1)
            case .unauthorized: return ("HTTP-auth", 401)
            case .quota: return ("HTTP", 429)
            case .payment: return ("HTTP", 402)
            case .unavailable: return ("HTTP-unavailable", 404)
            case .invalidResponse: return ("translation", 2)
            case .truncated: return ("translation", 3)
            case .inputTooLong: return ("translation", 4)
            case .nonChinese: return ("translation", 5)
            case .server(let code): return ("HTTP", code)
            }
        }
        let ns = error as NSError
        let allowed = [NSURLErrorDomain, NSPOSIXErrorDomain, NSOSStatusErrorDomain,
                       "kAFAssistantErrorDomain", "kLSRErrorDomain", "SFSpeechErrorDomain", "ThaiLens"]
        return (allowed.contains(ns.domain) ? ns.domain : "other", ns.code)
    }

    static func userMessage(stage: DiagnosticStage, error: Error) -> String {
        let (domain, code) = safeCode(error)
        if error is ServiceRateLimit { return "免费额度暂时受限，请等待后重试；正在运行的字幕会话会自动等待。" }
        if stage == .localConnection {
            return "本机录屏连接启动失败（\(domain) \(code)）。这不是翻译接口错误。请停止系统录屏、重新打开应用再试；诊断已记录。"
        }
        if stage == .speech, let failure = error as? SpeechFailure { return failure.localizedDescription }
        if stage == .translation, let failure = error as? TranslationFailure {
            return failure.localizedDescription
        }
        if domain == NSURLErrorDomain {
            return "\(stage.title)网络请求失败（\(code)）。请检查蜂窝数据权限，或切换 Wi-Fi 后重试。"
        }
        return "\(stage.title)失败（\(domain) \(code)）。错误已记录，可在诊断区查看。"
    }
}

enum DiagnosticUploadFailure: LocalizedError {
    case missingToken, publicRepository, invalidResponse, http(Int)
    var errorDescription: String? {
        switch self {
        case .missingToken: return "请保存仅限 ThaiLens 仓库、Issues 读写权限的 GitHub 细粒度令牌。"
        case .publicRepository: return "目标仓库不是预定的私有仓库，已阻止日志上传。"
        case .invalidResponse: return "GitHub 返回无效响应，日志留在本机。"
        case .http(let code):
            return "GitHub 上传失败（HTTP \(code)）。请检查令牌有效期、ThaiLens 仓库权限与 Issues 读写权限。"
        }
    }
}

private final class NoDiagnosticRedirects: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}

struct GitHubDiagnostics {
    static let repository = "jir782172-source/ThaiLens"
    static let webURL = URL(string: "https://github.com/\(repository)/issues")!
    static let baseURL = URL(string: "https://api.github.com/repos/\(repository)")!

    static func request(path: String = "", method: String = "GET", token: String, body: Data? = nil) throws -> URLRequest {
        let trimmed = token.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.hasPrefix("github_pat_"), !trimmed.contains(where: { $0.isWhitespace }) else {
            throw DiagnosticUploadFailure.missingToken
        }
        var request = URLRequest(url: URL(string: baseURL.absoluteString + path)!)
        request.httpMethod = method
        request.setValue("Bearer \(trimmed)", forHTTPHeaderField: "Authorization")
        request.setValue("application/vnd.github+json", forHTTPHeaderField: "Accept")
        request.setValue("2026-03-10", forHTTPHeaderField: "X-GitHub-Api-Version")
        request.setValue("ThaiLens-Diagnostics", forHTTPHeaderField: "User-Agent")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = body
        return request
    }

    static func validateRepository(_ data: Data) throws {
        struct Repo: Decodable { let `private`: Bool; let full_name: String }
        guard let repo = try? JSONDecoder().decode(Repo.self, from: data) else {
            throw DiagnosticUploadFailure.invalidResponse
        }
        guard repo.private, repo.full_name.lowercased() == repository.lowercased() else {
            throw DiagnosticUploadFailure.publicRepository
        }
    }

    static func body(events: [DiagnosticEvent]) throws -> String {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        let json = String(decoding: try encoder.encode(Array(events.suffix(80))), as: UTF8.self)
        return "ThaiLens 自动诊断。仅含错误阶段、代码、时间与版本，不含聊天、画面、声音、译文或密钥。\n\n```json\n\(json)\n```"
    }

    func upload(events: [DiagnosticEvent], token: String, issueNumber: Int?, session injected: URLSession? = nil) async throws -> Int {
        let config = URLSessionConfiguration.ephemeral
        config.urlCache = nil
        config.httpCookieStorage = nil
        config.timeoutIntervalForRequest = 15
        config.timeoutIntervalForResource = 20
        let session = injected ?? URLSession(configuration: config, delegate: NoDiagnosticRedirects(), delegateQueue: nil)
        defer { if injected == nil { session.invalidateAndCancel() } }
        func send(_ request: URLRequest) async throws -> Data {
            try Task.checkCancellation()
            let (data, response) = try await session.data(for: request)
            try Task.checkCancellation()
            guard let http = response as? HTTPURLResponse else { throw DiagnosticUploadFailure.invalidResponse }
            guard (200...299).contains(http.statusCode) else { throw DiagnosticUploadFailure.http(http.statusCode) }
            guard data.count < 2_000_000 else { throw DiagnosticUploadFailure.invalidResponse }
            return data
        }
        // Check privacy before *every* write, including retries to an existing issue.
        try Self.validateRepository(try await send(Self.request(token: token)))
        let text = try Self.body(events: events)
        let payload: [String: String]
        let path: String
        let method: String
        if let number = issueNumber, number > 0 {
            payload = ["body": text]
            path = "/issues/\(number)"
            method = "PATCH"
        } else {
            payload = ["title": "ThaiLens 诊断 · \(String(UUID().uuidString.prefix(8)))", "body": text]
            path = "/issues"
            method = "POST"
        }
        let data = try await send(Self.request(path: path, method: method, token: token,
                                               body: JSONEncoder().encode(payload)))
        struct Issue: Decodable { let number: Int }
        guard let issue = try? JSONDecoder().decode(Issue.self, from: data), issue.number > 0 else {
            throw DiagnosticUploadFailure.invalidResponse
        }
        return issue.number
    }
}

@MainActor
final class Diagnostics: ObservableObject {
    static let tokenAccount = "github-diagnostics-token"
    @Published private(set) var events: [DiagnosticEvent] = []
    @Published private(set) var enabled = UserDefaults.standard.bool(forKey: "diagnostics.enabled")
    @Published private(set) var tokenSaved = !APIKeyStore.load(account: tokenAccount).isEmpty
    @Published private(set) var uploadStatus = "错误日志只记录错误码、阶段、时间与版本。"
    @Published private(set) var uploading = false
    private var task: Task<Void, Never>?
    private var revision = 0
    private var generation = UUID()
    private var uploadedRevision = 0
    private var issueNumber: Int?
    private var lastAttempt = Date.distantPast
    private var nextAttempt = Date.distantPast
    private var retryDelay: TimeInterval = 60
    private let fileURL: URL
    private struct Saved: Codable {
        var events: [DiagnosticEvent]
        var revision: Int
        var uploadedRevision: Int
        var issueNumber: Int?
    }

    init() {
        let directory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Diagnostics", isDirectory: true)
        fileURL = directory.appendingPathComponent("errors.json")
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        var excluded = directory
        var values = URLResourceValues()
        values.isExcludedFromBackup = true
        try? excluded.setResourceValues(values)
        if let data = try? Data(contentsOf: fileURL), let saved = try? JSONDecoder().decode(Saved.self, from: data) {
            events = Array(saved.events.filter { Date().timeIntervalSince($0.time) < 7 * 86400 }.suffix(80))
            revision = saved.revision
            uploadedRevision = saved.uploadedRevision
            issueNumber = saved.issueNumber
        }
        if !tokenSaved { enabled = false }
    }

    var report: String { (try? GitHubDiagnostics.body(events: events)) ?? "暂无日志" }
    var issueURL: URL {
        guard let number = issueNumber else { return GitHubDiagnostics.webURL }
        return URL(string: GitHubDiagnostics.webURL.absoluteString + "/\(number)")!
    }

    func record(_ stage: DiagnosticStage, mode: CaptureMode, error: Error? = nil) {
        let event = DiagnosticEvent(stage: stage, mode: mode, error: error)
        // Deduplicate repeated failures for a minute; do not flood the repository.
        if let last = events.last, last.stage == event.stage, last.domain == event.domain,
           last.code == event.code, event.time.timeIntervalSince(last.time) < 60 { return }
        events = Array(events.filter { Date().timeIntervalSince($0.time) < 7 * 86400 }.suffix(79)) + [event]
        revision += 1
        save()
        resume()
    }

    func saveToken(_ raw: String) {
        do {
            _ = try GitHubDiagnostics.request(token: raw)
            try APIKeyStore.save(raw, account: Self.tokenAccount)
            tokenSaved = true
            nextAttempt = .distantPast
            uploadStatus = "日志令牌已存入本机钥匙串；开启自动上传后再点测试。"
        } catch { uploadStatus = error.localizedDescription }
    }

    func removeToken() {
        setEnabled(false)
        do {
            try APIKeyStore.remove(account: Self.tokenAccount)
            tokenSaved = false
            uploadStatus = "日志令牌已从本机删除。"
        } catch { uploadStatus = "日志令牌删除失败，请重试。" }
    }

    func setEnabled(_ value: Bool) {
        enabled = value && tokenSaved
        UserDefaults.standard.set(enabled, forKey: "diagnostics.enabled")
        if enabled { resume() }
        else {
            generation = UUID()
            task?.cancel()
            task = nil
            uploading = false
            uploadStatus = "自动上传已关闭；已有 GitHub 日志不会被删除。"
        }
    }

    func testUpload() {
        guard enabled else { uploadStatus = "请先保存日志令牌并开启自动上传。"; return }
        record(.uploadTest, mode: .screen)
        // A previously uploaded test can be resent without creating a fake error.
        if uploadedRevision == revision { revision += 1; save() }
        resume()
    }

    func resume() {
        guard enabled, tokenSaved, task == nil, revision > uploadedRevision else { return }
        let id = generation
        task = Task { [weak self] in
            guard let self else { return }
            defer { if self.generation == id { self.task = nil; self.uploading = false } }
            while self.enabled, self.generation == id, self.revision > self.uploadedRevision, !Task.isCancelled {
                let wait = max(3, self.nextAttempt.timeIntervalSinceNow,
                               60 - Date().timeIntervalSince(self.lastAttempt))
                do { try await Task.sleep(for: .seconds(wait)) } catch { return }
                guard self.enabled, self.generation == id, !Task.isCancelled else { return }
                let snapshot = self.events
                let sentRevision = self.revision
                self.lastAttempt = Date()
                self.uploading = true
                self.uploadStatus = "正在验证私有仓库并上传诊断…"
                do {
                    let number = try await GitHubDiagnostics().upload(events: snapshot,
                        token: APIKeyStore.load(account: Self.tokenAccount), issueNumber: self.issueNumber)
                    guard self.enabled, self.generation == id, !Task.isCancelled else { return }
                    self.issueNumber = number
                    self.uploadedRevision = sentRevision
                    self.retryDelay = 60
                    self.nextAttempt = .distantPast
                    self.uploadStatus = "日志已上传到私有 Issue #\(number)。排查时可把该链接发给助手。"
                    self.save()
                } catch is CancellationError { return }
                catch {
                    guard self.generation == id, !Task.isCancelled else { return }
                    let message = (error as? DiagnosticUploadFailure)?.localizedDescription
                        ?? "日志上传网络失败；本机记录已保留。"
                    self.uploadStatus = message + " 应用运行时将稍后重试。"
                    self.nextAttempt = Date().addingTimeInterval(self.retryDelay)
                    self.retryDelay = min(600, self.retryDelay * 2)
                }
                self.uploading = false
            }
        }
    }

    private func save() {
        do {
            let data = try JSONEncoder().encode(Saved(events: events, revision: revision,
                uploadedRevision: uploadedRevision, issueNumber: issueNumber))
            try data.write(to: fileURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        } catch { uploadStatus = "本机日志文件保存失败；本次记录暂存于内存。" }
    }
}
