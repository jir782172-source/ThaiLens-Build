import SwiftUI
import ReplayKit

@main
struct ThaiLensApp: App {
    var body: some Scene { WindowGroup { HomeView() } }
}

struct BroadcastButton: UIViewRepresentable {
    func makeUIView(context: Context) -> RPSystemBroadcastPickerView {
        let picker = RPSystemBroadcastPickerView(frame: CGRect(x: 0, y: 0, width: 52, height: 52))
        // Derive this from the installed bundle so re-signing can preserve the suffix.
        picker.preferredExtension = (Bundle.main.bundleIdentifier ?? "com.thailens.experimental") + ".broadcast"
        picker.showsMicrophoneButton = false
        return picker
    }
    func updateUIView(_ uiView: RPSystemBroadcastPickerView, context: Context) {}
}

struct HomeView: View {
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var model = SessionModel()
    @State private var showPrivacy = false
    @State private var keyDraft = ""
    

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    Text("跨应用泰语字幕")
                        .font(.largeTitle.bold())
                    Text("面向 YeeTalk · 微信 · Instagram 的实验原型\n兼容性与后台持续运行尚需真机验证")
                        .font(.subheadline).foregroundStyle(.secondary)
                    VStack(alignment: .leading, spacing: 8) {
                        Label(model.recoveryStatus.isEmpty ? model.status : model.recoveryStatus,
                              systemImage: model.recoveryStatus.isEmpty ? "waveform" : "wifi.exclamationmark")
                        Text("主模型限流会自动尝试备用模型；都受限时显示等待时间，到时自动尝试恢复。密钥失效仍需重新设置。")
                            .font(.caption).foregroundStyle(.secondary)
                        if model.running {
                            Text("采集 \(model.receivedCount) 次 · 翻译 \(model.translationCount) 次")
                                .font(.caption.monospacedDigit())
                            if model.mode == .audio { Text(model.audioInputState.shortTitle).font(.caption) }
                        }
                    }.card()
                    VStack(alignment: .leading, spacing: 12) {
                        Label("双模型自动切换 · 0.9.1", systemImage: "character.bubble").font(.headline)
                        Text("Qwen 3.8 27B，由 Groq 提供。翻译与 Whisper 识别共用一个 Groq 密钥。仅使用 Free Plan；免费请求数和令牌额度有限，用完会停止。")
                            .font(.footnote).foregroundStyle(.secondary)
                        HStack {
                            Link("注册 / 获取密钥", destination: URL(string: "https://console.groq.com/keys")!)
                            Link("查看免费额度", destination: URL(string: "https://console.groq.com/docs/rate-limits")!)
                        }.font(.footnote)
                        Text("如果 v0.7 已保存 Groq 密钥，这里会直接复用。请保持 Free Plan，不绑卡、不升级。硅基流动密钥不再用于新版翻译。")
                            .font(.footnote).foregroundStyle(.secondary)
                        SecureField(model.keySaved ? "密钥已保存；可输入新密钥替换" : "粘贴 gsk_ 开头的 Groq API Key", text: $keyDraft)
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                            .textFieldStyle(.roundedBorder)
                        HStack {
                            Button("保存密钥") { model.saveKey(keyDraft); keyDraft = "" }
                                .disabled(keyDraft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                            if model.keySaved {
                                Button("删除密钥", role: .destructive) { model.removeKey() }
                            }
                        }
                        Toggle("同意联网翻译，且 Groq 账户为 Free Plan", isOn: $model.cloudConsent)
                        Text("开启后，将识别出的泰文、人物关系设置和术语（可能包括聊天内容）发送给 Groq 翻译。画面不上传；密钥仅存本机钥匙串。语音模式另需同意上传应用声音。Groq 的数据处理规则适用。")
                            .font(.footnote).foregroundStyle(.secondary)
                        Text(model.setupStatus).font(.footnote)
                    }.disabled(model.running || model.testing).card()

                    VStack(alignment: .leading, spacing: 12) {
                        Text("先试 7 条泰语口语").font(.headline)
                        Text("包含女朋友、人称、拒绝转账等对照样例。参考含义仅供人工比较；测试不读取聊天，也不能证明真实通话的识别准确率。")
                            .font(.footnote).foregroundStyle(.secondary)
                        if model.testing {
                            Button("取消样例测试") { model.cancelTest() }
                        } else {
                            Button("测试连接与译文") { model.testTranslation() }
                                .disabled(model.running || !model.keySaved || !model.cloudConsent)
                        }
                        ForEach(TranslationExample.samples) { example in
                            if let result = model.testResults[example.id] {
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(example.thai).font(.footnote)
                                    Text("Qwen 译文：\(result)")
                                    Text("参考含义：\(example.meaning)").font(.caption).foregroundStyle(.secondary)
                                }
                            }
                        }
                    }.card()
                    VStack(alignment: .leading, spacing: 14) {
                        Text("翻译什么").font(.headline)
                        Picker("翻译内容", selection: $model.mode) {
                            ForEach(CaptureMode.allCases) { Text($0.title).tag($0) }
                        }.pickerStyle(.segmented)
                        if model.mode == .audio {
                            Text("Whisper Large V3 · Groq 联网识别").font(.headline)
                            Text("已替换苹果语音识别。只使用 Groq Free Plan，不绑卡、不升级；有免费额度和地区限制。中国与泰国的实际可用性需在手机上测试，不能保证比苹果更准确。")
                                .font(.footnote).foregroundStyle(.secondary)
                            HStack {
                                Link("注册 / 获取 Groq 密钥", destination: URL(string: "https://console.groq.com/keys")!)
                                Link("免费额度", destination: URL(string: "https://console.groq.com/docs/rate-limits")!)
                            }.font(.footnote)
                            Text("语音识别使用上方已保存的同一个 Groq 密钥。").font(.footnote)
                            Toggle("同意上传声音给 Groq，且账户为 Free Plan", isOn: $model.speechConsent)
                            Text("开启并启动广播后，应用音轨分段通过 HTTPS 发给 Groq Whisper；识别出的泰文再交给 Groq Qwen 翻译。可能包含通话内容，Groq 的数据政策适用。声音仅在本机内存暂存，不写入日志或音频文件。")
                                .font(.footnote).foregroundStyle(.secondary)
                            Text("连续语音约积累 6 秒出初稿，约 12 秒修订；停顿可提前结束一段。识别与翻译请求分别至少间隔 6 秒。Qwen 受限会尝试 GPT-OSS 120B 备用模型；都受限时保留字幕、等待恢复，不积压声音。使用 Groq Free Plan 的额度，不自动升级。")
                                .font(.footnote).foregroundStyle(.secondary)
                            Label("不采集麦克风，不用麦克风补录", systemImage: "mic.slash").font(.subheadline)
                            Text("YeeTalk 内可以照常开麦；系统屏幕广播的“麦克风”请保持关闭。这是两个不同的开关。应用音轨可能包含回声或其他声音，不能按说话者身份分离。开麦后的通话声音能否采集，需要在你的手机上测试。")
                                .font(.footnote).foregroundStyle(.secondary)
                        } else {
                            Text("约每 1.2 秒采集一次画面，用离线泰文 OCR 识别；显示最近几行中文，不修改原软件界面。")
                                .font(.footnote).foregroundStyle(.secondary)
                        }
                    }.disabled(model.running || model.testing).card()

                    VStack(alignment: .leading, spacing: 12) {
                        Text("人物关系与字幕修订").font(.headline)
                        Picker("这段对话里的แฟน", selection: $model.partnerPreference) {
                            ForEach(PartnerPreference.allCases) { Text($0.title).tag($0) }
                        }
                        Text("แฟน 可指恋人，默认要求模型在未明确男女时用“对象”。确认当前语境后可补充女朋友或男朋友；提示会随原文发给翻译服务，但模型仍可能忽略或翻错。")
                            .font(.footnote).foregroundStyle(.secondary)
                        Toggle("字幕实时修订", isOn: $model.realtimeCorrections)
                        Text("开启后，新结果及时替换旧结果，同段语音修正尽量保留阅读页。未结束的识别标为“临时译文”。想读完当前段落时可暂停翻页；关闭此项会优先读完旧段落。")
                            .font(.footnote).foregroundStyle(.secondary)
                    }.disabled(model.running || model.testing).card()

                    ConfigurationUpdatesView(updates: model.updates)
                    SubtitlePanel(window: model.window)

                    VStack(alignment: .leading, spacing: 12) {
                        Label(model.status, systemImage: model.connected ? "dot.radiowaves.left.and.right" : "info.circle")
                            .font(.subheadline)
                        if !model.running {
                            Button("1 · 准备翻译") { Task { await model.prepare() } }
                                .buttonStyle(.borderedProminent).controlSize(.large)
                                .disabled(!model.keySaved || !model.cloudConsent || model.testing || (model.mode == .audio && (!model.speechKeySaved || !model.speechConsent)))
                        } else {
                            Button("停止翻译与采集", role: .destructive) { model.stop() }
                                .buttonStyle(.bordered)
                        }
                        if model.ready {
                            Text("2 · 点上方“开启字幕窗口”\n3 · 点下方广播按钮，选择“泰语字幕”并开始\n4 · 切换到目标软件，等待中文字幕")
                                .font(.subheadline)
                            HStack {
                                BroadcastButton().frame(width: 52, height: 52)
                                Text("开启系统屏幕广播").font(.headline)
                            }
                            Text("出现红色录屏指示表示采集正在进行。关闭字幕小窗会停止翻译；也可点击系统录屏指示停止广播。")
                                .font(.footnote).foregroundStyle(.secondary)
                        }
                    }.card()

                    if model.running {
                        VStack(alignment: .leading, spacing: 8) {
                            if model.mode == .audio {
                                Label(model.audioInputState.shortTitle, systemImage: "waveform").font(.headline)
                                ProgressView(value: Double(model.audioLevel), total: 1)
                                Text(model.audioInputState.explanation).font(.footnote).foregroundStyle(.secondary)
                            }
                            Text("采集 \(model.receivedCount) 次 · 翻译 \(model.translationCount) 次")
                                .font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                            if let duration = model.lastTranslationSeconds {
                                Text(model.lastTranslationCached ? "上次译文来自本机缓存"
                                     : String(format: "上次翻译接口耗时 %.1f 秒（不含声音识别与字幕排队）", duration))
                                    .font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                            }
                            if !model.sourceText.isEmpty {
                                Text(model.mode == .audio ? "Whisper 识别原文（核对是否听错）" : "画面识别原文").font(.caption)
                                Text(model.sourceText).font(.footnote).foregroundStyle(.secondary).textSelection(.enabled)
                            }
                            if !model.translatedText.isEmpty {
                                if !model.translationWarning.isEmpty { Text("⚠ " + model.translationWarning).font(.caption).foregroundStyle(.orange) }
                                if model.provisionalTranslation { Text("临时译文 · 识别结束前可能修正").font(.caption).foregroundStyle(.secondary) }
                                Text(model.translatedText).font(.body).textSelection(.enabled)
                            }
                        }.card()
                    }

                    DiagnosticsView(diagnostics: model.diagnostics)

                    Text("译文由 Qwen 模型生成，不使用苹果翻译。受保护的视频、语音通话、录屏限制、网络或后台挂起都可能导致中断。Whisper 分段识别、Qwen 翻译、网络和阅读翻页均会带来延迟。人名、俚语、否定句请结合上下文核对。")
                        .font(.footnote).foregroundStyle(.secondary)
                    Button("数据如何处理") { showPrivacy = true }
                }.padding(20)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationBarTitleDisplayMode(.inline)
            .sheet(isPresented: $showPrivacy) {
                NavigationStack {
                    ScrollView {
                        Text("只有你主动开启系统屏幕广播后才会采集。\n\n画面与声音通过本机回环连接交给字幕应用。画面文字由本地 Tesseract 识别，图片不会上传。\n\n同意联网翻译后，识别出的泰文、人物关系提示和术语会通过 HTTPS 发到 Groq，调用 Qwen 3.8 27B 翻译；限流或模型不可用时自动尝试同一 Groq 账户的 GPT-OSS 120B。对方的数据处理及保留政策适用；本应用无法控制对方的数据保留。不要用于你不愿上传的聊天。\n\n没有开发者中转服务器，不写入录屏、音频或聊天记录。为避免重复请求，只在本次会话内存中缓存少量译文，停止后清除。密钥存放本机钥匙串，不写入源码、IPA 或日志；可在设置区删除。\n\n语音识别已替换为 Groq Whisper Large V3。只有开启“同意上传声音给 Groq，且账户为 Free Plan”并启动广播后，才将应用音轨经 HTTPS 发送给 Groq。不会发送给苹果。Groq 的数据处理及保留政策适用；应用无法撤回已上传的声音。不采集麦克风，也无法按说话者身份分离应用音轨。\n\n样例测试只发送界面上展示的固定泰语，不采集屏幕。\n\n关闭字幕小窗、点击停止或关闭屏幕广播都会结束翻译；已发给服务商的请求无法撤回。\n\nQwen 翻译与 Whisper 识别均使用 Groq Free Plan 内的免费额度。应用无法验证你的账户套餐，如已升级为付费套餐，请勿使用。无自动升级或收费模型回退。服务价格和速率政策可能变化，请在平台核实，不必充值。诊断仅保存错误阶段、错误码、时间和版本；本机最多 80 条、保留 7 天。开启自动上传后，将这些记录通过 HTTPS 发到你配置的 GitHub 私有仓库 Issues；每次发送前检查仓库仍为私有。GitHub 的数据政策适用，关闭自动上传不会删除已上传记录。不会上传聊天、图像、音频、译文或密钥。没有持续监控当前聊天的服务；系统挂起时不能保证实时上传。无广告。开源 OCR 许可证随安装包提供。")
                            .padding()
                    }.navigationTitle("数据处理说明")
                        .toolbar { Button("完成") { showPrivacy = false } }
                }
            }
        }.tint(.teal)
            .onChange(of: scenePhase) { _, phase in
                if phase == .active {
                    model.diagnostics.resume()
                    Task { await model.updates.check() }
                }
            }
            .task { await model.updates.check() }
    }
}

private struct ConfigurationUpdatesView: View {
    @ObservedObject var updates: ConfigurationUpdates
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("配置热更新", systemImage: "arrow.triangle.2.circlepath").font(.headline)
            Toggle("打开应用时检查配置更新", isOn: $updates.enabled)
            Text(updates.status).font(.footnote)
            Text("热更新可调整翻译规则、术语和字幕节奏；断线恢复等程序修复需要安装新版 IPA。后续配置更新仍可直接检查获取。").font(.caption).foregroundStyle(.secondary)
            Text("当前可用配置：r\(updates.effective.revision) · \(updates.effective.notes)")
                .font(.caption).foregroundStyle(.secondary)
            Button(updates.checking ? "正在检查…" : "检查配置更新") { Task { await updates.check(force: true) } }
                .disabled(updates.checking)
            Text("复用下方已保存的 GitHub 日志令牌，只读取自己私有仓库里的签名配置。可更新对应模型的翻译规则、术语和等待参数，下次准备翻译生效。更新失败继续使用原配置；录音、识别引擎等原生代码更新仍需安装新版 IPA。")
                .font(.caption).foregroundStyle(.secondary)
        }.card()
    }
}

private struct DiagnosticsView: View {
    @ObservedObject var diagnostics: Diagnostics
    @State private var tokenDraft = ""
    @State private var showReport = false

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("错误诊断与自动上传", systemImage: "stethoscope").font(.headline)
            Text("错误会保存在手机，最多 80 条、保留 7 天。仅记录阶段、错误码、时间、应用与系统版本，不含聊天、画面、音频、译文或任何密钥。")
                .font(.footnote).foregroundStyle(.secondary)
            Text("上传目标：你的 GitHub 私有仓库 ThaiLens。需单独的 GitHub 细粒度令牌，仅选择该仓库并开启 Issues 读写；不要填写 Groq 翻译密钥。")
                .font(.footnote).foregroundStyle(.secondary)
            Link("创建 GitHub 日志令牌", destination: URL(string: "https://github.com/settings/personal-access-tokens/new")!)
                .font(.footnote)
            SecureField(diagnostics.tokenSaved ? "日志令牌已保存；可输入新令牌替换" : "粘贴 github_pat_ 开头的日志令牌", text: $tokenDraft)
                .textInputAutocapitalization(.never).autocorrectionDisabled().textFieldStyle(.roundedBorder)
            HStack {
                Button("保存日志令牌") { diagnostics.saveToken(tokenDraft); tokenDraft = "" }
                    .disabled(tokenDraft.isEmpty || diagnostics.uploading)
                if diagnostics.tokenSaved {
                    Button("删除日志令牌", role: .destructive) { diagnostics.removeToken() }
                }
            }.font(.footnote)
            Toggle("自动上传错误到我的私有仓库", isOn: Binding(
                get: { diagnostics.enabled }, set: { diagnostics.setEnabled($0) }))
                .disabled(!diagnostics.tokenSaved)
            Text("开启即同意将上述诊断信息发给 GitHub。应用可运行时会自动上传，最多每分钟一次；断网重试。iOS 暂停或关闭应用后不能保证实时。助手只在你请求排查时查看，不会持续监控。")
                .font(.footnote).foregroundStyle(.secondary)
            Text(diagnostics.uploadStatus).font(.footnote)
            HStack {
                Button("测试日志上传") { diagnostics.testUpload() }
                    .disabled(!diagnostics.enabled || diagnostics.uploading)
                Button("查看本机日志") { showReport = true }
            }.font(.footnote)
            Link("打开我的诊断记录", destination: diagnostics.issueURL).font(.footnote)
        }.card()
            .sheet(isPresented: $showReport) {
                NavigationStack {
                    ScrollView { Text(diagnostics.report).font(.caption.monospaced()).textSelection(.enabled).padding() }
                        .navigationTitle("本机诊断")
                        .toolbar {
                            ShareLink(item: diagnostics.report) { Image(systemName: "square.and.arrow.up") }
                            Button("完成") { showReport = false }
                        }
                }
            }
    }
}

private struct SubtitlePanel: View {
    @ObservedObject var window: SubtitleWindow
    @State private var readingText = ""
    @State private var showFullText = false
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            SubtitlePreview(window: window).aspectRatio(2.4, contentMode: .fit)
                .clipShape(RoundedRectangle(cornerRadius: 16))
            Button(window.active ? "字幕窗口已开启" : "2 · 开启字幕窗口") { window.start() }
                .buttonStyle(.bordered).disabled(!window.possible || window.active)
            HStack {
                Button("上一页") { window.previousPage() }.disabled(window.pageNumber <= 1)
                Text("\(window.pageNumber) / \(window.pageCount)").monospacedDigit()
                Button("下一页") { window.nextPage() }
                    .disabled(window.pageNumber >= window.pageCount && !window.hasPendingCaption)
                Spacer()
                Button(window.autoPaging ? "暂停翻页" : "自动翻页") { window.toggleAutoPaging() }
            }.font(.footnote)
            HStack {
                Button("完整译文（可滑动）") { readingText = window.fullText; showFullText = true }
                if window.hasPendingCaption { Button("显示新译文") { window.showLatest() } }
            }.font(.footnote)
            Text("长译文按当前配置自动翻页。小窗里点一下可显示系统播放/暂停与前后跳转按钮；它们用于暂停、前后翻页。小窗内的文字不能直接滑动，完整译文可在此展开阅读。")
                .font(.caption).foregroundStyle(.secondary)
        }
        .sheet(isPresented: $showFullText) {
            NavigationStack {
                ScrollView {
                    Text(readingText).font(.title3).frame(maxWidth: .infinity, alignment: .leading)
                        .textSelection(.enabled).padding()
                }.navigationTitle("完整译文")
                    .toolbar { Button("完成") { showFullText = false } }
            }
        }
    }
}

private extension View {
    func card() -> some View {
        padding(16).frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18))
    }
}
