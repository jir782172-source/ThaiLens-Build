import Foundation

enum AudioInputState: String {
    case waiting, receiving, silent, noBuffers, noRecognition, recognizing
    var shortTitle: String {
        switch self {
        case .recognizing: return "AI 正在联网识别"
        case .waiting: return "等待应用声音"
        case .receiving: return "收到应用声音"
        case .silent: return "音轨接近静音"
        case .noBuffers: return "未收到应用音轨"
        case .noRecognition: return "有声音，尚未识别出泰文"
        }
    }
    var explanation: String {
        switch self {
        case .recognizing: return "已接收应用声音，正在等待 Groq 识别结果；网络超时会提示。"
        case .waiting: return "请让对方说一小段泰语，观察开麦前后是否都有声音。"
        case .receiving: return "检测到应用音轨中的声音；这不能证明说话者身份或翻译准确率。"
        case .silent: return "系统仍在发送音轨，但声音接近静音。可能对方没说话，也可能通话声音没有提供给录屏。"
        case .noBuffers: return "未收到可用的应用音轨。若仅在开麦后出现，可能是 iOS / YeeTalk 的通话采集限制；不会改用麦克风。"
        case .noRecognition: return "应用音轨有声音，但还没有新的泰文识别结果。请检查是否为泰语，以及 Groq 账户额度和网络。"
        }
    }
    var diagnosticCode: Int? {
        switch self {
        case .noBuffers: return 1101
        case .silent: return 1102
        case .noRecognition: return 1103
        default: return nil
        }
    }
}

// The meter is ephemeral: only coarse error codes may enter Diagnostics.
// Signal presence is deliberately not described as "the other person's voice".
struct AudioHealth {
    private var started: TimeInterval = 0
    private var lastBuffer: TimeInterval?
    private var lastSignal: TimeInterval?
    private var lastRecognition: TimeInterval?
    private var signalBegan: TimeInterval?
    private(set) var peak: Float = 0

    mutating func reset(now: TimeInterval) { self = AudioHealth(); started = now }

    mutating func receive(_ chunk: PCMChunk, now: TimeInterval) {
        guard chunk.isValid else { return }
        lastBuffer = now
        peak = chunk.samples.withUnsafeBytes { bytes -> Float in
            var maximum: Float = 0
            for offset in stride(from: 0, to: bytes.count, by: MemoryLayout<Float>.size) {
                let value = bytes.loadUnaligned(fromByteOffset: offset, as: Float.self)
                if value.isFinite { maximum = max(maximum, abs(value)) }
            }
            return min(1, maximum)
        }
        if peak > 0.00001 {
            if lastSignal == nil || now - lastSignal! > 3 { signalBegan = now }
            lastSignal = now
        }
    }

    mutating func recognized(now: TimeInterval) { lastRecognition = now }

    func state(now: TimeInterval) -> AudioInputState {
        guard now - started >= 3 else { return .waiting }
        guard let lastBuffer else { return now - started >= 6 ? .noBuffers : .waiting }
        if now - lastBuffer >= 6 { return .noBuffers }
        guard let lastSignal else { return now - started >= 8 ? .silent : .waiting }
        if now - lastSignal >= 8 { return .silent }
        if now - lastSignal < 3, let signalBegan,
           now - max(signalBegan, lastRecognition ?? started) >= 12 { return .noRecognition }
        return .receiving
    }
}

enum TranslationPacing {
    static let minimumInterval: TimeInterval = 2.5
    static func isReady(mode: CaptureMode, now: TimeInterval, lastAttempt: TimeInterval,
                        pendingSince: TimeInterval, lastChange: TimeInterval, isFinal: Bool,
                        configuration: TranslationConfiguration = .builtIn) -> Bool {
        guard now - lastAttempt >= configuration.requestInterval else { return false }
        if mode == .audio {
            // Do not keep extending the debounce while the other person is speaking.
            return isFinal || now - lastChange >= configuration.speechStableSeconds ||
                now - pendingSince >= configuration.maximumSpeechWait
        }
        return now - lastChange >= 0.6 || now - lastAttempt >= 5
    }
}
