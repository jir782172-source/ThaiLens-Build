import Foundation

struct SpeechAudioWindow {
    let group: UUID
    let revision: Int
    let rate: Double
    let pcm: Data // signed 16-bit little endian, mono, memory only
    let isFinal: Bool
    let overlapsPrevious: Bool
    var duration: Double { Double(pcm.count / 2) / rate }
    var wav: Data {
        var data = Data("RIFF".utf8)
        func u32(_ value: UInt32) { var v = value.littleEndian; withUnsafeBytes(of: &v) { data.append(contentsOf: $0) } }
        func u16(_ value: UInt16) { var v = value.littleEndian; withUnsafeBytes(of: &v) { data.append(contentsOf: $0) } }
        u32(UInt32(36 + pcm.count)); data.append(Data("WAVEfmt ".utf8))
        u32(16); u16(1); u16(1); u32(UInt32(rate)); u32(UInt32(rate) * 2)
        u16(2); u16(16); data.append(Data("data".utf8)); u32(UInt32(pcm.count)); data.append(pcm)
        return data
    }
}

struct SpeechSegmenter {
    struct Output { let window: SpeechAudioWindow?; let discontinuity: Bool }
    private var pcm = Data()
    private var preRoll = Data()
    private var rate: Double = 0
    private var sequence: UInt64?
    private var group = UUID()
    private var revision = 0
    private var lastEmission: Double = 0
    private var quietSeconds: Double = 0
    private var active = false
    private var overlap = false

    mutating func append(_ chunk: PCMChunk) -> Output {
        guard chunk.isValid else { return Output(window: nil, discontinuity: false) }
        let gap = sequence.map { chunk.sequence != $0 &+ 1 || chunk.rate != rate } ?? false
        if gap { self = SpeechSegmenter() }
        rate = chunk.rate; sequence = chunk.sequence
        var bytes = Data(capacity: chunk.frames * 2)
        var energy: Double = 0
        chunk.samples.withUnsafeBytes { raw in
            for offset in stride(from: 0, to: raw.count, by: 4) {
                let rawValue = raw.loadUnaligned(fromByteOffset: offset, as: Float.self)
                let value = rawValue.isFinite ? max(-1, min(1, rawValue)) : 0
                energy += Double(value * value)
                var sample = Int16((value * 32767).rounded()).littleEndian
                withUnsafeBytes(of: &sample) { bytes.append(contentsOf: $0) }
            }
        }
        // Conservative energy gate, not a speaker/language detector.
        let signal = sqrt(energy / Double(chunk.frames)) > 0.0001
        let seconds = Double(chunk.frames) / rate
        if !active {
            if !signal {
                preRoll.append(bytes)
                let limit = Int(rate * 0.3) * 2
                if preRoll.count > limit { preRoll = Data(preRoll.suffix(limit)) }
                return Output(window: nil, discontinuity: gap)
            }
            active = true; pcm = preRoll; preRoll.removeAll(); pcm.append(bytes)
        } else { pcm.append(bytes) }
        quietSeconds = signal ? 0 : quietSeconds + seconds
        let duration = Double(pcm.count / 2) / rate
        let final = duration >= 12 || (quietSeconds >= 0.7 && duration >= 0.9)
        guard final || duration - lastEmission >= 6 else { return Output(window: nil, discontinuity: gap) }
        revision += 1
        let window = SpeechAudioWindow(group: group, revision: revision, rate: rate, pcm: pcm,
                                       isFinal: final, overlapsPrevious: overlap)
        lastEmission = duration
        if final {
            let keepOverlap = quietSeconds < 0.7
            pcm = keepOverlap ? Data(pcm.suffix(Int(rate) * 2)) : Data()
            active = keepOverlap; overlap = keepOverlap
            group = UUID(); revision = 0; lastEmission = keepOverlap ? 1 : 0; quietSeconds = 0
        }
        return Output(window: window, discontinuity: gap)
    }
}

enum SpeechOverlap {
    static func removingRepeatedPrefix(_ text: String, previous: String) -> String {
        let a = Array(previous.trimmingCharacters(in: .whitespacesAndNewlines))
        let b = Array(text.trimmingCharacters(in: .whitespacesAndNewlines))
        let maximum = min(100, min(a.count, b.count - 1))
        guard maximum >= 8 else { return text }
        for length in stride(from: maximum, through: 8, by: -1) {
            if a.suffix(length).elementsEqual(b.prefix(length)) {
                return String(b.dropFirst(length)).trimmingCharacters(in: .whitespacesAndNewlines)
            }
        }
        return text
    }
}

// Local conservative ceilings; timestamps/seconds only, never conversation data.
struct SpeechBudget: Codable {
    struct Entry: Codable { let time: Double; let seconds: Double }
    var entries: [Entry] = []
    func retryDelay(duration: Double, now: Double) -> TimeInterval {
        var lower = 0.0, upper = 86401.0
        for _ in 0..<20 {
            let middle = (lower + upper) / 2
            var probe = self
            if (try? probe.reserve(duration: duration, now: now + middle)) != nil { upper = middle }
            else { lower = middle }
        }
        return ceil(upper) + 1
    }
    mutating func reserve(duration: Double, now: Double) throws {
        entries.removeAll { now - $0.time >= 86400 }
        let billed = max(10, ceil(duration))
        guard entries.count < 1800,
              entries.reduce(0, { $0 + $1.seconds }) + billed <= 27000,
              entries.filter({ now - $0.time < 3600 }).reduce(0, { $0 + $1.seconds }) + billed <= 6900,
              entries.filter({ now - $0.time < 60 }).count < 15 else { throw SpeechFailure.localLimit }
        entries.append(Entry(time: now, seconds: billed))
    }
    static func load() -> SpeechBudget {
        guard let data = UserDefaults.standard.data(forKey: "groq-request-budget-v1"),
              let result = try? JSONDecoder().decode(Self.self, from: data) else { return Self() }
        return result
    }
    func save() { if let data = try? JSONEncoder().encode(self) { UserDefaults.standard.set(data, forKey: "groq-request-budget-v1") } }
}
