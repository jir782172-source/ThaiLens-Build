import UIKit

// The same TextKit layout is used for pagination, measurement and drawing.
// No character-count estimates, single-line ellipses or clipped unseen suffixes.
final class SubtitleDocument {
    static let canvasSize = CGSize(width: 960, height: 400)
    static let bodyRect = CGRect(x: 36, y: 78, width: 888, height: 264)
    let text: String
    let group: UUID?
    let provisional: Bool
    private let storage: NSTextStorage
    private let layout = NSLayoutManager()
    private var containers: [NSTextContainer] = []
    private(set) var glyphRanges: [NSRange] = []
    private(set) var characterRanges: [NSRange] = []

    init(_ text: String, group: UUID? = nil, provisional: Bool = false) {
        self.text = text
        self.group = group
        self.provisional = provisional
        let paragraph = NSMutableParagraphStyle()
        paragraph.lineBreakMode = .byWordWrapping
        paragraph.lineSpacing = 8
        storage = NSTextStorage(string: text, attributes: [
            .font: UIFont.systemFont(ofSize: 42, weight: .medium),
            .foregroundColor: UIColor.white, .paragraphStyle: paragraph
        ])
        storage.addLayoutManager(layout)
        repeat {
            let container = NSTextContainer(size: Self.bodyRect.size)
            container.lineFragmentPadding = 0
            container.lineBreakMode = .byWordWrapping
            layout.addTextContainer(container)
            layout.ensureLayout(for: container)
            let range = layout.glyphRange(for: container)
            containers.append(container)
            glyphRanges.append(range)
            characterRanges.append(layout.characterRange(forGlyphRange: range, actualGlyphRange: nil))
            if range.length == 0 || NSMaxRange(range) >= layout.numberOfGlyphs { break }
        } while true
    }

    var pageCount: Int { containers.count }
    func pageText(_ index: Int) -> String {
        (text as NSString).substring(with: characterRanges[min(max(0, index), pageCount - 1)])
    }
    func usedRect(_ index: Int) -> CGRect { layout.usedRect(for: containers[index]) }
    func lineCount(_ index: Int) -> Int {
        var count = 0
        layout.enumerateLineFragments(forGlyphRange: glyphRanges[index]) { _, _, _, _, _ in count += 1 }
        return count
    }

    func draw(page index: Int, title: String, footer: String) {
        let page = min(max(0, index), pageCount - 1)
        UIColor(red: 0.04, green: 0.08, blue: 0.14, alpha: 1).setFill()
        UIRectFill(CGRect(origin: .zero, size: Self.canvasSize))
        (title as NSString).draw(in: CGRect(x: 36, y: 20, width: 710, height: 36), withAttributes: [
            .font: UIFont.systemFont(ofSize: 23, weight: .semibold), .foregroundColor: UIColor.systemMint
        ])
        let right = NSMutableParagraphStyle()
        right.alignment = .right
        ("\(page + 1) / \(pageCount)" as NSString).draw(in: CGRect(x: 758, y: 20, width: 166, height: 36), withAttributes: [
            .font: UIFont.monospacedDigitSystemFont(ofSize: 23, weight: .medium),
            .foregroundColor: UIColor.systemMint, .paragraphStyle: right
        ])
        if let cg = UIGraphicsGetCurrentContext() {
            cg.saveGState()
            cg.clip(to: Self.bodyRect)
            layout.drawBackground(forGlyphRange: glyphRanges[page], at: Self.bodyRect.origin)
            layout.drawGlyphs(forGlyphRange: glyphRanges[page], at: Self.bodyRect.origin)
            cg.restoreGState()
        }
        (footer as NSString).draw(in: CGRect(x: 36, y: 363, width: 888, height: 29), withAttributes: [
            .font: UIFont.systemFont(ofSize: 20), .foregroundColor: UIColor.lightGray
        ])
    }
}

struct SubtitlePager {
    static let secondsPerPage: TimeInterval = 6
    static let timelineSecondsPerPage: TimeInterval = 15
    private(set) var document = SubtitleDocument("准备后开启字幕窗口")
    private(set) var page = 0
    private(set) var playing = true
    private(set) var pending: SubtitleDocument?
    private var deadline: TimeInterval = 0
    private(set) var dwellSeconds: TimeInterval = SubtitlePager.secondsPerPage

    mutating func configure(seconds: TimeInterval, now: TimeInterval) {
        guard seconds.isFinite, (4...12).contains(seconds) else { return }
        dwellSeconds = seconds
        deadline = now + dwellSeconds
    }

    mutating func replace(_ document: SubtitleDocument, now: TimeInterval) {
        self.document = document
        page = 0
        pending = nil
        deadline = now + dwellSeconds
    }

    mutating func submit(_ next: SubtitleDocument, now: TimeInterval, realtime: Bool = false) {
        guard next.text != document.text || next.provisional != document.provisional || next.group != document.group
        else { pending = nil; return }
        if !playing { pending = next; return }
        if realtime {
            if let group = next.group, group == document.group {
                document = next
                page = min(page, next.pageCount - 1)
                pending = nil
            } else { replace(next, now: now) }
            return
        }
        if next.text.hasPrefix(document.text), !document.text.isEmpty {
            // Growing speech transcripts keep the current page and its timer.
            document = next
            pending = nil
        } else if !playing || document.pageCount > 1 {
            // Keep unread pages; coalesce incoming results to the latest only.
            pending = next
        } else { replace(next, now: now) }
    }

    @discardableResult mutating func tick(now: TimeInterval) -> Bool {
        guard playing, now >= deadline else { return false }
        deadline = now + dwellSeconds
        if page + 1 < document.pageCount { page += 1; return true }
        if let next = pending { replace(next, now: now); return true }
        if document.pageCount > 1 { page = 0; return true }
        return true // Rewind the finite one-page timeline while waiting for new input.
    }

    mutating func setPlaying(_ value: Bool, now: TimeInterval) {
        let resuming = value && !playing
        playing = value
        if resuming, let next = pending { replace(next, now: now) }
        deadline = now + dwellSeconds
    }

    mutating func move(_ direction: Int, now: TimeInterval) {
        if direction > 0, page == document.pageCount - 1, let next = pending {
            replace(next, now: now)
        } else { page = min(max(0, page + direction), document.pageCount - 1) }
        deadline = now + dwellSeconds
    }

    mutating func latest(now: TimeInterval) {
        if let next = pending { replace(next, now: now) }
        else { page = 0; deadline = now + dwellSeconds }
    }

    func playbackTime(now: TimeInterval) -> TimeInterval {
        let elapsed = playing ? min(dwellSeconds, max(0, dwellSeconds - (deadline - now))) : 0
        return (Double(page) + elapsed / dwellSeconds) * Self.timelineSecondsPerPage
    }
}
