import Foundation
import Network

enum RecoveryChannel: Hashable { case translation, speech }
enum RecoverySkip: Error { case superseded }

enum RecoveryPolicy {
    static func isTransient(_ error: Error) -> Bool {
        if error is CancellationError { return false }
        if let error = error as? TranslationFailure {
            if case .server(let code) = error { return code == 408 || code == 425 || (500...599).contains(code) }
            return false
        }
        if let error = error as? SpeechFailure {
            if case .server(let code) = error { return code == 408 || code == 425 || (500...599).contains(code) }
            return false
        }
        let ns = error as NSError
        guard ns.domain == NSURLErrorDomain else { return false }
        return [NSURLErrorTimedOut, NSURLErrorCannotFindHost, NSURLErrorCannotConnectToHost,
                NSURLErrorDNSLookupFailed, NSURLErrorNetworkConnectionLost,
                NSURLErrorNotConnectedToInternet, NSURLErrorInternationalRoamingOff,
                NSURLErrorCallIsActive, NSURLErrorDataNotAllowed].contains(ns.code)
    }
    static func delay(failures: Int) -> TimeInterval {
        [2.0, 4, 8, 15][min(max(failures - 1, 0), 3)]
    }
}

// One controller per active session. Separate channels cannot hide each other's errors.
// No audio, transcript, credential or response is retained here.
@MainActor
final class NetworkRecovery {
    var onStatus: ((String?) -> Void)?
    var onTransient: ((RecoveryChannel, Error) -> Void)?
    private(set) var available = true
    private(set) var active = false
    private var monitor: NWPathMonitor?
    private var generation = UUID()
    private var pathRevision = 0
    private struct Backoff { var failures = 0; var until: TimeInterval = 0; var path = 0 }
    private var backoffs: [RecoveryChannel: Backoff] = [:]
    private var messages: [RecoveryChannel: String] = [:]
    private var lastDiagnostic: [RecoveryChannel: TimeInterval] = [:]
    private let now: () -> TimeInterval
    private let sleep: (TimeInterval) async throws -> Void

    init(now: @escaping () -> TimeInterval = { ProcessInfo.processInfo.systemUptime },
         sleep: @escaping (TimeInterval) async throws -> Void = { try await Task.sleep(for: .seconds($0)) }) {
        self.now = now; self.sleep = sleep
    }
    func start(monitorNetwork: Bool = true) {
        stop()
        active = true
        if monitorNetwork {
            let monitor = NWPathMonitor()
            let id = generation
            monitor.pathUpdateHandler = { [weak self] path in
                let online = path.status == .satisfied
                Task { @MainActor [weak self] in
                    guard let self, self.active, self.generation == id else { return }
                    self.updatePath(available: online)
                }
            }
            self.monitor = monitor
            monitor.start(queue: DispatchQueue(label: "thailens.network"))
        }
    }
    func stop() {
        active = false
        generation = UUID()
        monitor?.cancel(); monitor = nil
        backoffs.removeAll(); messages.removeAll(); lastDiagnostic.removeAll()
        available = true
        onStatus?(nil)
    }
    func updatePath(available: Bool) {
        guard active else { return }
        self.available = available
        pathRevision += 1
        publish()
    }
    private func publish() {
        guard active else { return }
        onStatus?(!available ? "网络已断开 · 保留会话，联网后自动恢复"
                  : messages[.speech] ?? messages[.translation])
    }
    func perform<T>(channel: RecoveryChannel, isCurrent: () -> Bool,
                    operation: () async throws -> T) async throws -> T {
        let id = generation
        func validate() throws {
            try Task.checkCancellation()
            guard active, generation == id else { throw CancellationError() }
            guard isCurrent() else { throw RecoverySkip.superseded }
        }
        defer {
            if generation == id { messages.removeValue(forKey: channel); publish() }
        }
        while true {
            try validate()
            if !available { publish(); try await sleep(0.25); continue }
            if let backoff = backoffs[channel], backoff.path == pathRevision, now() < backoff.until {
                messages[channel] = channel == .speech ? "语音识别连接中断 · 自动重试中" : "翻译连接中断 · 自动重试中"
                publish()
                try await sleep(min(0.25, backoff.until - now())); continue
            }
            do {
                let value = try await operation()
                try validate()
                backoffs.removeValue(forKey: channel)
                return value
            } catch {
                try validate()
                guard RecoveryPolicy.isTransient(error) else { throw error }
                var backoff = backoffs[channel] ?? Backoff()
                backoff.failures = min(backoff.failures + 1, 4)
                backoff.until = now() + RecoveryPolicy.delay(failures: backoff.failures)
                backoff.path = pathRevision
                backoffs[channel] = backoff
                messages[channel] = channel == .speech
                    ? "语音识别连接中断 · 自动重试中"
                    : "翻译连接中断 · 自动重试中"
                if now() - (lastDiagnostic[channel] ?? -.infinity) >= 60 {
                    lastDiagnostic[channel] = now(); onTransient?(channel, error)
                }
                publish()
            }
        }
    }
}
