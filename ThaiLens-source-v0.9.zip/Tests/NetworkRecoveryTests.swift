import XCTest
@testable import ThaiLens

@MainActor
final class NetworkRecoveryTests: XCTestCase {
    func testDisconnectThenReconnectResumesWithoutNewSession() async throws {
        var time: Double = 0
        var sleeps = 0
        var recovery: NetworkRecovery!
        recovery = NetworkRecovery(now: { time }, sleep: { seconds in
            time += seconds; sleeps += 1
            if sleeps == 4 { recovery.updatePath(available: true) }
            await Task.yield()
        })
        recovery.start(monitorNetwork: false)
        recovery.updatePath(available: false)
        defer { recovery.stop() }
        var attempts = 0
        var messages: [String] = []
        recovery.onStatus = { if let value = $0 { messages.append(value) } }
        let value = try await recovery.perform(channel: .translation, isCurrent: { true }) {
            XCTAssertTrue(recovery.available)
            attempts += 1
            return "已恢复"
        }
        XCTAssertEqual(value, "已恢复"); XCTAssertEqual(attempts, 1)
        XCTAssertEqual(sleeps, 4)
        XCTAssertTrue(messages.contains { $0.contains("网络已断开") })
    }

    func testTransientFailuresBackOffThenSucceedAndClearStatus() async throws {
        var time: Double = 0
        let recovery = NetworkRecovery(now: { time }, sleep: { time += $0 })
        recovery.start(monitorNetwork: false)
        defer { recovery.stop() }
        var attempts: [Double] = []
        var finalStatus: String? = "initial"
        recovery.onStatus = { finalStatus = $0 }
        let value = try await recovery.perform(channel: .translation, isCurrent: { true }) {
            attempts.append(time)
            if attempts.count <= 3 { throw URLError(.networkConnectionLost) }
            return "中文"
        }
        XCTAssertEqual(value, "中文")
        XCTAssertEqual(attempts, [0, 2, 6, 14])
        XCTAssertNil(finalStatus)
        XCTAssertTrue(recovery.active)
    }

    func testNetworkChangeWakesBackoffEarly() async throws {
        var time: Double = 0
        var recovery: NetworkRecovery!
        recovery = NetworkRecovery(now: { time }, sleep: { seconds in
            time += seconds; recovery.updatePath(available: true)
        })
        recovery.start(monitorNetwork: false)
        defer { recovery.stop() }
        var count = 0
        let value = try await recovery.perform(channel: .speech, isCurrent: { true }) {
            count += 1
            if count == 1 { throw URLError(.timedOut) }
            return 42
        }
        XCTAssertEqual(value, 42)
        XCTAssertLessThan(time, 2)
    }

    func testStoppingWhileOfflineNeverRestartsOrUploads() async throws {
        var recovery: NetworkRecovery!
        recovery = NetworkRecovery(sleep: { _ in recovery.stop() })
        recovery.start(monitorNetwork: false); recovery.updatePath(available: false)
        var calls = 0
        do {
            let _: Int = try await recovery.perform(channel: .speech, isCurrent: { true }) { calls += 1; return 1 }
            XCTFail("Stopped request completed")
        } catch { XCTAssertTrue(error is CancellationError) }
        recovery.updatePath(available: true)
        XCTAssertEqual(calls, 0); XCTAssertFalse(recovery.active)
    }

    func testLateResponseCannotReviveStoppedOrReplacedSession() async throws {
        let recovery = NetworkRecovery()
        recovery.start(monitorNetwork: false)
        defer { recovery.stop() }
        do {
            let _: String = try await recovery.perform(channel: .translation, isCurrent: { true }) {
                recovery.stop(); recovery.start(monitorNetwork: false)
                return "旧译文"
            }
            XCTFail("Old request escaped generation guard")
        } catch { XCTAssertTrue(error is CancellationError) }
        XCTAssertTrue(recovery.active)
    }

    func testStaleSourceIsDiscardedWithoutRetryingOrStoppingSession() async throws {
        var current = true
        let recovery = NetworkRecovery(sleep: { _ in current = false })
        recovery.start(monitorNetwork: false)
        defer { recovery.stop() }
        var count = 0
        do {
            let _: String = try await recovery.perform(channel: .translation, isCurrent: { current }) {
                count += 1; throw URLError(.cannotConnectToHost)
            }
            XCTFail("Stale source was retried")
        } catch { XCTAssertTrue(error is RecoverySkip) }
        XCTAssertEqual(count, 1); XCTAssertTrue(recovery.active)
    }

    func testAuthQuotaBillingCertificateAndCancellationDoNotRetry() async {
        let errors: [Error] = [TranslationFailure.unauthorized, TranslationFailure.quota,
                              TranslationFailure.payment, TranslationFailure.unavailable,
                              SpeechFailure.localLimit, SpeechFailure.quota, SpeechFailure.unauthorized,
                              URLError(.serverCertificateUntrusted), URLError(.cancelled), CancellationError()]
        for failure in errors {
            let recovery = NetworkRecovery(sleep: { _ in XCTFail("Non-transient failure retried") })
            recovery.start(monitorNetwork: false)
            var count = 0
            do {
                let _: Int = try await recovery.perform(channel: .translation, isCurrent: { true }) {
                    count += 1; throw failure
                }
                XCTFail("Expected failure")
            } catch { XCTAssertEqual(count, 1) }
            recovery.stop()
        }
    }

    func testBackoffCapAndServerClassification() {
        XCTAssertEqual(RecoveryPolicy.delay(failures: 50), 15)
        XCTAssertTrue(RecoveryPolicy.isTransient(TranslationFailure.server(503)))
        XCTAssertTrue(RecoveryPolicy.isTransient(SpeechFailure.server(502)))
        XCTAssertFalse(RecoveryPolicy.isTransient(TranslationFailure.server(400)))
        XCTAssertFalse(RecoveryPolicy.isTransient(SpeechFailure.invalidAudio))
    }

    func testTaskCancellationWhileWaitingDoesNotUpload() async {
        let recovery = NetworkRecovery()
        recovery.start(monitorNetwork: false); recovery.updatePath(available: false)
        defer { recovery.stop() }
        let task = Task {
            try await recovery.perform(channel: .speech, isCurrent: { true }) { XCTFail("Uploaded offline"); return 1 }
        }
        await Task.yield(); task.cancel()
        do { _ = try await task.value; XCTFail("Cancellation ignored") }
        catch { XCTAssertTrue(error is CancellationError) }
    }
}
