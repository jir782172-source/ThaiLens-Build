import XCTest
@testable import ThaiLens

final class WireTests: XCTestCase {
    func testSplitAndCoalescedPackets() throws {
        let first = try Wire.encode(WirePacket(kind: "hello"))
        let second = try Wire.encode(WirePacket(kind: "configure", mode: .audio))
        let data = first + second
        var decoder = PacketDecoder()
        var result: [WirePacket] = []
        for byte in data { result += try decoder.append(Data([byte])) }
        XCTAssertEqual(result.map(\.kind), ["hello", "configure"])
        XCTAssertEqual(result.last?.mode, .audio)
        var batch = PacketDecoder()
        XCTAssertEqual(try batch.append(data).count, 2)
    }

    func testRejectsWrongToken() throws {
        var decoder = PacketDecoder()
        var packet = WirePacket(kind: "image")
        packet.token = "wrong-build"
        XCTAssertThrowsError(try decoder.append(Wire.encode(packet)))
    }

    func testRejectsOversizedFrameBeforeAllocatingBody() {
        var decoder = PacketDecoder()
        XCTAssertThrowsError(try decoder.append(Data([255, 255, 255, 255])))
    }

    func testPCMValidation() {
        XCTAssertTrue(PCMChunk(rate: 48000, frames: 2, samples: Data(count: 8), sequence: 1).isValid)
        XCTAssertFalse(PCMChunk(rate: .nan, frames: 2, samples: Data(count: 8), sequence: 1).isValid)
        XCTAssertFalse(PCMChunk(rate: 48000, frames: 3, samples: Data(count: 8), sequence: 1).isValid)
    }

    func testThaiFilteringPreservesNumbersOnThaiLines() {
        XCTAssertEqual(TextTools.thaiLines("Hello\nราคา 120 บาท\n中文\nสวัสดี"), "ราคา 120 บาท\nสวัสดี")
        XCTAssertEqual(TextTools.thaiLines("中文 English 123"), "")
        XCTAssertEqual(TextTools.normalized("สวัสดี  \nครับ"), "สวัสดี ครับ")
    }
}
