import XCTest
import CryptoKit
@testable import ThaiLens

final class ConfigurationTests: XCTestCase {
    private let now = ISO8601DateFormatter().date(from: "2026-11-19T00:00:00Z")!
    private func object(_ overrides: [String: Any] = [:]) -> [String: Any] {
        var value: [String: Any] = ["schema":1, "revision":3, "minimumBuild":6,
            "validUntil":"2027-02-15T00:00:00Z", "translationPrompt":"把下面的泰文翻译成中文，不要猜测人物关系。",
            "glossary":[["thai":"แฟนสาว","chinese":"女朋友"]],
            "speechStableSeconds":0.55, "maximumSpeechWait":1.5,
            "requestInterval":2.5, "pageSeconds":6, "notes":"测试配置"]
        for (key, item) in overrides { value[key] = item }
        return value
    }
    private func signed(_ object: [String: Any], key: Curve25519.Signing.PrivateKey) throws -> Data {
        let payload = try JSONSerialization.data(withJSONObject: object, options: [.sortedKeys])
        return try JSONEncoder().encode(ConfigurationEnvelope.Envelope(payload: payload.base64EncodedString(),
                                        signature: key.signature(for: payload).base64EncodedString()))
    }

    func testValidSignedConfigurationChangesOnlySupportedParameters() throws {
        let key = Curve25519.Signing.PrivateKey()
        let data = try signed(object(), key: key)
        let configuration = try ConfigurationEnvelope.decode(data, publicKey: key.publicKey.rawRepresentation,
                                                             now: now, build: 6)
        XCTAssertEqual(configuration.revision, 3)
        XCTAssertEqual(configuration.glossary.first?.chinese, "女朋友")
        let request = try CloudTranslator.request(text: "แฟนสาวของคุณ", apiKey: "gsk_test-key-placeholder", configuration: configuration)
        XCTAssertEqual(request.url, CloudTranslator.endpoint)
        let body = try XCTUnwrap(JSONSerialization.jsonObject(with: XCTUnwrap(request.httpBody)) as? [String: Any])
        XCTAssertEqual(body["model"] as? String, "qwen/qwen3.8-27b")
    }

    func testModifiedPayloadAndWrongSignatureAreRejected() throws {
        let key = Curve25519.Signing.PrivateKey()
        let valid = try signed(object(), key: key)
        let decoded = try JSONDecoder().decode(ConfigurationEnvelope.Envelope.self, from: valid)
        let changed = try JSONSerialization.data(withJSONObject: object(["revision":4]))
        let tampered = try JSONEncoder().encode(ConfigurationEnvelope.Envelope(payload: changed.base64EncodedString(),
                                                                 signature: decoded.signature))
        XCTAssertThrowsError(try ConfigurationEnvelope.decode(tampered, publicKey: key.publicKey.rawRepresentation,
                                                               now: now, build: 6))
        XCTAssertThrowsError(try ConfigurationEnvelope.decode(valid,
            publicKey: Curve25519.Signing.PrivateKey().publicKey.rawRepresentation, now: now, build: 6))
    }
    func testQwenPromptCanHotUpdateWithoutChangingLegacyPromptOrProvider() throws {
        let key = Curve25519.Signing.PrivateKey()
        let prompt = "只翻译成中文，保留原文的人称与否定，不猜测性别。"
        let data = try signed(object(["qwenPrompt": prompt]), key: key)
        let config = try ConfigurationEnvelope.decode(data, publicKey: key.publicKey.rawRepresentation,
                                                      now: now, build: 8)
        let request = try CloudTranslator.request(text: "คุณมีแฟนหรือยัง", apiKey: "gsk_test-key-placeholder", configuration: config)
        let body = try XCTUnwrap(JSONSerialization.jsonObject(with: XCTUnwrap(request.httpBody)) as? [String: Any])
        let messages = try XCTUnwrap(body["messages"] as? [[String: String]])
        XCTAssertTrue(messages[0]["content"]?.hasPrefix(prompt) == true)
        XCTAssertNotEqual(config.translationPrompt, prompt)
        XCTAssertEqual(request.url?.host, "api.groq.com")
    }
    func testLegacyConfigUsesTestedQwenFallbackAndRejectsEmptyNewPrompt() throws {
        let key = Curve25519.Signing.PrivateKey()
        let config = try ConfigurationEnvelope.decode(signed(object(), key: key), publicKey: key.publicKey.rawRepresentation,
                                                      now: now, build: 8)
        XCTAssertNil(config.qwenPrompt)
        let request = try CloudTranslator.request(text: "ผมไม่มีแฟน", apiKey: "gsk_test-key-placeholder", configuration: config)
        let body = try XCTUnwrap(JSONSerialization.jsonObject(with: XCTUnwrap(request.httpBody)) as? [String: Any])
        let messages = try XCTUnwrap(body["messages"] as? [[String: String]])
        XCTAssertTrue(messages[0]["content"]?.hasPrefix(TranslationConfiguration.qwenDefaultPrompt) == true)
        XCTAssertThrowsError(try ConfigurationEnvelope.decode(signed(object(["qwenPrompt":""]), key: key),
                              publicKey: key.publicKey.rawRepresentation, now: now, build: 8))
    }

    func testExpiredNewerAppAndOutOfRangeConfigurationsAreRejected() throws {
        let key = Curve25519.Signing.PrivateKey()
        let changes: [[String: Any]] = [["validUntil":"2026-01-01T00:00:00Z"], ["minimumBuild":7],
                                     ["schema":2], ["requestInterval":0.1], ["pageSeconds":0],
                                     ["maximumSpeechWait":0.1], ["translationPrompt":""],
                                     ["validUntil":"2030-01-01T00:00:00Z"]]
        for change in changes {
            XCTAssertThrowsError(try ConfigurationEnvelope.decode(signed(object(change), key: key),
                publicKey: key.publicKey.rawRepresentation, now: now, build: 6))
        }
    }

    func testOlderRevisionCannotReplaceNewerInstalledConfiguration() throws {
        let key = Curve25519.Signing.PrivateKey()
        let data = try signed(object(), key: key)
        XCTAssertThrowsError(try ConfigurationEnvelope.decode(data, publicKey: key.publicKey.rawRepresentation,
                                                               now: now, build: 6, minimumRevision: 4))
    }

    func testPublishedFixtureUsesPinnedPublicKey() throws {
        XCTAssertGreaterThan(UpdateTrust.issueNumber, 0)
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "signed-config", withExtension: "json"))
        let configuration = try ConfigurationEnvelope.decode(Data(contentsOf: url),
            publicKey: XCTUnwrap(Data(base64Encoded: UpdateTrust.publicKeyBase64)), now: now, build: 6)
        XCTAssertEqual(configuration.revision, 1)
        XCTAssertTrue(configuration.translationPrompt.contains("แฟน"))
    }

    func testConfigurationIssueMustHaveExpectedAuthorNumberAndTitle() throws {
        func issue(_ overrides: [String: Any] = [:]) throws -> Data {
            var value: [String:Any] = ["number":2,"title":ConfigurationClient.title,
                                      "user":["login":"jir782172-source"],"body":"{}"]
            for (key, item) in overrides { value[key] = item }
            return try JSONSerialization.data(withJSONObject:value)
        }
        XCTAssertEqual(try ConfigurationClient.envelope(from: issue(), issueNumber: 2), Data("{}".utf8))
        let changes: [[String:Any]] = [["number":3], ["title":"unexpected"], ["user":["login":"someone-else"]],
                                      ["pull_request":["url":"https://example.invalid"]]]
        for change in changes {
            XCTAssertThrowsError(try ConfigurationClient.envelope(from: issue(change), issueNumber: 2))
        }
    }

    func testUpdateFetchUsesOnlyGETAndExistingPrivateRepository() async throws {
        let options = URLSessionConfiguration.ephemeral
        options.protocolClasses = [ConfigurationStub.self]
        let session = URLSession(configuration: options)
        defer { session.invalidateAndCancel() }
        let result = try await ConfigurationClient().fetch(token: "github_pat_test", issueNumber: 2, session: session)
        XCTAssertEqual(result, Data("{}".utf8))
    }

    func testPublicRepositoryBlocksConfigurationRead() async {
        let options = URLSessionConfiguration.ephemeral
        options.protocolClasses = [ConfigurationStub.self]
        let session = URLSession(configuration: options)
        defer { session.invalidateAndCancel() }
        do {
            _ = try await ConfigurationClient().fetch(token: "github_pat_public", issueNumber: 2, session: session)
            XCTFail("Public repository unexpectedly accepted")
        } catch { XCTAssertTrue(error is DiagnosticUploadFailure) }
    }
}

private final class ConfigurationStub: URLProtocol {
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        XCTAssertEqual(request.url?.host, "api.github.com")
        XCTAssertEqual(request.httpMethod, "GET")
        XCTAssertNil(request.httpBody)
        let isPublic = request.value(forHTTPHeaderField: "Authorization") == "Bearer github_pat_public"
        let isIssue = request.url?.path.hasSuffix("/issues/2") == true
        XCTAssertFalse(isPublic && isIssue, "Public metadata must prevent issue reads")
        let data: Data
        if isIssue {
            data = try! JSONSerialization.data(withJSONObject: ["number":2,"title":ConfigurationClient.title,
                        "user":["login":"jir782172-source"],"body":"{}"])
        } else {
            XCTAssertEqual(request.url?.path, "/repos/jir782172-source/ThaiLens")
            data = try! JSONSerialization.data(withJSONObject: ["private":!isPublic,"full_name":"jir782172-source/ThaiLens"])
        }
        let response = HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: "HTTP/1.1", headerFields: nil)!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: data)
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}
