import XCTest
import UIKit
@testable import ThaiLens

@MainActor
final class SubtitleLayoutTests: XCTestCase {
    private let sample = String(repeating: "这是一段专门检查字幕排版的示例。文字应该自动换行，完整显示每个句子，长段落则依次翻到下一页。阅读时可以暂停，准备好以后继续。", count: 4) + "最后一句也必须看得见。"

    func testChineseWrapsAndEveryCharacterSurvivesPagination() {
        let document = SubtitleDocument(sample)
        XCTAssertGreaterThan(document.pageCount, 1)
        XCTAssertGreaterThan(document.lineCount(0), 1)
        XCTAssertEqual((0..<document.pageCount).map(document.pageText).joined(), sample)
        XCTAssertTrue(document.pageText(document.pageCount - 1).contains("最后一句也必须看得见。"))
    }

    func testEmojiThaiNewlinesAndUnbrokenWordsFitWithoutLosingText() {
        let text = String(repeating: "中文👨‍👩‍👧‍👦🇹🇭🙂 ภาษาไทย\n", count: 20) + String(repeating: "longword", count: 40)
        let document = SubtitleDocument(text)
        XCTAssertEqual((0..<document.pageCount).map(document.pageText).joined(), text)
        for page in 0..<document.pageCount {
            XCTAssertFalse(document.pageText(page).contains("�"))
            XCTAssertLessThanOrEqual(document.usedRect(page).maxY, SubtitleDocument.bodyRect.height + 1)
            XCTAssertLessThanOrEqual(document.usedRect(page).maxX, SubtitleDocument.bodyRect.width + 1)
        }
    }

    func testAutomaticPagesRepeatAndIdenticalUpdatesDoNotResetReading() {
        var pager = SubtitlePager()
        let document = SubtitleDocument(sample)
        pager.replace(document, now: 0)
        XCTAssertFalse(pager.tick(now: 5))
        XCTAssertTrue(pager.tick(now: 6))
        XCTAssertEqual(pager.page, 1)
        pager.submit(SubtitleDocument(sample), now: 7)
        XCTAssertEqual(pager.page, 1)
        XCTAssertTrue(pager.tick(now: 12))
        XCTAssertEqual(pager.page, 2)
        for step in 3...document.pageCount { _ = pager.tick(now: Double(step) * 6) }
        XCTAssertEqual(pager.page, 0)
    }

    func testPauseFreezesReadingWhileManualPagingRemainsAvailable() {
        var pager = SubtitlePager()
        pager.replace(SubtitleDocument(sample), now: 0)
        pager.setPlaying(false, now: 1)
        pager.submit(SubtitleDocument("新的字幕"), now: 2)
        XCTAssertFalse(pager.tick(now: 100))
        XCTAssertEqual(pager.document.text, sample)
        pager.move(1, now: 100)
        XCTAssertEqual(pager.page, 1)
        pager.move(-1, now: 101)
        XCTAssertEqual(pager.page, 0)
        XCTAssertFalse(pager.playing)
        pager.latest(now: 102)
        XCTAssertEqual(pager.document.text, "新的字幕")
    }

    func testUnreadPagesCompleteBeforeNewestPendingCaptionReplacesThem() {
        var pager = SubtitlePager()
        pager.replace(SubtitleDocument(sample), now: 0)
        pager.submit(SubtitleDocument("旧的等待字幕"), now: 1)
        pager.submit(SubtitleDocument("最新等待字幕"), now: 2)
        let count = pager.document.pageCount
        for step in 1..<count {
            _ = pager.tick(now: Double(step) * 6)
            XCTAssertEqual(pager.document.text, sample)
        }
        _ = pager.tick(now: Double(count) * 6)
        XCTAssertEqual(pager.document.text, "最新等待字幕")
        XCTAssertNil(pager.pending)
    }

    func testResumingPausedWindowImmediatelyShowsLatestCaption() {
        var pager = SubtitlePager()
        pager.replace(SubtitleDocument("旧字幕"), now: 0)
        pager.setPlaying(false, now: 1)
        pager.submit(SubtitleDocument("新字幕一"), now: 2, realtime: true)
        pager.submit(SubtitleDocument("最新字幕"), now: 3, realtime: true)
        XCTAssertEqual(pager.document.text, "旧字幕")
        pager.setPlaying(true, now: 4)
        XCTAssertEqual(pager.document.text, "最新字幕")
        XCTAssertNil(pager.pending)
    }

    func testGrowingTranscriptPreservesPageAndDwellDeadline() {
        var pager = SubtitlePager()
        pager.replace(SubtitleDocument(sample), now: 0)
        _ = pager.tick(now: 6)
        pager.submit(SubtitleDocument(sample + "这是一句新补充的内容。"), now: 10)
        XCTAssertEqual(pager.page, 1)
        XCTAssertTrue(pager.tick(now: 12))
        XCTAssertEqual(pager.page, 2)
    }

    func testStatusReplacementClearsPendingAndFiniteTimelineTracksPages() {
        var pager = SubtitlePager()
        pager.replace(SubtitleDocument(sample), now: 0)
        _ = pager.tick(now: 6)
        XCTAssertEqual(pager.playbackTime(now: 9), 22.5, accuracy: 0.01)
        pager.submit(SubtitleDocument("等候的新内容"), now: 10)
        pager.replace(SubtitleDocument("已停止采集"), now: 11)
        XCTAssertEqual(pager.page, 0)
        XCTAssertNil(pager.pending)
        XCTAssertEqual(pager.playbackTime(now: 11), 0)
        XCTAssertTrue(pager.tick(now: 17))
        XCTAssertEqual(pager.playbackTime(now: 17), 0)
    }

    func testRenderedChineseHasInkBelowFirstLineAndExportsActualPreviews() throws {
        let document = SubtitleDocument(sample)
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        format.opaque = true
        format.preferredRange = .standard
        let renderer = UIGraphicsImageRenderer(size: SubtitleDocument.canvasSize, format: format)
        let directory = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("SubtitlePreviews", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        for page in [0, 1, document.pageCount - 1] {
            let image = renderer.image { _ in
                document.draw(page: page, title: "泰语 → 中文 · Qwen 翻译", footer: "自动翻页 · 每页 6 秒")
            }
            try XCTUnwrap(image.pngData()).write(to: directory.appendingPathComponent("subtitle-page-\(page + 1).png"))
            if page == 0 {
                let cg = try XCTUnwrap(image.cgImage)
                let data = try XCTUnwrap(cg.dataProvider?.data)
                let bytes = try XCTUnwrap(CFDataGetBytePtr(data))
                let stride = cg.bitsPerPixel / 8
                XCTAssertGreaterThanOrEqual(stride, 4)
                var whitePixels = 0
                for y in 150..<300 {
                    for x in 36..<924 {
                        let offset = y * cg.bytesPerRow + x * stride
                        if bytes[offset] > 190, bytes[offset + 1] > 190, bytes[offset + 2] > 190 { whitePixels += 1 }
                    }
                }
                XCTAssertGreaterThan(whitePixels, 500, "Rendered subtitle must occupy multiple visible lines")
            }
        }
    }
}
