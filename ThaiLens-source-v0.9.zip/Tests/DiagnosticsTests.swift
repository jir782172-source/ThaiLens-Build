import XCTest
import Network
@testable import ThaiLens

final class DiagnosticsTests: XCTestCase {
    func testDiagnosticNeverSerializesErrorDescriptionsOrUnknownDomains() throws {
        let secret = "sk-test-secret-not-real"
        let error = NSError(domain: "https://example.invalid/\(secret)", code: 22,
                            userInfo: [NSLocalizedDescriptionKey: "private chat \(secret)",
                                       NSUnderlyingErrorKey: NSError(domain: secret, code: 9)])
        let event = DiagnosticEvent(stage: .localConnection, mode: .audio, error: error)
        let body = try GitHubDiagnostics.body(events: [event])
        XCTAssertFalse(body.contains(secret))
        XCTAssertFalse(body.contains("private chat"))
        XCTAssertFalse(body.contains("example.invalid"))
        XCTAssertEqual(event.domain, "other")
        XCTAssertEqual(event.code, 22)
    }

    func testNWErrorPreservesPOSIXCodeAndExplainsCorrectStage() {
        let error = NWError.posix(.EINVAL)
        let event = DiagnosticEvent(stage: .localConnection, mode: .audio, error: error)
        XCTAssertEqual(event.domain, "POSIX")
        XCTAssertEqual(event.code, 22)
        let text = DiagnosticEvent.userMessage(stage: .localConnection, error: error)
        XCTAssertTrue(text.contains("本机录屏连接"))
        XCTAssertTrue(text.contains("22"))
    }

    func testPublicOrUnexpectedRepositoryIsRejected() {
        for json in [#"{"private":false,"full_name":"jir782172-source/ThaiLens"}"#,
                     #"{"private":true,"full_name":"other/repo"}"#, "{}"] {
            XCTAssertThrowsError(try GitHubDiagnostics.validateRepository(Data(json.utf8)))
        }
    }

    func testRequestUsesOnlyGitHubAndKeepsTokenOutOfBodyAndURL() throws {
        let token = "github_pat_test_only"
        let request = try GitHubDiagnostics.request(path: "/issues", method: "POST", token: token,
                                                   body: Data("{}".utf8))
        XCTAssertEqual(request.url?.host, "api.github.com")
        XCTAssertNil(request.url?.query)
        XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer \(token)")
        XCTAssertFalse(String(decoding: request.httpBody!, as: UTF8.self).contains(token))
        XCTAssertThrowsError(try GitHubDiagnostics.request(token: "sk-wrong-provider"))
        XCTAssertThrowsError(try GitHubDiagnostics.request(token: "github_pat_test\nInjected: true"))
    }

    func testPublicRepositoryPreventsEveryWrite() async throws {
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [PublicRepoStub.self]
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }
        do {
            _ = try await GitHubDiagnostics().upload(events: [DiagnosticEvent(stage: .uploadTest, mode: .screen)],
                token: "github_pat_test_only", issueNumber: 12, session: session)
            XCTFail("Public repo accepted")
        } catch DiagnosticUploadFailure.publicRepository { }
    }

    func testPrivateRepositoryCreatesThenUpdatesExistingIssue() async throws {
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [PrivateRepoStub.self]
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }
        let events = [DiagnosticEvent(stage: .uploadTest, mode: .screen)]
        let first = try await GitHubDiagnostics().upload(events: events, token: "github_pat_test_only",
            issueNumber: nil, session: session)
        XCTAssertEqual(first, 27)
        let second = try await GitHubDiagnostics().upload(events: events, token: "github_pat_test_only",
            issueNumber: first, session: session)
        XCTAssertEqual(second, first)
    }
}

private class DiagnosticStub: URLProtocol {
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    func reply(_ json: String, status: Int = 200) {
        client?.urlProtocol(self, didReceive: HTTPURLResponse(url: request.url!, statusCode: status,
            httpVersion: "HTTP/1.1", headerFields: nil)!, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: Data(json.utf8))
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}
private final class PublicRepoStub: DiagnosticStub {
    override func startLoading() {
        XCTAssertEqual(request.httpMethod, "GET", "Must never send log content to a public repo")
        reply(#"{"private":false,"full_name":"jir782172-source/ThaiLens"}"#)
    }
}
private final class PrivateRepoStub: DiagnosticStub {
    override func startLoading() {
        switch request.url!.path {
        case "/repos/jir782172-source/ThaiLens":
            XCTAssertEqual(request.httpMethod, "GET")
            reply(#"{"private":true,"full_name":"jir782172-source/ThaiLens"}"#)
        case "/repos/jir782172-source/ThaiLens/issues":
            XCTAssertEqual(request.httpMethod, "POST")
            reply(#"{"number":27}"#, status: 201)
        case "/repos/jir782172-source/ThaiLens/issues/27":
            XCTAssertEqual(request.httpMethod, "PATCH")
            reply(#"{"number":27}"#)
        default:
            XCTFail("Unexpected path")
            reply("{}", status: 404)
        }
    }
}
