import XCTest
@testable import ThaiLens

final class GroqSpeechTests: XCTestCase {
    private func chunk(_ second: UInt64, value: Float = 0.1, rate: Double = 8000) -> PCMChunk {
        let samples = [Float](repeating: value, count: Int(rate))
        return PCMChunk(rate: rate, frames: samples.count, samples: samples.withUnsafeBytes { Data($0) }, sequence: second)
    }
    private func window() -> SpeechAudioWindow {
        SpeechAudioWindow(group: UUID(), revision: 1, rate: 8000,
                          pcm: Data(repeating: 0, count: 16000), isFinal: true, overlapsPrevious: false)
    }
    func testSilenceIsNeverUploaded() {
        var segmenter = SpeechSegmenter()
        for i in 0..<120 { XCTAssertNil(segmenter.append(chunk(UInt64(i), value: 0)).window) }
    }
    func testContinuousSpeechIsRevisedWithFullContextAndBoundedOverlap() throws {
        var segmenter = SpeechSegmenter()
        var windows: [SpeechAudioWindow] = []
        for i in 0..<30 {
            if let window = segmenter.append(chunk(UInt64(i))).window { windows.append(window) }
        }
        XCTAssertEqual(windows.count, 5)
        XCTAssertEqual(windows[0].duration, 6)
        XCTAssertFalse(windows[0].isFinal)
        XCTAssertEqual(windows[1].duration, 12)
        XCTAssertTrue(windows[1].isFinal)
        XCTAssertEqual(windows[0].group, windows[1].group)
        XCTAssertEqual(windows[1].revision, 2)
        XCTAssertEqual(windows[2].duration, 7)
        XCTAssertNotEqual(windows[1].group, windows[2].group)
        XCTAssertTrue(windows[2].overlapsPrevious)
        XCTAssertTrue(windows.allSatisfy { $0.duration <= 12 })
    }
    func testPauseFlushesShortUtteranceAndResetsRelationshipContext() throws {
        var segmenter = SpeechSegmenter()
        XCTAssertNil(segmenter.append(chunk(0)).window)
        let first = try XCTUnwrap(segmenter.append(chunk(1, value: 0)).window)
        XCTAssertTrue(first.isFinal)
        XCTAssertEqual(first.duration, 2)
        XCTAssertNil(segmenter.append(chunk(2, value: 0)).window)
        XCTAssertNil(segmenter.append(chunk(3)).window)
        let next = try XCTUnwrap(segmenter.append(chunk(4, value: 0)).window)
        XCTAssertNotEqual(first.group, next.group)
        XCTAssertFalse(next.overlapsPrevious)
    }
    func testDroppedPacketsNeverSpliceUnrelatedAudio() {
        var segmenter = SpeechSegmenter()
        for i in 0..<5 { XCTAssertNil(segmenter.append(chunk(UInt64(i))).window) }
        let output = segmenter.append(chunk(8))
        XCTAssertTrue(output.discontinuity)
        XCTAssertNil(output.window)
        let changedRate = segmenter.append(chunk(9, rate: 16000))
        XCTAssertTrue(changedRate.discontinuity)
        XCTAssertNil(changedRate.window)
    }
    func testWAVHeaderAndPCMMatchActualSampleRateAndSignedSamples() throws {
        var segmenter = SpeechSegmenter()
        _ = segmenter.append(chunk(0, value: -0.5))
        let window = try XCTUnwrap(segmenter.append(chunk(1, value: 0)).window)
        let wav = window.wav
        XCTAssertEqual(String(decoding: wav.prefix(4), as: UTF8.self), "RIFF")
        XCTAssertEqual(String(decoding: wav[8..<16], as: UTF8.self), "WAVEfmt ")
        XCTAssertEqual(wav.count, 44 + 32000)
        wav.withUnsafeBytes {
            XCTAssertEqual($0.loadUnaligned(fromByteOffset: 24, as: UInt32.self).littleEndian, 8000)
            XCTAssertEqual($0.loadUnaligned(fromByteOffset: 40, as: UInt32.self).littleEndian, 32000)
            XCTAssertEqual($0.loadUnaligned(fromByteOffset: 44, as: Int16.self).littleEndian, -16384)
        }
    }
    func testMultipartUsesThaiTranscriptionAndCredentialOnlyInHeader() throws {
        let request = try GroqSpeechClient.request(window(), apiKey: "gsk_test_only_credential")
        XCTAssertEqual(request.url?.absoluteString, "https://api.groq.com/openai/v1/audio/transcriptions")
        XCTAssertNil(request.url?.query)
        let bytes = try XCTUnwrap(request.httpBody)
        let body = String(decoding: bytes, as: UTF8.self)
        XCTAssertTrue(body.contains("name=\"language\"\r\n\r\nth\r\n"))
        XCTAssertTrue(body.contains("whisper-large-v3"))
        XCTAssertTrue(body.contains("verbose_json"))
        XCTAssertTrue(body.contains("RIFF"))
        XCTAssertFalse(body.contains("gsk_test_only_credential"))
        XCTAssertFalse(body.contains("name=\"prompt\""))
    }
    func testWrongProviderAndInjectedKeysAreRejected() {
        for key in ["", "sk_siliconflow", "gsk_test\r\nX: bad"] {
            XCTAssertThrowsError(try GroqSpeechClient.request(window(), apiKey: key))
        }
    }
    func testRecognizedThaiIsPreservedWithoutGenderSubstitution() throws {
        let json = #"{"text":"แฟนสาวของคุณอยู่ที่ไหน","segments":[{"text":"แฟนสาวของคุณอยู่ที่ไหน","avg_logprob":-0.1,"no_speech_prob":0.01,"compression_ratio":1.2}]}"#
        let result = try GroqSpeechClient.decode(Data(json.utf8), status: 200)
        XCTAssertEqual(result.text, "แฟนสาวของคุณอยู่ที่ไหน")
        XCTAssertFalse(result.uncertain)
    }
    func testLikelySilenceIsDroppedAsAWholeWithoutDeletingJustNegation() throws {
        let json = #"{"text":"ฉันไม่รักคุณ","segments":[{"text":"ฉัน","avg_logprob":-0.1},{"text":"ไม่รักคุณ","avg_logprob":-1.5,"no_speech_prob":0.9}]}"#
        let result = try GroqSpeechClient.decode(Data(json.utf8), status: 200)
        XCTAssertTrue(result.text.isEmpty)
        XCTAssertTrue(result.uncertain)
    }
    func testQuotaAuthorizationPaymentAndMalformedResponsesAreNotSubtitles() {
        for code in [401, 402, 403, 404, 429, 500] {
            XCTAssertThrowsError(try GroqSpeechClient.decode(Data(#"{"text":"สวัสดี"}"#.utf8), status: code))
        }
        for body in ["{}", "bad-json"] { XCTAssertThrowsError(try GroqSpeechClient.decode(Data(body.utf8), status: 200)) }
    }
    func testOverlapDoesNotDeleteCompleteRepeatedUtterance() {
        XCTAssertEqual(SpeechOverlap.removingRepeatedPrefix("123456789你好", previous: "xxx123456789"), "你好")
        XCTAssertEqual(SpeechOverlap.removingRepeatedPrefix("123456789", previous: "123456789"), "123456789")
        XCTAssertEqual(SpeechOverlap.removingRepeatedPrefix("", previous: "test"), "")
    }
    func testBudgetEnforcesMinuteHourDayAndSurvivesSerialization() throws {
        var minute = SpeechBudget()
        for i in 0..<15 { try minute.reserve(duration: 1, now: Double(i * 3)) }
        XCTAssertThrowsError(try minute.reserve(duration: 1, now: 50))
        XCTAssertEqual(minute.entries.first?.seconds, 10)
        let stored = try JSONEncoder().encode(minute)
        XCTAssertEqual(try JSONDecoder().decode(SpeechBudget.self, from: stored).entries.count, 15)
        var hour = SpeechBudget(entries: [.init(time: 0, seconds: 6900)])
        XCTAssertThrowsError(try hour.reserve(duration: 1, now: 10))
        XCTAssertNoThrow(try hour.reserve(duration: 1, now: 3601))
        var day = SpeechBudget(entries: [.init(time: 0, seconds: 27000)])
        XCTAssertThrowsError(try day.reserve(duration: 1, now: 4000))
        XCTAssertNoThrow(try day.reserve(duration: 1, now: 86401))
    }
    func testRelationshipChecksWarnWithoutRewritingMixedGenderConversation() {
        XCTAssertNotNil(TranslationReview.warning(source: "แฟนสาวของคุณอยู่ที่ไหน", chinese: "你的男朋友在哪里"))
        XCTAssertNotNil(TranslationReview.warning(source: "คุณอยู่ที่ไหน", chinese: "他在哪里"))
        XCTAssertNil(TranslationReview.warning(source: "ฉันอยากคุยกับคุณ ไม่ใช่เขา", chinese: "我想和你聊，不是他"))
        XCTAssertNil(TranslationReview.warning(source: "แฟนสาว แฟนหนุ่ม", chinese: "女朋友和男朋友"))
    }
    func testSafeDiagnosticsNeverIncludeResponseOrKey() throws {
        let event = DiagnosticEvent(stage: .speech, mode: .audio, error: SpeechFailure.quota)
        XCTAssertEqual(event.domain, "Groq-ASR")
        XCTAssertEqual(event.code, 429)
        XCTAssertFalse(DiagnosticEvent.userMessage(stage: .speech, error: SpeechFailure.quota).contains("苹果"))
    }
    func testInjectedHTTPClientAndCancellation() async throws {
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [SpeechStub.self]
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }
        let client = GroqSpeechClient(session: session)
        let result = try await client.transcribe(window(), apiKey: "gsk_test_only_credential")
        XCTAssertEqual(result.text, "สวัสดี")
        let sample = window()
        let task = Task {
            withUnsafeCurrentTask { $0?.cancel() }
            return try await client.transcribe(sample, apiKey: "gsk_test_only_credential")
        }
        do { _ = try await task.value; XCTFail("Cancelled audio returned") }
        catch { XCTAssertTrue(error is CancellationError) }
    }
    @MainActor func testStoppingRecognitionRejectsLateHTTPResult() async throws {
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [SpeechStub.self]
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }
        let speech = ThaiSpeech(client: GroqSpeechClient(session: session))
        var callbacks = 0
        speech.onText = { _ in callbacks += 1 }
        try speech.start(apiKey: "gsk_test_only_credential")
        for i in 0..<6 { speech.append(chunk(UInt64(i))) }
        await Task.yield()
        speech.stop()
        try await Task.sleep(for: .milliseconds(300))
        XCTAssertEqual(callbacks, 0)
    }
}

private final class SpeechStub: URLProtocol {
    private let lock = NSLock()
    private var cancelled = false
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        DispatchQueue.global().asyncAfter(deadline: .now() + 0.1) { [self] in
            lock.lock(); defer { lock.unlock() }
            guard !cancelled else { return }
            let response = HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: "HTTP/1.1", headerFields: nil)!
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: Data(#"{"text":"สวัสดี"}"#.utf8))
            client?.urlProtocolDidFinishLoading(self)
        }
    }
    override func stopLoading() { lock.lock(); cancelled = true; lock.unlock() }
}
