import XCTest
@testable import ThaiLens

@MainActor
final class SpeechRecoveryTests: XCTestCase {
    private func chunk(_ sequence: UInt64, value: Float = 0.1) -> PCMChunk {
        let samples = [Float](repeating: value, count: 8000)
        return PCMChunk(rate: 8000, frames: samples.count,
                        samples: samples.withUnsafeBytes { Data($0) }, sequence: sequence)
    }
    func testSpeechContinuesAfterHTTPConnectionLost() async throws {
        let options = URLSessionConfiguration.ephemeral
        options.protocolClasses = [RecoverySpeechStub.self]
        let session = URLSession(configuration: options)
        defer { session.invalidateAndCancel() }
        RecoverySpeechStub.reset()
        let recovery = NetworkRecovery()
        recovery.start(monitorNetwork: false)
        defer { recovery.stop() }
        let speech = ThaiSpeech(client: GroqSpeechClient(session: session), recovery: recovery)
        defer { speech.stop() }
        let translated = expectation(description: "recognized after reconnect")
        speech.onText = { update in
            XCTAssertEqual(update.text, "สวัสดี"); translated.fulfill()
        }
        speech.onError = { _ in XCTFail("Transient error stopped speech") }
        try speech.start(apiKey: "gsk_test_only_placeholder")
        speech.append(chunk(0)); speech.append(chunk(1, value: 0))
        await fulfillment(of: [translated], timeout: 12)
        XCTAssertEqual(RecoverySpeechStub.attemptCount, 2)
        XCTAssertTrue(recovery.active)
    }
}

private final class RecoverySpeechStub: URLProtocol {
    private static let lock = NSLock()
    private static var attempts = 0
    static var attemptCount: Int { lock.lock(); defer { lock.unlock() }; return attempts }
    static func reset() { lock.lock(); attempts = 0; lock.unlock() }
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        Self.lock.lock(); Self.attempts += 1; let count = Self.attempts; Self.lock.unlock()
        if count == 1 { client?.urlProtocol(self, didFailWithError: URLError(.networkConnectionLost)); return }
        let response = HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: "HTTP/1.1", headerFields: nil)!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: Data(#"{"text":"สวัสดี"}"#.utf8))
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}
