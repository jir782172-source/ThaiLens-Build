import XCTest
import Network
@testable import ThaiLens

final class CaptureServerTests: XCTestCase {
    @MainActor
    func testLoopbackListenerStartsAndExchangesAuthenticatedPackets() async throws {
        let server = CaptureServer()
        defer { server.stop() }
        let ready = expectation(description: "loopback listener ready")
        server.onReady = { ready.fulfill() }
        server.onFailure = { error in XCTFail("Listener failed: \(error)"); ready.fulfill() }
        try server.start(mode: .audio)
        await fulfillment(of: [ready], timeout: 8)
        let configured = expectation(description: "broadcast receives configuration")
        let pong = expectation(description: "heartbeat round trip")
        let peer = WirePeer(NWConnection(host: .ipv4(.loopback), port: Wire.port, using: .tcp), queue: .main)
        defer { peer.close() }
        peer.onReady = { peer.send(WirePacket(kind: "hello")) }
        peer.onPacket = { packet in
            if packet.kind == "configure" {
                XCTAssertEqual(packet.mode, .audio)
                configured.fulfill()
                peer.send(WirePacket(kind: "ping"))
            }
            if packet.kind == "pong" { pong.fulfill() }
        }
        peer.start()
        await fulfillment(of: [configured, pong], timeout: 8)
    }

    @MainActor
    func testImmediateRestartDoesNotDeliverCancelledListenerFailure() async throws {
        let server = CaptureServer()
        defer { server.stop() }
        let ready = expectation(description: "replacement listener ready")
        server.onReady = { ready.fulfill() }
        server.onFailure = { error in XCTFail("Restart failed: \(error)"); ready.fulfill() }
        try server.start(mode: .screen)
        server.stop()
        try server.start(mode: .audio)
        await fulfillment(of: [ready], timeout: 8)
    }

    @MainActor
    func testDroppedLocalConnectionCanReauthenticateWithoutRestartingListener() async throws {
        let server = CaptureServer()
        defer { server.stop() }
        let ready = expectation(description: "ready")
        server.onReady = { ready.fulfill() }
        try server.start(mode: .audio)
        await fulfillment(of: [ready], timeout: 8)
        let firstConfigured = expectation(description: "first configured")
        let lost = expectation(description: "recoverable link loss")
        server.onPacket = { if $0.kind == "linkLost" { lost.fulfill() } }
        let first = WirePeer(NWConnection(host: .ipv4(.loopback), port: Wire.port, using: .tcp), queue: .main)
        first.onReady = { first.send(WirePacket(kind: "hello")) }
        first.onPacket = { if $0.kind == "configure" { firstConfigured.fulfill() } }
        first.start()
        await fulfillment(of: [firstConfigured], timeout: 8)
        first.close()
        await fulfillment(of: [lost], timeout: 8)
        let reconnected = expectation(description: "configured again")
        let finished = expectation(description: "explicit finish")
        server.onPacket = { if $0.kind == "finished" { finished.fulfill() } }
        let second = WirePeer(NWConnection(host: .ipv4(.loopback), port: Wire.port, using: .tcp), queue: .main)
        defer { second.close() }
        second.onReady = { second.send(WirePacket(kind: "hello")) }
        second.onPacket = { packet in
            if packet.kind == "configure" {
                XCTAssertEqual(packet.mode, .audio)
                reconnected.fulfill()
                second.send(WirePacket(kind: "finished"))
            }
        }
        second.start()
        await fulfillment(of: [reconnected, finished], timeout: 8)
    }
}
