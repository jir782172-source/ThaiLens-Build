import XCTest
import ReplayKit
@testable import ThaiLens

final class AudioHealthTests: XCTestCase {
    private func chunk(_ values: [Float], sequence: UInt64 = 1) -> PCMChunk {
        PCMChunk(rate: 16_000, frames: values.count,
                 samples: values.withUnsafeBytes { Data($0) }, sequence: sequence)
    }

    func testMicrophoneIsRejectedInEveryModeEvenWhenAppAudioIsMissing() {
        for mode in CaptureMode.allCases {
            for _ in 0..<10 { XCTAssertFalse(CapturePolicy.accepts(.audioMic, mode: mode)) }
        }
        XCTAssertTrue(CapturePolicy.accepts(.audioApp, mode: .audio))
        XCTAssertFalse(CapturePolicy.accepts(.audioApp, mode: .screen))
        XCTAssertFalse(CapturePolicy.accepts(.video, mode: .audio))
        XCTAssertTrue(CapturePolicy.accepts(.video, mode: .screen))
    }

    func testNoBuffersIsDistinctFromReceivingSilentBuffers() {
        var health = AudioHealth()
        health.reset(now: 100)
        XCTAssertEqual(health.state(now: 103), .waiting)
        XCTAssertEqual(health.state(now: 106), .noBuffers)
        health.receive(chunk([0, 0, 0]), now: 108)
        XCTAssertEqual(health.state(now: 108), .silent)
        XCTAssertEqual(health.peak, 0)
    }

    func testIncomingSignalRecoversFromSilenceWithoutMicrophone() {
        var health = AudioHealth()
        health.reset(now: 0)
        health.receive(chunk([0]), now: 8)
        XCTAssertEqual(health.state(now: 8), .silent)
        health.receive(chunk([0.1, -0.4, 0.2]), now: 9)
        XCTAssertEqual(health.state(now: 9), .receiving)
        XCTAssertEqual(health.peak, 0.4, accuracy: 0.001)
        XCTAssertEqual(health.state(now: 15), .noBuffers)
    }

    func testContinuousSignalWithoutRecognitionIsReportedSeparately() {
        var health = AudioHealth()
        health.reset(now: 0)
        for second in 0...13 { health.receive(chunk([0.2]), now: Double(second)) }
        XCTAssertEqual(health.state(now: 13), .noRecognition)
        health.recognized(now: 13)
        XCTAssertEqual(health.state(now: 13), .receiving)
    }

    func testNormalPauseDoesNotBecomeRecognitionFailureOnNextUtterance() {
        var health = AudioHealth()
        health.reset(now: 0)
        health.receive(chunk([0.2]), now: 1)
        health.receive(chunk([0]), now: 20)
        XCTAssertEqual(health.state(now: 20), .silent)
        health.receive(chunk([0.2]), now: 21)
        XCTAssertEqual(health.state(now: 21), .receiving)
    }

    func testInvalidChunksDoNotPretendAudioIsArrivingAndNonfiniteSamplesAreIgnored() {
        var health = AudioHealth()
        health.reset(now: 0)
        var invalid = chunk([1])
        invalid.frames = 2
        health.receive(invalid, now: 8)
        XCTAssertEqual(health.state(now: 8), .noBuffers)
        health.receive(chunk([.nan, .infinity, -.infinity, 0]), now: 9)
        XCTAssertEqual(health.peak, 0)
        XCTAssertEqual(health.state(now: 9), .silent)
    }

    func testNewBroadcastResetsOldAudioAndRecognitionState() {
        var health = AudioHealth()
        health.reset(now: 0)
        health.receive(chunk([0.2]), now: 1)
        health.recognized(now: 2)
        health.reset(now: 50)
        XCTAssertEqual(health.peak, 0)
        XCTAssertEqual(health.state(now: 51), .waiting)
        XCTAssertEqual(health.state(now: 56), .noBuffers)
    }

    func testContinuousPartialsCannotExtendTranslationDebounceToFiveSeconds() {
        XCTAssertTrue(TranslationPacing.isReady(mode: .audio, now: 12.5, lastAttempt: 10,
                      pendingSince: 10.1, lastChange: 12.49, isFinal: false))
        XCTAssertFalse(TranslationPacing.isReady(mode: .audio, now: 12.49, lastAttempt: 10,
                       pendingSince: 10.1, lastChange: 12, isFinal: true))
    }

    func testFirstAudioPartialWaitsForStabilityButFinalDoesNotAddDebounce() {
        XCTAssertFalse(TranslationPacing.isReady(mode: .audio, now: 0.1, lastAttempt: -100,
                       pendingSince: 0, lastChange: 0, isFinal: false))
        XCTAssertTrue(TranslationPacing.isReady(mode: .audio, now: 0.56, lastAttempt: -100,
                      pendingSince: 0, lastChange: 0, isFinal: false))
        XCTAssertTrue(TranslationPacing.isReady(mode: .audio, now: 0.1, lastAttempt: -100,
                      pendingSince: 0, lastChange: 0, isFinal: true))
        XCTAssertTrue(TranslationPacing.isReady(mode: .audio, now: 1.51, lastAttempt: -100,
                      pendingSince: 0, lastChange: 1.5, isFinal: false))
    }

    func testScreenOCRKeepsItsExistingCoalescingPolicy() {
        XCTAssertFalse(TranslationPacing.isReady(mode: .screen, now: 12.5, lastAttempt: 10,
                       pendingSince: 10, lastChange: 12.4, isFinal: false))
        XCTAssertTrue(TranslationPacing.isReady(mode: .screen, now: 15, lastAttempt: 10,
                      pendingSince: 10, lastChange: 14.9, isFinal: false))
    }

    func testAudioDiagnosticsContainOnlyCoarseCodeAndExistingSafeFields() throws {
        let event = DiagnosticEvent(stage: .audioCapture, mode: .audio,
            error: NSError(domain: "ThaiLens", code: 1101,
                           userInfo: [NSLocalizedDescriptionKey: "private speech and secret-token"]))
        let text = String(decoding: try JSONEncoder().encode(event), as: UTF8.self)
        XCTAssertFalse(text.contains("private speech"))
        XCTAssertFalse(text.contains("secret-token"))
        XCTAssertTrue(text.contains("1101"))
        XCTAssertEqual(try JSONDecoder().decode(DiagnosticEvent.self, from: Data(text.utf8)).stage, .audioCapture)
    }
}
