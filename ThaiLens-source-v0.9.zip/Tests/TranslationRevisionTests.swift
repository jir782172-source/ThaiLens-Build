import XCTest
@testable import ThaiLens

@MainActor
final class TranslationRevisionTests: XCTestCase {
    func testSpeechCorrectionDiscardsOlderInFlightTranslation() {
        let group = UUID()
        XCTAssertFalse(TranscriptRevision.canDisplay(candidate: "แฟนหนุ่มของคุณ", current: "แฟนสาวของคุณ",
                         candidateGroup: group, currentGroup: group))
        XCTAssertFalse(TranscriptRevision.canDisplay(candidate: "คุณ", current: "คุณ",
                         candidateGroup: group, currentGroup: UUID()))
        XCTAssertTrue(TranscriptRevision.canDisplay(candidate: "แฟนสาว", current: "แฟนสาวของคุณ",
                        candidateGroup: group, currentGroup: group))
    }

    func testRealtimeCorrectionUpdatesSameParagraphWithoutWaitingForOldPages() {
        let group = UUID()
        var pager = SubtitlePager()
        let old = String(repeating: "我想和他聊天。", count: 50)
        let corrected = String(repeating: "我想和你聊天。", count: 50)
        pager.replace(SubtitleDocument(old, group: group, provisional: true), now: 0)
        _ = pager.tick(now: 6)
        XCTAssertEqual(pager.page, 1)
        pager.submit(SubtitleDocument(corrected, group: group, provisional: false), now: 7, realtime: true)
        XCTAssertEqual(pager.document.text, corrected)
        XCTAssertEqual(pager.page, 1)
        XCTAssertFalse(pager.document.provisional)
        XCTAssertNil(pager.pending)
        XCTAssertTrue(pager.tick(now: 12))
    }

    func testPauseStillFreezesCaptionDuringRealtimeCorrections() {
        var pager = SubtitlePager()
        let group = UUID()
        pager.replace(SubtitleDocument("临时内容", group: group, provisional: true), now: 0)
        pager.setPlaying(false, now: 1)
        pager.submit(SubtitleDocument("修订内容", group: group), now: 2, realtime: true)
        XCTAssertEqual(pager.document.text, "临时内容")
        XCTAssertEqual(pager.pending?.text, "修订内容")
        pager.latest(now: 3)
        XCTAssertEqual(pager.document.text, "修订内容")
    }

    func testNewUtteranceReplacesOldPagesInRealtimeMode() {
        var pager = SubtitlePager()
        pager.replace(SubtitleDocument(String(repeating: "旧内容。", count: 100), group: UUID()), now: 0)
        pager.submit(SubtitleDocument("新的完整句子", group: UUID()), now: 1, realtime: true)
        XCTAssertEqual(pager.document.text, "新的完整句子")
        XCTAssertEqual(pager.page, 0)
    }

    func testFinalFlagCanUpdateWithoutTextChanging() {
        let group = UUID()
        var pager = SubtitlePager()
        pager.replace(SubtitleDocument("你的女朋友", group: group, provisional: true), now: 0)
        pager.submit(SubtitleDocument("你的女朋友", group: group, provisional: false), now: 1, realtime: true)
        XCTAssertFalse(pager.document.provisional)
    }

    func testWholeSourceIsPreservedBeyondOldCharacterLimits() throws {
        let source = "คุณไม่ได้บอกว่า" + String(repeating: "แฟนสาวของคุณอยู่ที่นี่ ", count: 40)
        XCTAssertGreaterThan(source.count, 600)
        let request = try CloudTranslator.request(text: source, apiKey: "gsk_test-key-placeholder")
        let object = try XCTUnwrap(JSONSerialization.jsonObject(with: XCTUnwrap(request.httpBody)) as? [String:Any])
        let messages = try XCTUnwrap(object["messages"] as? [[String:String]])
        XCTAssertTrue(messages[0]["content"]?.hasSuffix(source) == true)
        XCTAssertEqual(TextTools.thaiLines(source), source.trimmingCharacters(in: .whitespacesAndNewlines))
    }

    func testOverlongSourceIsRejectedInsteadOfSilentlyCuttingOffMeaning() {
        XCTAssertThrowsError(try CloudTranslator.request(text: String(repeating: "ก", count: 4001), apiKey: "gsk_test-key-placeholder"))
    }

    func testPartnerContextIsExplicitAndCannotChangeProviderOrModel() throws {
        let request = try CloudTranslator.request(text: "คุณมีแฟนหรือยัง", apiKey: "gsk_test-key-placeholder", partner: .girlfriend)
        let body = String(decoding: try XCTUnwrap(request.httpBody), as: UTF8.self)
        XCTAssertTrue(body.contains("用户补充语境"))
        XCTAssertTrue(body.contains("原文明示"))
        XCTAssertTrue(body.contains("女朋友"))
        XCTAssertEqual(request.url, CloudTranslator.endpoint)
        XCTAssertFalse(body.contains("gsk_test-key-placeholder"))
    }

    func testConfigurablePagingUsesValidDwellAndIgnoresInvalidValue() {
        var pager = SubtitlePager()
        pager.configure(seconds: 4, now: 0)
        pager.replace(SubtitleDocument(String(repeating: "测试完整字幕。", count: 40)), now: 0)
        XCTAssertFalse(pager.tick(now: 3.9))
        XCTAssertTrue(pager.tick(now: 4))
        pager.configure(seconds: 0, now: 4)
        XCTAssertEqual(pager.dwellSeconds, 4)
        XCTAssertEqual(pager.playbackTime(now: 6), 22.5, accuracy: 0.01)
    }
}
