import XCTest
@testable import ThaiLens

final class CloudTranslatorTests: XCTestCase {
    func testRequestUsesOnlyFreeModelAndKeepsCredentialOutOfBody() throws {
        let thai = "อย่าเพิ่งโอนนะ ยังไม่ได้ตกลงราคา"
        let request = try CloudTranslator.request(text: thai, apiKey: "gsk_test-only-secret")
        XCTAssertEqual(request.url?.absoluteString, "https://api.groq.com/openai/v1/chat/completions")
        XCTAssertEqual(request.httpMethod, "POST")
        XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer gsk_test-only-secret")
        let data = try XCTUnwrap(request.httpBody)
        let body = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
        XCTAssertEqual(body["model"] as? String, "qwen/qwen3.8-27b")
        XCTAssertEqual(body["stream"] as? Bool, false)
        XCTAssertEqual(body["reasoning_format"] as? String, "hidden")
        XCTAssertEqual(body["max_completion_tokens"] as? Int, 2048)
        XCTAssertFalse(String(decoding: data, as: UTF8.self).contains("gsk_test-only-secret"))
        let messages = try XCTUnwrap(body["messages"] as? [[String: String]])
        XCTAssertTrue(messages[0]["content"]?.hasSuffix(thai) == true)
        XCTAssertNil(request.url?.query)
    }
    func testRejectsMissingAndMalformedCredentials() {
        for key in ["", "  ", "sk_siliconflow_test", "gsk_tooShort", "test\nInjected-Header: x"] {
            XCTAssertThrowsError(try CloudTranslator.request(text: "สวัสดี", apiKey: key))
        }
    }
    func testDecodesCompleteChineseTranslation() throws {
        let data = Data(#"{"choices":[{"message":{"content":"  先别转账，价格还没谈好。\n"},"finish_reason":"stop"}]}"#.utf8)
        XCTAssertEqual(try CloudTranslator.decode(data, status: 200), "先别转账，价格还没谈好。")
    }
    func testRejectsTruncatedOrFilteredTranslation() {
        for reason in ["length", "content_filter"] {
            let data = Data("{\"choices\":[{\"message\":{\"content\":\"别转\"},\"finish_reason\":\"\(reason)\"}]}".utf8)
            XCTAssertThrowsError(try CloudTranslator.decode(data, status: 200))
        }
    }
    func testRejectsSourceEchoAndReasoningRatherThanDeletingPiecesOfMeaning() throws {
        for content in ["ฉันนอนไม่หลับ 的意思是我睡不着", "<think>分析</think>我睡不着", "ผมไม่มีแฟน"] {
            let data = try JSONSerialization.data(withJSONObject: ["choices": [
                ["message": ["content": content], "finish_reason": "stop"]]])
            XCTAssertThrowsError(try CloudTranslator.decode(data, status: 200)) { error in
                guard case TranslationFailure.nonChinese = error else { return XCTFail("Wrong failure") }
            }
        }
    }
    func testReasoningFieldNeverBecomesSubtitle() throws {
        let data = Data(#"{"choices":[{"message":{"content":"我没有对象。","reasoning":"internal analysis"},"finish_reason":"stop"}]}"#.utf8)
        XCTAssertEqual(try CloudTranslator.decode(data, status: 200), "我没有对象。")
    }
    func testRejectsEmptyAndMalformedSuccessResponses() {
        for json in ["{}", "<html>error</html>", #"{"choices":[]}"#,
                     #"{"choices":[{"message":{"content":" "},"finish_reason":"stop"}]}"#] {
            XCTAssertThrowsError(try CloudTranslator.decode(Data(json.utf8), status: 200))
        }
    }
    func testQuotaAndBillingErrorsNeverBecomeSubtitles() {
        let otherwiseValid = Data(#"{"choices":[{"message":{"content":"ignored"},"finish_reason":"stop"}]}"#.utf8)
        for code in [401, 402, 403, 404, 410, 429, 500] {
            XCTAssertThrowsError(try CloudTranslator.decode(otherwiseValid, status: code))
        }
    }
    func testHTTPResponseIsDecodedThroughInjectedSession() async throws {
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [TranslationStub.self]
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }
        let translator = CloudTranslator(session: session)
        let result = try await translator.translate("ไม่เป็นไร", apiKey: "gsk_test-key-placeholder")
        XCTAssertEqual(result, "没关系。")
    }
    func testCancelledTaskDoesNotProduceTranslation() async {
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [TranslationStub.self]
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }
        let task = Task { () throws -> String in
            withUnsafeCurrentTask { $0?.cancel() }
            return try await CloudTranslator(session: session).translate("ไม่เป็นไร", apiKey: "gsk_test-key-placeholder")
        }
        do { _ = try await task.value; XCTFail("Cancelled translation unexpectedly returned") }
        catch { XCTAssertTrue(error is CancellationError) }
    }
}

private final class TranslationStub: URLProtocol {
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        let response = HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: "HTTP/1.1", headerFields: nil)!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: Data(#"{"choices":[{"message":{"content":"没关系。"},"finish_reason":"stop"}]}"#.utf8))
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}
