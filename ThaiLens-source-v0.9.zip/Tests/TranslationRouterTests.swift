import XCTest
@testable import ThaiLens

@MainActor
final class TranslationRouterTests: XCTestCase {
    private func client() -> CloudTranslator {
        let options = URLSessionConfiguration.ephemeral
        options.protocolClasses = [RoutingStub.self]
        return CloudTranslator(session: URLSession(configuration: options))
    }
    private func translate(_ router: TranslationRouter) async throws -> RoutedTranslation {
        try await router.translate("สวัสดี", apiKey: "gsk_test_only_placeholder",
            configuration: .builtIn, partner: .neutral)
    }
    func testPrimaryLimitSwitchesToBackupAndRespectsPrimaryCooldown() async throws {
        var time = 0.0
        RoutingStub.reset([429, 200, 200, 200])
        let router = TranslationRouter(client: client(), now: { time })
        let first = try await translate(router)
        let second = try await translate(router)
        XCTAssertEqual(first.engine, .backup); XCTAssertEqual(second.engine, .backup)
        time = 11
        let third = try await translate(router)
        XCTAssertEqual(third.engine, .qwen)
        XCTAssertEqual(RoutingStub.models, [TranslationEngine.qwen.rawValue, TranslationEngine.backup.rawValue,
            TranslationEngine.backup.rawValue, TranslationEngine.qwen.rawValue])
    }
    func testBothModelsLimitedReturnWaitWithoutRequestLoop() async throws {
        RoutingStub.reset([429, 429])
        let router = TranslationRouter(client: client(), now: { 0 })
        for _ in 0..<2 {
            do { _ = try await translate(router); XCTFail("Expected cooldown") }
            catch let limit as ServiceRateLimit { XCTAssertEqual(limit.retryAfter, 10) }
        }
        XCTAssertEqual(RoutingStub.models.count, 2)
    }
    func testAuthenticationAndPaymentErrorsNeverTriggerMoreRequests() async throws {
        for code in [401, 402, 403] {
            RoutingStub.reset([code, 200])
            let router = TranslationRouter(client: client())
            do { _ = try await translate(router); XCTFail("Expected account error") } catch { }
            XCTAssertEqual(RoutingStub.models.count, 1)
        }
    }
    func testUnavailablePrimaryCanUseBackup() async throws {
        RoutingStub.reset([404, 200])
        let result = try await translate(TranslationRouter(client: client()))
        XCTAssertEqual(result.engine, .backup)
        XCTAssertEqual(result.text, "你好。")
    }
    func testBackupUsesSupportedParametersAndDoesNotExposeReasoning() throws {
        let request = try CloudTranslator.request(text: "สวัสดี", apiKey: "gsk_test_only_placeholder", engine: .backup)
        let body = try XCTUnwrap(JSONSerialization.jsonObject(with: try XCTUnwrap(request.httpBody)) as? [String: Any])
        XCTAssertEqual(body["model"] as? String, "openai/gpt-oss-120b")
        XCTAssertEqual(body["reasoning_effort"] as? String, "low")
        XCTAssertEqual(body["include_reasoning"] as? Bool, false)
        XCTAssertNil(body["reasoning_format"])
        XCTAssertEqual(request.url?.host, "api.groq.com")
    }
    func testCancelledOrStaleSourceDoesNotSendEvenPrimary() async throws {
        RoutingStub.reset([200])
        let router = TranslationRouter(client: client())
        do {
            _ = try await router.translate("สวัสดี", apiKey: "gsk_test_only_placeholder",
                configuration: .builtIn, partner: .neutral, isCurrent: { false })
            XCTFail("Stale source sent")
        } catch is RecoverySkip { }
        XCTAssertTrue(RoutingStub.models.isEmpty)
    }
}

private final class RoutingStub: URLProtocol {
    private static let lock = NSLock()
    private static var codes: [Int] = []
    private static var seen: [String] = []
    static var models: [String] { lock.lock(); defer { lock.unlock() }; return seen }
    static func reset(_ statuses: [Int]) { lock.lock(); codes = statuses; seen = []; lock.unlock() }
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        var body = request.httpBody ?? Data()
        if body.isEmpty, let stream = request.httpBodyStream {
            stream.open(); defer { stream.close() }
            var buffer = [UInt8](repeating: 0, count: 4096)
            while true {
                let count = stream.read(&buffer, maxLength: buffer.count)
                if count <= 0 { break }
                body.append(contentsOf: buffer.prefix(count))
            }
        }
        let json = (try? JSONSerialization.jsonObject(with: body)) as? [String: Any]
        Self.lock.lock()
        Self.seen.append(json?["model"] as? String ?? "missing")
        let code = Self.codes.isEmpty ? 500 : Self.codes.removeFirst()
        Self.lock.unlock()
        client?.urlProtocol(self, didReceive: HTTPURLResponse(url: request.url!, statusCode: code,
            httpVersion: nil, headerFields: ["Retry-After": "10"])!, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: Data(#"{"choices":[{"message":{"content":"你好。"},"finish_reason":"stop"}]}"#.utf8))
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}
