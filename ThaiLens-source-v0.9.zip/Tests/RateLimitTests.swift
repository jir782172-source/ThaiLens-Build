import XCTest
@testable import ThaiLens

final class RateLimitTests: XCTestCase {
    func testRetryAfterHonorsDailyResetInsteadOfRetryingEveryMinute() throws {
        let response = try XCTUnwrap(HTTPURLResponse(url: CloudTranslator.endpoint, statusCode: 429,
            httpVersion: nil, headerFields: ["Retry-After": "4", "x-ratelimit-remaining-requests": "0",
                "x-ratelimit-reset-requests": "2h1m", "x-ratelimit-remaining-tokens": "42",
                "x-ratelimit-reset-tokens": "8h"]))
        XCTAssertEqual(ServiceRateLimit.from(response).retryAfter, 7260)
    }
    func testDurationUnitsAndMalformedMetadata() {
        XCTAssertEqual(ServiceRateLimit.duration("2m59.56s"), 179.56)
        XCTAssertEqual(ServiceRateLimit.duration("1h2m3s4ms"), 3723.004)
        for value in ["", "NaN", "inf", "-2", "2m rubbish", "s", "private text"] {
            XCTAssertNil(ServiceRateLimit.duration(value))
        }
    }
    func testMissingHeaderLeavesConservativeBackoffToController() throws {
        let response = try XCTUnwrap(HTTPURLResponse(url: CloudTranslator.endpoint, statusCode: 429,
            httpVersion: nil, headerFields: ["Retry-After": "NaN"]))
        XCTAssertNil(ServiceRateLimit.from(response).retryAfter)
    }
    func testHTTPDateRetryAfter() throws {
        let response = try XCTUnwrap(HTTPURLResponse(url: CloudTranslator.endpoint, statusCode: 429,
            httpVersion: nil, headerFields: ["Retry-After": "Thu, 01 Jan 1970 00:01:00 GMT"]))
        XCTAssertEqual(ServiceRateLimit.from(response, now: Date(timeIntervalSince1970: 0)).retryAfter, 60)
    }
    func testLocalSpeechBudgetHasFiniteRecoveryTime() throws {
        var budget = SpeechBudget()
        for _ in 0..<15 { try budget.reserve(duration: 1, now: 100) }
        XCTAssertThrowsError(try budget.reserve(duration: 1, now: 100))
        let wait = budget.retryDelay(duration: 1, now: 100)
        XCTAssertGreaterThanOrEqual(wait, 60); XCTAssertLessThan(wait, 63)
        XCTAssertNoThrow(try budget.reserve(duration: 1, now: 100 + wait))
    }
    func testDiagnosticsKeepOnlyRateLimitCode() {
        let event = DiagnosticEvent(stage: .translation, mode: .audio, error: ServiceRateLimit(retryAfter: 999))
        XCTAssertEqual(event.code, 429); XCTAssertEqual(event.domain, "HTTP")
    }
}

@MainActor
final class RateLimitRecoveryTests: XCTestCase {
    func testCooldownSurvivesNetworkSwitchAndRecovers() async throws {
        var time = 0.0
        var recovery: NetworkRecovery!
        recovery = NetworkRecovery(now: { time }, sleep: { time += $0; recovery.updatePath(available: true) })
        recovery.start(monitorNetwork: false); defer { recovery.stop() }
        var attempts: [Double] = [], statuses: [String] = []
        recovery.onStatus = { if let text = $0 { statuses.append(text) } }
        let result = try await recovery.perform(channel: .translation, isCurrent: { true }) {
            attempts.append(time)
            if attempts.count == 1 { throw ServiceRateLimit(retryAfter: 3) }
            return "恢复"
        }
        XCTAssertEqual(result, "恢复"); XCTAssertEqual(attempts, [0, 3])
        XCTAssertTrue(recovery.active); XCTAssertFalse(recovery.isCoolingDown(.translation))
        XCTAssertTrue(statuses.contains { $0.contains("额度等待") })
    }
    func testStaleRequestStillRecordsCooldownForNextSource() async throws {
        var time = 0.0, current = true
        let recovery = NetworkRecovery(now: { time }, sleep: { time += $0 })
        recovery.start(monitorNetwork: false); defer { recovery.stop() }
        do {
            let _: String = try await recovery.perform(channel: .translation, isCurrent: { current }) {
                current = false; throw ServiceRateLimit(retryAfter: 5)
            }
            XCTFail("Expected stale request to be discarded")
        } catch is RecoverySkip { }
        XCTAssertTrue(recovery.isCoolingDown(.translation))
        _ = try await recovery.perform(channel: .translation, isCurrent: { true }) {
            XCTAssertEqual(time, 5); return "新话题"
        }
    }
    func testManualRestartDoesNotEraseKnownCooldown() async throws {
        var time = 0.0
        var recovery: NetworkRecovery!
        recovery = NetworkRecovery(now: { time }, sleep: { seconds in time += seconds; recovery.stop() })
        recovery.start(monitorNetwork: false)
        var calls = 0
        do {
            let _: Int = try await recovery.perform(channel: .speech, isCurrent: { true }) {
                calls += 1; throw ServiceRateLimit(retryAfter: 120)
            }
            XCTFail("Stop ignored")
        } catch is CancellationError { }
        XCTAssertEqual(calls, 1)
        recovery.start(monitorNetwork: false)
        XCTAssertTrue(recovery.isCoolingDown(.speech)); recovery.stop()
    }
    func testMissingHeadersBackOffInsteadOfRapidRetry() async throws {
        var time = 0.0, attempts: [Double] = []
        let recovery = NetworkRecovery(now: { time }, sleep: { time += $0 })
        recovery.start(monitorNetwork: false); defer { recovery.stop() }
        _ = try await recovery.perform(channel: .translation, isCurrent: { true }) {
            attempts.append(time)
            if attempts.count < 3 { throw ServiceRateLimit(retryAfter: nil) }
            return 1
        }
        XCTAssertEqual(attempts, [0, 60, 180])
    }
    func testTranslationPacingKeepsSpeechIndependent() async throws {
        var time = 0.0
        let recovery = NetworkRecovery(minimumTranslationInterval: 6, now: { time }, sleep: { time += $0 })
        recovery.start(monitorNetwork: false); defer { recovery.stop() }
        _ = try await recovery.perform(channel: .translation, isCurrent: { true }) { 1 }
        _ = try await recovery.perform(channel: .speech, isCurrent: { true }) { XCTAssertEqual(time, 0); return 1 }
        _ = try await recovery.perform(channel: .translation, isCurrent: { true }) { XCTAssertEqual(time, 6); return 1 }
    }
}
