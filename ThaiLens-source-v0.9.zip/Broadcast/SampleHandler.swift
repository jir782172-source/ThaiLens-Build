import ReplayKit
import Network
import CoreImage
import UIKit
import AVFoundation

final class SampleHandler: RPBroadcastSampleHandler {
    private let queue = DispatchQueue(label: "thailens.capture")
    private let context = CIContext(options: [.cacheIntermediates: false])
    private var peer: WirePeer?
    private var mode: CaptureMode?
    private var lastFrame: TimeInterval = 0
    private var sequence: UInt64 = 0
    private var stopped = false
    private var converter: AVAudioConverter?
    private var sourceFormat: AVAudioFormat?
    private var heartbeat: DispatchSourceTimer?
    private var lastPong = Date()
    private var connectionID = UUID()
    private var reconnectSince: Date?
    private var nextConnect = Date.distantPast
    private var paused = false

    override func broadcastStarted(withSetupInfo setupInfo: [String: NSObject]?) {
        queue.async { [self] in
            reconnectSince = Date()
            connect()
            let heartbeat = DispatchSource.makeTimerSource(queue: queue)
            heartbeat.schedule(deadline: .now() + 2, repeating: 2)
            heartbeat.setEventHandler { [weak self] in
                guard let self, !stopped else { return }
                if let since = reconnectSince, Date().timeIntervalSince(since) > 30 {
                    fail("字幕应用未响应，已停止采集。请回到应用后重新开启屏幕广播。")
                    return
                }
                if mode != nil, Date().timeIntervalSince(lastPong) > 12 { resetConnection() }
                if peer == nil, Date() >= nextConnect { connect() }
                peer?.send(WirePacket(kind: "ping"))
            }
            self.heartbeat = heartbeat
            heartbeat.resume()
        }
    }

    private func connect() {
        guard !stopped, peer == nil else { return }
        let id = UUID(); connectionID = id
        let peer = WirePeer(NWConnection(host: .ipv4(.loopback), port: Wire.port, using: .tcp), queue: queue)
        self.peer = peer
        peer.onReady = { [weak self] in
            guard let self, connectionID == id, !stopped else { return }
            self.peer?.send(WirePacket(kind: "hello"))
        }
        peer.onPacket = { [weak self] packet in
            guard let self, connectionID == id, !stopped else { return }
            if packet.kind == "configure" {
                mode = packet.mode
                reconnectSince = nil; lastPong = Date()
                if paused { self.peer?.send(WirePacket(kind: "paused")) }
            }
            if packet.kind == "pong" { lastPong = Date() }
            if packet.kind == "stop" { fail("字幕已停止。请重新打开泰语字幕准备翻译。") }
        }
        peer.onClose = { [weak self] _ in
            guard let self, connectionID == id, !stopped else { return }
            resetConnection()
        }
        peer.start()
        queue.asyncAfter(deadline: .now() + 6) { [weak self] in
            guard let self, connectionID == id, mode == nil, !stopped else { return }
            resetConnection()
        }
    }

    private func resetConnection() {
        connectionID = UUID()
        peer?.onClose = nil; peer?.close(); peer = nil
        mode = nil; converter = nil; sourceFormat = nil
        if reconnectSince == nil { reconnectSince = Date() }
        nextConnect = Date().addingTimeInterval(2)
    }

    override func processSampleBuffer(_ sampleBuffer: CMSampleBuffer, with sampleBufferType: RPSampleBufferType) {
        // Reject microphone data before retaining, inspecting or dispatching the buffer.
        guard sampleBufferType != .audioMic else { return }
        // Do not enqueue retained full-resolution frames: the extension has a small memory budget.
        queue.sync {
            guard !stopped, let mode, CapturePolicy.accepts(sampleBufferType, mode: mode) else { return }
            autoreleasepool {
                if mode == .screen, sampleBufferType == .video { captureImage(sampleBuffer) }
                if mode == .audio, sampleBufferType == .audioApp { captureAudio(sampleBuffer) }
                // Microphone buffers are deliberately ignored.
            }
        }
    }

    override func broadcastPaused() {
        queue.async { [weak self] in self?.paused = true; self?.peer?.send(WirePacket(kind: "paused")) }
    }

    override func broadcastResumed() {
        queue.async { [weak self] in self?.paused = false; self?.peer?.send(WirePacket(kind: "resumed")) }
    }

    override func broadcastFinished() {
        queue.async { [weak self] in
            guard let self else { return }
            stopped = true
            heartbeat?.cancel()
            heartbeat = nil
            let retiring = peer
            retiring?.onClose = nil
            retiring?.send(WirePacket(kind: "finished"))
            queue.asyncAfter(deadline: .now() + 0.2) { retiring?.close() }
            peer = nil
        }
    }

    private func fail(_ message: String) {
        guard !stopped else { return }
        stopped = true
        heartbeat?.cancel()
        heartbeat = nil
        peer?.close()
        finishBroadcastWithError(NSError(domain: "ThaiLens", code: 1,
                                         userInfo: [NSLocalizedDescriptionKey: message]))
    }

    private func captureImage(_ buffer: CMSampleBuffer) {
        let now = ProcessInfo.processInfo.systemUptime
        guard now - lastFrame >= 1.2 else { return }
        lastFrame = now
        guard let pixels = CMSampleBufferGetImageBuffer(buffer) else { return }
        var image = CIImage(cvPixelBuffer: pixels)
        if let value = CMGetAttachment(buffer, key: RPVideoSampleOrientationKey as CFString,
                                       attachmentModeOut: nil) as? NSNumber {
            image = image.oriented(forExifOrientation: value.int32Value)
        }
        let scale = min(1.0, 2048.0 / max(image.extent.width, image.extent.height))
        image = image.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        guard let cg = context.createCGImage(image, from: image.extent),
              let jpeg = UIImage(cgImage: cg).jpegData(compressionQuality: 0.78),
              jpeg.count < 1_000_000 else { return }
        peer?.send(WirePacket(kind: "image", image: jpeg))
    }

    private func captureAudio(_ sample: CMSampleBuffer) {
        guard let description = CMSampleBufferGetFormatDescription(sample) else { return }
        let format = AVAudioFormat(cmAudioFormatDescription: description)
        let frames = CMSampleBufferGetNumSamples(sample)
        guard (1...16_384).contains(frames),
              let input = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: AVAudioFrameCount(frames)) else { return }
        input.frameLength = AVAudioFrameCount(frames)
        guard CMSampleBufferCopyPCMDataIntoAudioBufferList(sample, at: 0, frameCount: Int32(frames),
                                                           into: input.mutableAudioBufferList) == noErr else { return }
        guard let mono = AVAudioFormat(commonFormat: .pcmFormatFloat32, sampleRate: format.sampleRate,
                                       channels: 1, interleaved: false) else { return }
        if sourceFormat != format {
            sourceFormat = format
            converter = AVAudioConverter(from: format, to: mono)
        }
        guard let converter, let output = AVAudioPCMBuffer(pcmFormat: mono, frameCapacity: input.frameCapacity) else { return }
        var supplied = false
        var error: NSError?
        converter.convert(to: output, error: &error) { _, status in
            if supplied { status.pointee = .noDataNow; return nil }
            supplied = true
            status.pointee = .haveData
            return input
        }
        guard error == nil, output.frameLength > 0, let floats = output.floatChannelData?[0] else { return }
        sequence &+= 1
        let bytes = Data(bytes: floats, count: Int(output.frameLength) * 4)
        let chunk = PCMChunk(rate: mono.sampleRate, frames: Int(output.frameLength), samples: bytes, sequence: sequence)
        peer?.send(WirePacket(kind: "audio", pcm: chunk))
    }
}
