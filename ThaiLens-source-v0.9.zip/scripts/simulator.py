"""Prefer the runtime matching the selected Xcode SDK."""
import json
import subprocess

data = json.loads(subprocess.check_output(["xcrun", "simctl", "list", "devices", "available", "--json"]))
choices = [(runtime, device) for runtime, devices in data["devices"].items()
           if "iOS" in runtime for device in devices if "iPhone" in device["name"] and device.get("isAvailable")]
if not choices:
    raise SystemExit("No available iPhone simulator installed")
sdk = subprocess.check_output(["xcrun", "--sdk", "iphonesimulator", "--show-sdk-version"], text=True).strip()
matching = [choice for choice in choices if choice[0].endswith("iOS-" + sdk.replace(".", "-"))]
def version(choice):
    return tuple(int(part) for part in choice[0].split("iOS-")[-1].split("-"))
runtime, device = max(matching or choices, key=version)
print(device["udid"])
