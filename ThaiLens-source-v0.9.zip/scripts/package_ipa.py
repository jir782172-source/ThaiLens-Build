"""Validate an unsigned device build before packaging it for external re-signing."""
from pathlib import Path
import plistlib
import shutil
import struct
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]

def read_plist(path):
    with path.open("rb") as stream:
        return plistlib.load(stream)

def validate_executable(executable):
    with executable.open("rb") as stream:
        header = stream.read(12)
    if len(header) != 12:
        raise RuntimeError("Missing Mach-O executable")
    magic, cpu, _ = struct.unpack("<III", header)
    if magic != 0xFEEDFACF or cpu != 0x0100000C:
        raise RuntimeError("Expected a thin 64-bit arm64 Mach-O device executable")

def validate_app(app):
    info = read_plist(app / "Info.plist")
    if info.get("CFBundleSupportedPlatforms") != ["iPhoneOS"]:
        raise RuntimeError("Refusing to package a simulator app as IPA")
    executable = app / info["CFBundleExecutable"]
    validate_executable(executable)
    extension = app / "PlugIns" / "ThaiLensBroadcast.appex"
    ext_info = read_plist(extension / "Info.plist")
    if ext_info["CFBundleIdentifier"] != info["CFBundleIdentifier"] + ".broadcast":
        raise RuntimeError("Broadcast extension bundle identifier mismatch")
    if not (extension / ext_info["CFBundleExecutable"]).is_file():
        raise RuntimeError("Missing broadcast executable")
    if ext_info.get("CFBundleSupportedPlatforms") != ["iPhoneOS"]:
        raise RuntimeError("Broadcast extension must be built for iPhoneOS")
    validate_executable(extension / ext_info["CFBundleExecutable"])
    model = app / "tessdata" / "tha.traineddata"
    if not model.is_file() or model.stat().st_size < 100_000:
        raise RuntimeError("Missing Thai OCR model")
    if not (app / "Licenses").is_dir():
        raise RuntimeError("Missing third-party licenses")
    return info

def main():
    app = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT / "build/Build/Products/Release-iphoneos/ThaiLens.app"
    info = validate_app(app)
    dist = ROOT / "dist"
    payload = dist / "Payload"
    destination = payload / "ThaiLens.app"
    if destination.exists():
        raise RuntimeError("Output already exists; choose a fresh workspace/build before packaging")
    payload.mkdir(parents=True, exist_ok=True)
    shutil.copytree(app, destination, symlinks=True)
    archive = dist / "ThaiLens-unsigned.ipa"
    subprocess.run(["ditto", "-c", "-k", "--sequesterRsrc", "--keepParent", str(payload), str(archive)], check=True)
    print(f"Packaged {info['CFBundleIdentifier']}: {archive.name}")
    print("UNSIGNED: external signing of both the app and its broadcast extension is still required.")

if __name__ == "__main__":
    main()
