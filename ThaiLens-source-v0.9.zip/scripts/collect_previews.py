"""Collect public fixture images drawn by the actual iOS renderer in XCTest."""
from pathlib import Path
import shutil

root = Path(__file__).resolve().parents[1]
destination = root / 'dist/subtitle-previews'
destination.mkdir(parents=True, exist_ok=True)
devices = Path.home() / 'Library/Developer/CoreSimulator/Devices'
for image in devices.glob('*/data/Containers/Data/Application/*/Library/Caches/SubtitlePreviews/subtitle-page-*.png'):
    shutil.copyfile(image, destination / image.name)
count = len(list(destination.glob('*.png')))
if count < 3:
    raise RuntimeError(f'Expected at least 3 simulator-rendered pagination previews, got {count}')
print(f'Collected {count} actual iOS subtitle previews')
