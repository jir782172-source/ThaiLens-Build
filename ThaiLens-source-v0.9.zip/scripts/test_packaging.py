"""Contract checks for rejecting non-installable build inputs, using temporary fixtures."""
import plistlib
from pathlib import Path
import struct
import tempfile
import unittest
from package_ipa import validate_app

class PackagingTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        assert Path(self.temp.name).resolve().is_relative_to(Path(tempfile.gettempdir()).resolve())
        self.addCleanup(self.temp.cleanup)
        self.app = Path(self.temp.name) / "ThaiLens.app"
        self.app.mkdir()
        self.info = {
            "CFBundleSupportedPlatforms": ["iPhoneOS"],
            "CFBundleIdentifier": "example.thailens",
            "CFBundleExecutable": "ThaiLens",
        }
        self.write_info()
        (self.app / "ThaiLens").write_bytes(struct.pack("<III", 0xFEEDFACF, 0x0100000C, 0))
        extension = self.app / "PlugIns/ThaiLensBroadcast.appex"
        extension.mkdir(parents=True)
        (extension / "Info.plist").write_bytes(plistlib.dumps({
            "CFBundleIdentifier": "example.thailens.broadcast", "CFBundleExecutable": "ThaiLensBroadcast",
            "CFBundleSupportedPlatforms": ["iPhoneOS"]
        }))
        (extension / "ThaiLensBroadcast").write_bytes(struct.pack("<III", 0xFEEDFACF, 0x0100000C, 0))
        (self.app / "tessdata").mkdir()
        (self.app / "tessdata/tha.traineddata").write_bytes(b"x" * 100_001)
        (self.app / "Licenses").mkdir()

    def write_info(self):
        (self.app / "Info.plist").write_bytes(plistlib.dumps(self.info))

    def test_accepts_expected_layout(self):
        self.assertEqual(validate_app(self.app)["CFBundleIdentifier"], "example.thailens")

    def test_rejects_simulator(self):
        self.info["CFBundleSupportedPlatforms"] = ["iPhoneSimulator"]
        self.write_info()
        with self.assertRaisesRegex(RuntimeError, "simulator"):
            validate_app(self.app)

    def test_rejects_wrong_architecture(self):
        (self.app / "ThaiLens").write_bytes(struct.pack("<III", 0xFEEDFACF, 0x01000007, 0))
        with self.assertRaisesRegex(RuntimeError, "arm64"):
            validate_app(self.app)

    def test_rejects_missing_extension_binary(self):
        (self.app / "PlugIns/ThaiLensBroadcast.appex/ThaiLensBroadcast").unlink()
        with self.assertRaisesRegex(RuntimeError, "broadcast executable"):
            validate_app(self.app)

    def test_rejects_missing_model(self):
        (self.app / "tessdata/tha.traineddata").unlink()
        with self.assertRaisesRegex(RuntimeError, "OCR model"):
            validate_app(self.app)

    def test_rejects_wrong_extension_architecture(self):
        (self.app / "PlugIns/ThaiLensBroadcast.appex/ThaiLensBroadcast").write_bytes(
            struct.pack("<III", 0xFEEDFACF, 0x01000007, 0))
        with self.assertRaisesRegex(RuntimeError, "arm64"):
            validate_app(self.app)

if __name__ == "__main__":
    unittest.main()
