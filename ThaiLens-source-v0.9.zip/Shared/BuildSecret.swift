// Replaced with a new random local IPC token by scripts/prepare.py.
enum BuildSecret { static let token = "0000000000000000000000000000000000000000000000000000000000000000" }
