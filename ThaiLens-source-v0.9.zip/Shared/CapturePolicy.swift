import ReplayKit

// This is the sole admission gate before any sample data is read or forwarded.
// Missing app audio must never trigger a microphone fallback.
enum CapturePolicy {
    static func accepts(_ type: RPSampleBufferType, mode: CaptureMode) -> Bool {
        switch (mode, type) {
        case (.screen, .video), (.audio, .audioApp): return true
        default: return false
        }
    }
}
