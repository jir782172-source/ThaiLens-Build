import Foundation
import Network

enum CaptureMode: String, Codable, CaseIterable, Identifiable {
    case screen, audio
    var id: String { rawValue }
    var title: String { self == .screen ? "聊天 / 画面文字" : "应用里的泰语声音" }
}

struct PCMChunk: Codable {
    var rate: Double
    var frames: Int
    // Mono float32, native little endian on iPhone.
    var samples: Data
    var sequence: UInt64
    var isValid: Bool {
        rate.isFinite && (8_000...96_000).contains(rate)
            && (1...16_384).contains(frames) && samples.count == frames * 4
    }
}

struct WirePacket: Codable {
    var token = BuildSecret.token
    var kind: String
    var mode: CaptureMode?
    var image: Data?
    var pcm: PCMChunk?
    var message: String?
}

enum WireError: Error { case invalidLength, unauthorized }

enum Wire {
    static let port: NWEndpoint.Port = 28461
    static let maxPacket = 1_500_000
    static func encode(_ packet: WirePacket) throws -> Data {
        let body = try JSONEncoder().encode(packet)
        guard body.count <= maxPacket else { throw WireError.invalidLength }
        var count = UInt32(body.count).bigEndian
        var data = withUnsafeBytes(of: &count) { Data($0) }
        data.append(body)
        return data
    }
}

// Handles split headers, split JSON, and multiple packets in a single TCP read.
struct PacketDecoder {
    private var buffer = Data()
    mutating func append(_ data: Data) throws -> [WirePacket] {
        buffer.append(data)
        var packets: [WirePacket] = []
        while buffer.count >= 4 {
            let length = buffer.prefix(4).reduce(0) { ($0 << 8) | Int($1) }
            guard length > 0, length <= Wire.maxPacket else { throw WireError.invalidLength }
            guard buffer.count >= 4 + length else { break }
            let body = Data(buffer.dropFirst(4).prefix(length))
            let packet = try JSONDecoder().decode(WirePacket.self, from: body)
            guard packet.token == BuildSecret.token else { throw WireError.unauthorized }
            packets.append(packet)
            buffer.removeFirst(4 + length)
        }
        guard buffer.count <= Wire.maxPacket + 4 else { throw WireError.invalidLength }
        return packets
    }
}

// All methods/callbacks must be used on the queue supplied at construction.
final class WirePeer {
    let connection: NWConnection
    let queue: DispatchQueue
    var onPacket: ((WirePacket) -> Void)?
    var onClose: ((String) -> Void)?
    var onReady: (() -> Void)?
    private var decoder = PacketDecoder()
    private var pending = 0
    private var closed = false
    private var ready = false

    init(_ connection: NWConnection, queue: DispatchQueue) {
        self.connection = connection
        self.queue = queue
    }

    func start() {
        connection.stateUpdateHandler = { [weak self] state in
            guard let self, !closed else { return }
            switch state {
            case .ready:
                ready = true
                onReady?()
                receive()
            case .failed(let error): close(error.localizedDescription)
            case .waiting(let error): close(error.localizedDescription)
            case .cancelled: close("连接已结束")
            default: break
            }
        }
        connection.start(queue: queue)
    }

    @discardableResult func send(_ packet: WirePacket) -> Bool {
        guard ready, !closed, pending < 4, let data = try? Wire.encode(packet) else { return false }
        pending += 1
        connection.send(content: data, completion: .contentProcessed { [weak self] error in
            guard let self else { return }
            pending -= 1
            if let error { close(error.localizedDescription) }
        })
        return true
    }

    func close(_ reason: String = "连接已结束") {
        guard !closed else { return }
        closed = true
        connection.cancel()
        onClose?(reason)
    }

    private func receive() {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 65_536) { [weak self] data, _, done, error in
            guard let self, !closed else { return }
            do {
                if let data {
                    for packet in try decoder.append(data) { onPacket?(packet) }
                }
            } catch { close("本机数据校验失败"); return }
            if let error { close(error.localizedDescription); return }
            if done { close(); return }
            receive()
        }
    }
}
